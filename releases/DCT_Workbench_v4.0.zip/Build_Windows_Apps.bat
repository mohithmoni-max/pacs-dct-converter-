@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  set "PYTHON=python"
) else (
  set "PYTHON=py -3"
)
if not exist .venv\Scripts\python.exe %PYTHON% -m venv .venv
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt pyinstaller
if errorlevel 1 exit /b 1
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name DCT_Workbench app\dct_workbench.py --distpath dist --workpath build\workbench --specpath build
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name PACS_DCT_Suite app\pacs_dct_suite.py --distpath dist --workpath build\suite --specpath build
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --console --name DCT_All_Template_Validator app\dct_all_template_validator.py --distpath dist --workpath build\validator --specpath build
if errorlevel 1 exit /b 1
copy /y app\dct_validator_settings.json dist\dct_validator_settings.json >nul
echo Built applications are in the dist folder.
