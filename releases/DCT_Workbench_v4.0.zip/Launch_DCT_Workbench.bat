@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  set "PYTHON=python"
) else (
  set "PYTHON=py -3"
)
if not exist .venv\Scripts\python.exe %PYTHON% -m venv .venv
if errorlevel 1 (
  echo Could not create the local Python environment.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo Dependency setup failed. Check your Python installation and internet connection.
  pause
  exit /b 1
)
.venv\Scripts\python.exe app\dct_workbench.py
if errorlevel 1 pause
