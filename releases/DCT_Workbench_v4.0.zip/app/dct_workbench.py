#!/usr/bin/env python3
"""DCT Workbench: guided access to the PACS suite and all-template validator."""
from __future__ import annotations

import hashlib
import json
import os
import queue
import subprocess
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


FROZEN = bool(getattr(sys, "frozen", False))
APP_DIR = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parent
SUITE = APP_DIR / ("PACS_DCT_Suite.exe" if FROZEN else "pacs_dct_suite.py")
VALIDATOR = APP_DIR / ("DCT_All_Template_Validator.exe" if FROZEN else "dct_all_template_validator.py")
SETTINGS = APP_DIR / "dct_validator_settings.json"
HISTORY = APP_DIR / "run_history.json"
DEFAULTS = {
    "negative_sign_convention_share": 0.80,
    "date_tolerance_days": 2,
    "installment_amount_tolerance_pct": 0.05,
    "deposit_amount_tolerance_pct": 0.02,
    "rd_total_paid_tolerance_pct": 0.02,
}
LABELS = {
    "negative_sign_convention_share": "Negative sign convention threshold (0–100%)",
    "date_tolerance_days": "Date tolerance (days)",
    "installment_amount_tolerance_pct": "Installment amount tolerance (0–100%)",
    "deposit_amount_tolerance_pct": "Maturity amount tolerance (0–100%)",
    "rd_total_paid_tolerance_pct": "RD paid-total tolerance (0–100%)",
}


def now_text() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_settings() -> dict:
    values = dict(DEFAULTS)
    try:
        raw = json.loads(SETTINGS.read_text(encoding="utf-8"))
        for key in values:
            values[key] = float(raw.get(key, values[key]))
    except (OSError, ValueError, TypeError):
        pass
    return values


def save_history(record: dict) -> None:
    try:
        items = json.loads(HISTORY.read_text(encoding="utf-8")) if HISTORY.exists() else []
        if not isinstance(items, list):
            items = []
    except (OSError, ValueError):
        items = []
    items.append(record)
    HISTORY.write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding="utf-8")


class Workbench(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("DCT Workbench 4.0")
        self.geometry("900x650")
        self.minsize(760, 540)
        self.folder = tk.StringVar()
        self.recursive = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value="Choose a folder containing DCT files to begin.")
        self.events: queue.Queue = queue.Queue()
        self.busy = False
        self.latest_report: Path | None = None
        self._build()
        self.after(100, self._drain_events)

    def _build(self):
        pad = {"padx": 14, "pady": 8}
        body = ttk.Frame(self, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="DCT Workbench", font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(body, text="Validate files, prepare them in the PACS suite, and keep a local audit trail.",
                  wraplength=820).pack(anchor="w", pady=(3, 15))

        folder_row = ttk.Frame(body)
        folder_row.pack(fill="x", **pad)
        ttk.Label(folder_row, text="DCT file folder").pack(anchor="w")
        line = ttk.Frame(folder_row)
        line.pack(fill="x", pady=(4, 0))
        ttk.Entry(line, textvariable=self.folder).pack(side="left", fill="x", expand=True)
        ttk.Button(line, text="Choose…", command=self._choose_folder).pack(side="left", padx=(8, 0))
        ttk.Checkbutton(folder_row, text="Include subfolders", variable=self.recursive).pack(anchor="w", pady=(7, 0))

        actions = ttk.LabelFrame(body, text="Workflow", padding=12)
        actions.pack(fill="x", **pad)
        self.validate_btn = ttk.Button(actions, text="1. Validate this folder", command=self._validate)
        self.validate_btn.grid(row=0, column=0, sticky="w", padx=6, pady=6)
        self.suite_btn = ttk.Button(actions, text="2. Open PACS DCT suite", command=self._launch_suite)
        self.suite_btn.grid(row=0, column=1, sticky="w", padx=6, pady=6)
        self.output_btn = ttk.Button(actions, text="Validate generated output…", command=self._validate_output)
        self.output_btn.grid(row=0, column=2, sticky="w", padx=6, pady=6)
        self.review_btn = ttk.Button(actions, text="Mark latest report reviewed", command=self._mark_reviewed, state="disabled")
        self.review_btn.grid(row=1, column=0, sticky="w", padx=6, pady=6)
        ttk.Button(actions, text="Validation rule settings", command=self._settings_dialog).grid(
            row=1, column=1, sticky="w", padx=6, pady=6)
        actions.columnconfigure(3, weight=1)

        ttk.Label(body, textvariable=self.status).pack(anchor="w", padx=14, pady=(4, 2))
        self.log = tk.Text(body, height=18, wrap="word", state="disabled", font=("Consolas", 9))
        self.log.pack(fill="both", expand=True, padx=14, pady=8)
        self.progress = ttk.Progressbar(body, mode="indeterminate")
        self.progress.pack(fill="x", padx=14, pady=(0, 8))
        ttk.Label(body, text="Local run history stores filenames, file hashes, settings, and review timestamps. It does not copy spreadsheet rows into the history.",
                  wraplength=820).pack(anchor="w", padx=14, pady=(0, 4))

    def _choose_folder(self):
        chosen = filedialog.askdirectory(title="Choose the DCT file folder")
        if chosen:
            self.folder.set(chosen)

    def _write_log(self, text: str):
        self.log.configure(state="normal")
        self.log.insert("end", text.rstrip() + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _set_busy(self, busy: bool, status: str):
        self.busy = busy
        self.status.set(status)
        self.progress.start(10) if busy else self.progress.stop()
        state = "disabled" if busy else "normal"
        self.validate_btn.configure(state=state)
        self.suite_btn.configure(state=state)
        self.output_btn.configure(state=state)

    def _validate(self):
        raw = self.folder.get().strip()
        if not raw or not Path(raw).is_dir():
            messagebox.showerror("Choose a folder", "Select an existing folder containing DCT files.")
            return
        self._start_validation(Path(raw))

    def _validate_output(self):
        chosen = filedialog.askdirectory(title="Choose the PACS suite output folder")
        if chosen:
            self._start_validation(Path(chosen))

    def _start_validation(self, folder: Path):
        if self.busy:
            return
        self._set_busy(True, f"Validating {folder}…")
        self._write_log(f"Starting validation: {folder}")
        thread = threading.Thread(target=self._validation_worker, args=(folder, self.recursive.get()), daemon=True)
        thread.start()

    def _validation_worker(self, folder: Path, recursive: bool):
        started = now_text()
        candidates = sorted(folder.rglob("*") if recursive else folder.iterdir())
        files = [p for p in candidates if p.is_file() and p.suffix.lower() in {".xls", ".xlsx", ".xlsm", ".csv", ".tsv", ".txt"}
                 and not any(part.startswith("Validated_") for part in p.parts)]
        input_meta = []
        try:
            for path in files:
                input_meta.append({"name": str(path.relative_to(folder)), "size": path.stat().st_size, "sha256": sha256(path)})
            args = ([str(VALIDATOR), str(folder)] if FROZEN
                    else [sys.executable, "-u", str(VALIDATOR), str(folder)])
            if recursive:
                args.append("--recursive")
            process = subprocess.Popen(args, cwd=APP_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, encoding="utf-8", errors="replace")
            output_lines = []
            assert process.stdout is not None
            for line in process.stdout:
                output_lines.append(line.rstrip())
                self.events.put(("log", line.rstrip()))
            code = process.wait()
            reports = sorted(folder.glob("Validated_*"), key=lambda p: p.stat().st_mtime, reverse=True)
            report = reports[0] if reports else None
            out_meta = []
            if report:
                for path in sorted(report.rglob("*")):
                    if path.is_file():
                        out_meta.append({"name": str(path.relative_to(report)), "size": path.stat().st_size, "sha256": sha256(path)})
            record = {
                "id": datetime.now().strftime("%Y%m%d-%H%M%S-%f"),
                "type": "validation",
                "started_at": started,
                "finished_at": now_text(),
                "folder": str(folder.resolve()),
                "exit_code": code,
                "validator_version": "3.1",
                "settings": load_settings(),
                "inputs": input_meta,
                "report_folder": str(report.resolve()) if report else None,
                "outputs": out_meta,
            }
            save_history(record)
            self.events.put(("complete", code, report, "\n".join(output_lines)))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def _drain_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "log":
                    self._write_log(event[1])
                elif event[0] == "complete":
                    _, code, report, _ = event
                    self._set_busy(False, "Validation complete." if code == 0 else f"Validation stopped with exit code {code}.")
                    self.latest_report = report
                    self.review_btn.configure(state="normal" if report else "disabled")
                    if report:
                        self._write_log(f"Report folder: {report}")
                        try:
                            os.startfile(report)
                        except OSError:
                            pass
                elif event[0] == "error":
                    self._set_busy(False, "Validation could not be completed.")
                    messagebox.showerror("Validation error", event[1])
        except queue.Empty:
            pass
        self.after(100, self._drain_events)

    def _mark_reviewed(self):
        report = self.latest_report
        if not report or not report.is_dir():
            messagebox.showinfo("No report selected", "Run validation first.")
            return
        if not messagebox.askyesno("Confirm review", "Have you reviewed the rejected rows and review items in this report?"):
            return
        record = {"type": "review_approval", "reviewed_at": now_text(), "report_folder": str(report.resolve()),
                  "reviewed_files": [{"name": str(p.relative_to(report)), "sha256": sha256(p)}
                                     for p in report.rglob("*") if p.is_file()]}
        save_history(record)
        self._write_log(f"Reviewed report recorded: {report}")
        self.status.set("Report review recorded in local history.")

    def _launch_suite(self):
        if not SUITE.exists():
            messagebox.showerror("Suite missing", f"Could not find {SUITE}")
            return
        try:
            subprocess.Popen([str(SUITE)] if FROZEN else [sys.executable, str(SUITE)], cwd=APP_DIR)
            save_history({"type": "suite_launched", "started_at": now_text(), "suite_version": "4.0",
                          "source_folder": self.folder.get().strip() or None})
            self._write_log("PACS DCT suite opened. Its existing reports capture mapping and cleanup details.")
        except Exception as exc:
            messagebox.showerror("Could not open suite", str(exc))

    def _settings_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title("Validation rule settings")
        dialog.transient(self)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="These settings adjust tolerances; they do not change source data.",
                  wraplength=460).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        current = load_settings()
        vars_by_key = {}
        for row, (key, label) in enumerate(LABELS.items(), start=1):
            var = tk.StringVar(value=str(current[key] * 100 if key.endswith("_pct") or key.endswith("_share") else current[key]))
            vars_by_key[key] = var
            ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=5)
            ttk.Entry(frame, textvariable=var, width=12).grid(row=row, column=1, sticky="e", pady=5)
        def save():
            values = {}
            try:
                for key, var in vars_by_key.items():
                    value = float(var.get().strip())
                    if key.endswith("_pct") or key.endswith("_share"):
                        if not 0 <= value <= 100:
                            raise ValueError("Percent values must be between 0 and 100.")
                        value /= 100
                    elif not 0 <= value <= 366:
                        raise ValueError("Date tolerance must be between 0 and 366 days.")
                    values[key] = value
            except ValueError as exc:
                messagebox.showerror("Invalid setting", str(exc), parent=dialog)
                return
            SETTINGS.write_text(json.dumps(values, indent=2), encoding="utf-8")
            self._write_log("Validation rule settings saved. They are applied on the next validation run.")
            dialog.destroy()
        buttons = ttk.Frame(frame)
        buttons.grid(row=len(LABELS) + 1, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Cancel", command=dialog.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Save settings", command=save).pack(side="right")
        dialog.resizable(False, False)


if __name__ == "__main__":
    Workbench().mainloop()
