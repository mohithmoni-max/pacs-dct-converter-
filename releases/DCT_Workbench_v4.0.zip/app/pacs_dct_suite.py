#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 PACS DCT + MAPPING SUITE  --  merged from DCT.py + pacs_mapping_tool.py
 One script: source-file conversion & validation, member-number checks,
 split by Member/Product, product/purpose mapping with keyboard-searchable
 pickers, Masters + Transactions generation, and combined reporting.
================================================================================

WHAT CHANGED vs. the two original tools (see accompanying summary for detail):
  - Single script -- no more running one tool, saving files, then opening a
    second tool. "Split by Product" now loads straight into Product Mapping.
  - "Select PACS" and Product/Purpose pickers are keyboard-searchable
    (type to filter) instead of long scrolling dropdown lists.
  - New: Duplicate Member Report + Special Member Number Error Report
    (AdmissionNo must be numeric only -- "A125"/"B226"-style values are
    flagged, not silently accepted).
  - AdmissionDate cap is no longer hardcoded to 31-03-2026 (which had already
    passed) -- it auto-advances to the next 31-March and is editable in Setup.
  - Fixed a date-parsing bug where day/month could be swapped for dates with
    day <= 12 (pandas was parsing "01-04-2020" as 4-Jan instead of 1-Apr).
  - Product/Purpose taxonomy updated per the Crop/Purpose Requirement
    attachment (farmer-size KCC categories, vehicle purchase types, etc.),
    with the Purpose list auto-narrowing based on the selected Product.
  - Reports tab consolidates every validation + mapping-audit report, with a
    single "Export All Reports" multi-sheet workbook.

Requires: pandas, openpyxl, xlrd, numpy  (installed automatically if missing)
"""

import sys
import subprocess


def _ensure_dependencies():
    # When packaged into a Windows .exe (PyInstaller), every dependency is already bundled inside the
    # exe -- there is no separate Python/pip to call, sys.executable IS the .exe itself, and trying to
    # "pip install" from inside a frozen app is both pointless and can fail in confusing ways. Skip
    # entirely in that case; this only runs when the app is launched as a plain .py script.
    if getattr(sys, "frozen", False):
        return
    required = {"pandas": "pandas", "openpyxl": "openpyxl", "xlrd": "xlrd", "numpy": "numpy", "olefile": "olefile"}
    missing = []
    for module_name, pip_name in required.items():
        try:
            __import__(module_name)
        except ImportError:
            missing.append(pip_name)
    if missing:
        print(f"Installing required packages: {', '.join(missing)} ...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", *missing])
        except Exception:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", "--user", *missing])
            except Exception as e:
                print("Automatic install failed. Please run manually:")
                print(f"    {sys.executable} -m pip install {' '.join(missing)}")
                raise SystemExit(1) from e


_ensure_dependencies()

import types as _types


import os
import re
import json
import datetime
import pandas as pd
import numpy as np
from collections import defaultdict

# ---------------------------------------------------------------------------
# 1. CONSTANTS
# ---------------------------------------------------------------------------

CONFIG_FILENAME = "dct_mapping_config.json"

# Regex helpers -------------------------------------------------------------
RE_SPECIAL_CHARS = re.compile(r"[@#$%^&*()+=!~<>?|{}\[\]\\;:\"'`]+")
RE_MULTISPACE = re.compile(r"\s+")
RE_NONDIGIT = re.compile(r"\D+")
RE_SO = re.compile(r"^\s*S/?\s*O\.?\s*[:\-]?\s*", re.IGNORECASE)
RE_DO = re.compile(r"^\s*D/?\s*O\.?\s*[:\-]?\s*", re.IGNORECASE)
RE_WO = re.compile(r"^\s*W/?\s*O\.?\s*[:\-]?\s*", re.IGNORECASE)
RE_HO = re.compile(r"^\s*H/?\s*O\.?\s*[:\-]?\s*", re.IGNORECASE)  # Husband of
RE_CO = re.compile(r"^\s*C/?\s*O\.?\s*[:\-]?\s*", re.IGNORECASE)  # Care Of
RE_PAN = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
RE_AADHAR = re.compile(r"^[2-9][0-9]{11}$")

# Standard Verhoeff algorithm tables -- well-documented, unchanging constants used for Aadhaar's
# built-in check digit. CONFIRMED against 7 real, known-invalid Aadhaar numbers pulled from actual
# core-system rejection reports ("Found invalid Adhaar Card Number : ..."): every one of them passed
# the format-only check (RE_AADHAR above -- 12 digits, doesn't start with 0/1) but ALL 7 correctly
# fail this checksum. Format-only checking was letting through numbers the real system rejects.
_VERHOEFF_D = [
    [0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],
    [3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],
    [6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],
    [9,8,7,6,5,4,3,2,1,0],
]
_VERHOEFF_P = [
    [0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],
    [8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],
    [2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8],
]

def verhoeff_checksum_valid(num_str):
    c = 0
    for i, digit in enumerate(reversed(num_str)):
        c = _VERHOEFF_D[c][_VERHOEFF_P[i % 8][int(digit)]]
    return c == 0
RE_MOBILE = re.compile(r"^[6-9][0-9]{9}$")
RE_VOTERID = re.compile(r"^[A-Z]{3}[0-9]{7}$")
RE_IFSC = re.compile(r"^[A-Z]{4}0[A-Z0-9]{6}$")

# Maximum allowed AdmissionDate -- this used to be hard-coded to 31-03-2026, which
# silently goes stale every financial year. It now defaults to the *next* upcoming
# 31-March boundary from whatever "today" is, and can be overridden from the Setup
# tab (persisted in config) so an admin can bump it forward without editing code.
def _default_fy_end_cap():
    today = datetime.datetime.now()
    year = today.year if today.month <= 3 else today.year + 1
    return datetime.datetime(year, 3, 31)

MAX_ADMISSION_DATE = _default_fy_end_cap()

def set_admission_date_cap(dt):
    """Override the AdmissionDate cap at runtime (called from Setup tab / config load)."""
    global MAX_ADMISSION_DATE
    if isinstance(dt, datetime.datetime):
        MAX_ADMISSION_DATE = dt

def admission_date_cap_str():
    return MAX_ADMISSION_DATE.strftime("%d-%m-%Y")


def sanitize_folder_name(name, max_len=15):
    if not name:
        return "PACS"
    safe = re.sub(r'[<>:"/\\|?*]', '_', str(name)).strip()
    safe = re.sub(r'[\s_]+', '_', safe)
    safe = safe.strip('_')
    if len(safe) > max_len:
        safe = safe[:max_len].rstrip('_')
    return safe if safe else "PACS"

# Valid Caste Description values (Only these are allowed) - changed "Not Applicable" to "Not Available"
VALID_CASTE_VALUES = {
    "Not Available",
    "Schedule Caste",
    "Schedule Tribe",
    "Backward Caste A",
    "Backward Caste B",
    "Backward Caste C",
    "Backward Caste D",
    "Other Backward Caste",
    "General",
    "Minorities"
}

# Filename -> internal sheet-type key
FILENAME_PATTERNS = [
    (re.compile(r"membership", re.I), "Membership"),
    (re.compile(r"personaldetail", re.I), "Membership"),
    (re.compile(r"personal detail", re.I), "Membership"),
    (re.compile(r"member detail", re.I), "Membership"),
    (re.compile(r"landdetail", re.I), "LandDetails"),
    (re.compile(r"land detail", re.I), "LandDetails"),
    (re.compile(r"loankcc", re.I), "LoanKCC"),
    (re.compile(r"loan kcc", re.I), "LoanKCC"),
    (re.compile(r"loanmt", re.I), "LoanMTLT"),
    (re.compile(r"loan mt", re.I), "LoanMTLT"),
    (re.compile(r"loanoth", re.I), "LoanOthers"),
    (re.compile(r"loan other", re.I), "LoanOthers"),
    (re.compile(r"collateral", re.I), "Collateral"),
    (re.compile(r"sbandother", re.I), "SBOthers"),
    (re.compile(r"sb other", re.I), "SBOthers"),
    (re.compile(r"fdnoncum", re.I), "FDNonCumulative"),
    (re.compile(r"fd noncum", re.I), "FDNonCumulative"),
    (re.compile(r"fdtemplate|fd template|akshaya", re.I), "FDTemplate"),
    (re.compile(r"(^|[^a-z])rd([^a-z]|$)", re.I), "RD"),
    (re.compile(r"pigmy", re.I), "Pigmy"),
    (re.compile(r"transactiondetail|loantrans", re.I), "Transactions"),
    (re.compile(r"transaction detail", re.I), "Transactions"),
    (re.compile(r"^agent", re.I), "Agent"),
    (re.compile(r"sharetrans", re.I), "ShareTrans"),
    (re.compile(r"share trans", re.I), "ShareTrans"),
    (re.compile(r"balance\s*sheet|balsheet", re.I), "BalanceSheet"),
    (re.compile(r"\bvillages?(?:[-_]?list)?\b", re.I), "VillagesRef"),
    (re.compile(r"pacs.*id.*detail", re.I), "PacsIdRef"),
]

SHEET_TYPE_LABELS = {
    "Membership": "Membership / Personal Details",
    "LandDetails": "Land Details",
    "LoanKCC": "Short Term KCC Loans",
    "LoanMTLT": "Medium/Long Term Loans (MTAP/MTNAP/LTAP/LTNAP/Vehicle/SHG...)",
    "LoanOthers": "Other Loans (Gold/Deposit Cert/Produce...)",
    "Collateral": "Gold / Collateral Details",
    "SBOthers": "SB, PD, Staff & Customer Security Deposits",
    "FDNonCumulative": "FD Non-Cumulative Deposits",
    "FDTemplate": "FD / Cash Certificate Deposits",
    "RD": "Recurring Deposits (RD)",
    "Pigmy": "Pigmy Deposits",
    "Transactions": "Loan Transaction Details",
    "Agent": "Pigmy Agent Master",
    "ShareTrans": "Share Transactions",
    "BalanceSheet": "Balance Sheet (reference only - not uploaded)",
    "VillagesRef": "Villages Reference List",
    "PacsIdRef": "PACS ID Details (Setup reference)",
    "Unknown": "Unrecognised file - please map manually",
}

# Member type priority order for keeping duplicates
MEMBER_TYPE_PRIORITY = {
    "A Type": 1,
    "B Type": 2,
    "C Type": 3,
    "D Type": 4,
    "Member": 1,
    "Nominal Member": 5,
    "Associate Member": 5,
    "Organisation": 5,
}

# ---------------------------------------------------------------------------
# 2. DEFAULT CONFIG
# ---------------------------------------------------------------------------

def _default_config():
    return {
        "version": APP_VERSION,
        "settings": {
            "dob_missing_strategy": "admission_minus_years",
            "dob_fixed_default": "01-01-1947",
            "dob_admission_minus_years": 20,
            "age_as_on": "admission_date",
            "age_as_on_custom_date": "",
            "pacs_id_details_path": "",
            "villages_ref_path": "",
            "caste_mapping_disabled": False,
        },
        "gender_map": {
            "MALE": "Male",
            "FEMALE": "Female",
            "TRANSGENDER": "Others",
            "OTHER": "Others",
            "male": "Male",
            "m": "Male",
            "female": "Female",
            "f": "Female",
            "transgender": "Others",
            "t": "Others",
            "other": "Others",
            "others": "Others",
            "not available": "Others",
            "na": "Others",
            "OTHERS": "Others",
            "COMPANY": "Others"
        },
        "customer_type_map": {
            "MEMBERS": "Member", "MEMBER": "Member",
            "NOMINAL": "Nominal Member", "NOMINAL MEMBER": "Nominal Member",
            "ORGANISATION": "Organisation", "ORGANIZATION": "Organisation",
            "ASSOCIATEMEMBER": "Associate Member", "ASSOCIATE MEMBER": "Associate Member",
            "members": "Member",
            "member": "Member",
            "nominal": "Nominal Member",
            "nominal member": "Nominal Member",
            "associate": "Associate Member",
            "associatemember": "Associate Member",
            "shg": "SHG",
            "organisation": "Organisation",
            "institution": "Organisation"
        },
        "marital_status_map": {
            "MARRIED": "Married",
            "SINGLE": "Single",
            "WIDOW": "Widow",
            "WIDOWER": "Widower",
            "DIVORCED": "Divorced",
            "married": "Married",
            "unmarried": "Unmarried",
            "single": "Unmarried",
            "widow": "Widow",
            "widower": "Widower",
            "divorced": "Divorced",
            "not available": "Not Available",
            "widow(er)": "Widow/Widower",
            "OTHERS": "Not Available",
            "NOT MARIED": "Not Available"
        },
        "marital_status_default": "Not Available",
        "community_map": {
            "HINDU": "Hindu",
            "MUSLIM": "Muslim",
            "MUSLIMS": "Muslim",
            "CHRISTIAN": "Christian",
            "CHRISTIANS": "Christian",
            "JAIN": "Jain",
            "JAINS": "Jain",
            "SIKH": "Sikh",
            "BUDDHIST": "Buddhist",
            "hindu": "Hindu",
            "muslim": "Muslim",
            "muslims": "Muslim",
            "christian": "Christian",
            "christians": "Christian",
            "jain": "Jain",
            "jains": "Jain",
            "buddhism": "Buddhism",
            "sikhism": "Sikhism",
            "not available": "Not Available",
            "zoroastrian": "Zoroastrian",
            "jews": "Jews",
            ".": "Not Available",
            "NOT KNOWN": "Not Available",
            "OTHERS": "Not Available",
            "NOT APPLICABLE": "Not Available",
            "OTHER MINORITY": "Not Available",
            "NEO BUDHIST": "Buddhist"
        },
        "member_type_map": {
            "NON MEMBER": "Non Member",
            "a class share a/c": "A Type",
            "share capital-''a'' class": "A Type",
            "share capital- '''' a''''  class": "A Type",
            "a class": "A Type",
            "a type": "A Type",
            "b class share a/c": "B Type",
            "share capital-''b'' class": "B Type",
            "b class": "B Type",
            "b type": "B Type",
            "c class share a/c": "C Type",
            "share capital-''c ''class": "C Type",
            "c class": "C Type",
            "c type": "C Type",
            "d class share a./c": "D Type",
            "share capital- '''' d''''  class": "D Type",
            "d class": "D Type",
            "d type": "D Type",
            "non member": "Nominal",
            "nominal member": "Nominal",
            "associate member": "Associate",
            "shg member": "SHG",
            "institute": "Institution",
            "A TYPE": "A Type",
            "C TYPE": "C Type",
            "D TYPE": "D Type",
            "B TYPE": "B Type"
        },
        "ration_card_type_map": {
            "PH": "Priority Household",
            "AAY": "Antyodaya Anna Yojana",
            "APL": "Above Poverty Line",
            "BPL": "Below Poverty Line",
            "AY": "Annapurna Yojna",
            "PRIORITY": "Priority Household",
            "ANTYODAYA": "Antyodaya Anna Yojana",
            "ABOVE": "Above Poverty Line",
            "BELOW": "Below Poverty Line",
            "ANNAPURNA": "Annapurna Yojna",
            "PRIORITY HOUSEHOLD": "Priority Household",
            "ANTYODAYA ANNA YOJANA": "Antyodaya Anna Yojana",
            "ABOVE POVERTY LINE": "Above Poverty Line",
            "BELOW POVERTY LINE": "Below Poverty Line",
            "ANNAPURNA YOJNA": "Annapurna Yojna",
        },
        "operation_type_map": {
            "EITHER": "Either",
            "EITHER OR SURVIVOR": "Either or Survivor",
            "FORMER OR SURVIVOR": "Former or Survivor",
            "LATER OR SURVIVOR": "Later or Survivor",
            "BOTH JOINTLY": "Both Jointly",
            "JOINT OPERATION": "Joint Operation",
            "ANY TWO JOINTLY": "Any Two Jointly",
            "OTHERS": "Others",
            "SINGLE": "Single",
            "NOT AVAILABLE": "Not Available",
            "EITHER": "Either",
            "EITHERORSURVIVOR": "Either or Survivor",
            "FORMERORSURVIVOR": "Former or Survivor",
            "LATERORSURVIVOR": "Later or Survivor",
            "BOTHJOINTLY": "Both Jointly",
            "JOINTOPERATION": "Joint Operation",
            "ANYTWOJOINTLY": "Any Two Jointly",
            "SINGLE": "Single",
            "NOTAVAILABLE": "Not Available",
            "": "Not Available",
        },
        "caste_map": {
            "BILLAVA": "Backward Caste A",
            "POOJARY": "Backward Caste A",
            "POOJARI": "Backward Caste A",
            "VISHWAKARMA": "Backward Caste A",
            "VISHVAKARMA": "Backward Caste A",
            "ACHARI": "Backward Caste A",
            "ACHARYA": "Backward Caste A",
            "MADIVALA": "Backward Caste A",
            "MADIVAL": "Backward Caste A",
            "AGASA": "Backward Caste A",
            "DEVADIGA": "Backward Caste A",
            "MOILI": "Backward Caste A",
            "SAPALYA": "Backward Caste A",
            "SHETTIGAR": "Backward Caste A",
            "SHETTYGARA": "Backward Caste A",
            "MOGAVEERA": "Backward Caste A",
            "KHARVI": "Backward Caste A",
            "BHANDARI": "Backward Caste A",
            "BHANDARY": "Backward Caste A",
            "BANDARY": "Backward Caste A",
            "KUMBARA": "Backward Caste A",
            "KULAL": "Backward Caste A",
            "MOOLYA": "Backward Caste A",
            "MANIYANI": "Backward Caste A",
            "YADAVARU": "Backward Caste A",
            "GANIGA": "Backward Caste A",
            "KOTE KSHATHRIYA": "Backward Caste A",
            "RAMAKSHATHRIYA": "Backward Caste A",
            "JOGI": "Backward Caste A",
            "KURUBA": "Backward Caste A",
            "KURUBAR": "Backward Caste A",
            "EDIGA": "Backward Caste A",
            "IDIGA": "Backward Caste A",
            "BESTA": "Backward Caste A",
            "AMBIGA": "Backward Caste A",
            "DEVANGA": "Backward Caste A",
            "NEKAR": "Backward Caste A",
            "SALI": "Backward Caste A",
            "GOWDA": "Backward Caste B",
            "GOUDA": "Backward Caste B",
            "VOKKALIGA": "Backward Caste B",
            "OKKALIGA": "Backward Caste B",
            "BUNTS": "Backward Caste B",
            "BUNT": "Backward Caste B",
            "SHETTY": "Backward Caste B",
            "RAI": "Backward Caste B",
            "HEGDE": "Backward Caste B",
            "MARATI": "Backward Caste B",
            "LINGAYAT": "Backward Caste C",
            "VEERASHAIVA": "Backward Caste C",
            "JANGAMA": "Backward Caste C",
            "KAMMARA": "Backward Caste D",
            "UPPARA": "Backward Caste D",
            "UPPAR": "Backward Caste D",
            "OBC": "Other Backward Caste",
            "OTHER BACKWARD CASTE": "Other Backward Caste",
            "PATALI": "Other Backward Caste",
            "ST": "Schedule Tribe",
            "SCHEDULE TRIBE": "Schedule Tribe",
            "VALMIKI NAYAK": "Schedule Tribe",
            "NAYAK": "Schedule Tribe",
            "NAIKA": "Schedule Tribe",
            "NAYKA": "Schedule Tribe",
            "NAYKS": "Schedule Tribe",
            "MALEKUDIYA": "Schedule Tribe",
            "LAMBANI": "Schedule Tribe",
            "BANJARA": "Schedule Tribe",
            "SOLIGA": "Schedule Tribe",
            "KORAGA": "Schedule Tribe",
            "SC": "Schedule Caste",
            "SCHEDULE CASTE": "Schedule Caste",
            "MUGERA": "Schedule Caste",
            "MOOGERA": "Schedule Caste",
            "SAMAGARA": "Schedule Caste",
            "BELCHAPADA": "Schedule Caste",
            "DAS": "Schedule Caste",
            "DASA": "Schedule Caste",
            "MADIGA": "Schedule Caste",
            "HOLEYA": "Schedule Caste",
            "BHOVI": "Schedule Caste",
            "ADI KARNATAKA": "Schedule Caste",
            "BRAHMIN": "General",
            "BRAHMIN(HAVYAKA)": "General",
            "HAVYAKA": "General",
            "BHAT": "General",
            "BHATT": "General",
            "SHENOY": "General",
            "PAI": "General",
            "KAMATH": "General",
            "BALIGA": "General",
            "RAO": "General",
            "KONKANI": "General",
            "TAMILIANS": "General",
            "KERALIANS": "General",
            "NAYAR": "General",
            "HINDU": "General",
            "HINDHU": "General",
            "GENERAL": "General",
            "IYER": "General",
            "IYENGAR": "General",
            "SMARTHA": "General",
            "MADHWA": "General",
            "BRAHMINS": "General",
            "MUSLIM": "Minorities",
            "MUSLIMS": "Minorities",
            "CHRISTIAN": "Minorities",
            "CHRISTIANS": "Minorities",
            "JAIN": "Minorities",
            "JAINS": "Minorities",
            "SYED": "Minorities",
            "KHAN": "Minorities",
            "PATHAN": "Minorities",
            "PURUSHA": "Not Available",
            "NOT KNOWN": "Not Available",
            "NOT APPLICABLE": "Not Available",
            "UNKNOWN": "Not Available",
            "NA": "Not Available",
            "N/A": "Not Available",
            "NIL": "Not Available",
            "NONE": "Not Available",
            "": "Not Available"
        },
        "farmer_type_map": {
            "MF": "Medium",
            "MEDIUM FARMER": "Medium",
            "SF": "Small",
            "SMALL FARMER": "Small",
            "SMALL/MARGINAL FARMER": "Small or Marginal",
            "MARGINAL FARMER": "Marginal",
            "BF": "Big",
            "BIG FARMER": "Big",
            "AGRI. LABOURS": "Agricultural Labour",
            "RURALARTISANS": "Rural Artisan",
            "OTHERS": "Others",
            "GENARAL": "General",
            "NOT AVAILABLE": "Not Available",
            "NOT APPLICABLE": "Not Available",
            "NA": "Not Available",
            "medium": "Others",
            "big": "Large",
            "small or marginal": "Small",
            "small or marginal farmer": "Small / Marginal",
            "not available": "Not Available",
            "mf": "Marginal",
            "bf": "Large",
            "sf": "Small",
            "agri. labours": "Agricultural Laborer",
            "ruralartisans": "Others",
            "others": "Others",
            "big farmer": "Large",
            "agri labours": "Agricultural Laborer",
            "small farmer": "Small",
            "medium farmer": "Others",
            "marginal farmer": "Large",
            "smallmarginal farmer": "Small",
            "st": "Not Available",
            "genaral": "Not Available",
            "sc": "Not Available",
            "ST": "ST",
            "3A": "3A",
            "SC": "Others",
            "SMALL\\MARGINAL FARMER": "Small / Marginal",
            "ZZZZZZZSC": "Not Available",
            "ZZZZZST": "Others"
        },
        "split_map": {
            "SBOthers": {
                "SB SAVING BANK DEPOSIT": "SB",
                "SB SAVING DEPOSITS": "SB",
                "SB SAVINGS BANK": "SB",
                "SOCSBSAVING DEPOSITS": "SB",
                "CD COMPULSORY DEPOSITS": "SB",
                "PD PERMANENT DEPOSIT": "LifeTimeDepositNonCum",
                "SPF STAFF PROVIDENT FUND": "SBPF",
                "STAFF P.F PAYABLE": "SBPF",
                "STAFF PF-  EMPLOYEE CONTRIBUTION": "SBPF",
                "STF PF DEPOSIT": "SBPF",
                "SSD STAFF SECURITY DEPOSITS": "SBStaffSecurity",
                "STAFF SECURITY DEPOSIT": "SBStaffSecurity",
                "STF SECURITY DEPOSITE": "SBStaffSecurity",
                "SECURITY DEPOSIT(JEWEL]": "SBCustomerSecurity",
                "SECURITY DEPOSIT(PIGMY)": "SBCustomerSecurity",
                "SAVING DEPOSITS": "SB",
                "SHG SAVING DEPOSITS": "SBSHG",
                "PF SB ACCOUNT": "SBPF",
                "JLG SAVING DEPOSITS": "SBJLG",
                "STAFF SECURITY DEPOSIT SB": "SBStaffSecurity",
                "CURRENT DEPOSITS": "SBCurrent",
                "SB CUSTOMER SECURITY DEPOSIT": "SBCustomerSecurity",
                "SAVING DEPOSIT GRATUTY": "SBGratuity",
                "ASSAMI DEPOSIT": "SBAssami",
                "MATURITY DEPOSIT SB": "SBMaturity",
                "LOCKER DEPOSIT SB": "SBLocker",
                "FREEZED MEMBERSHIP SB": "SBFreezed",
                "SAVING DEPOSIT INOPERATIVE": "SBInoperative",
                "SB SAVING BANK": "SB",
                "STAFF PROVIDENT FUND": "SBCustomerSecurity",
                "STAFF SECURITY DEPOSITE": "SBCustomerSecurity",
                "SAVING DEPOSIT": "SB",
                "STAFF SECURITY DEPOSITS": "SBStaffSecurity",
                "STAFF PF DEPOSITS": "SBPF",
                "COMPULSORY DEPOSITS": "SBCustomerSecurity",
                "SAVING DEPOSIT NAVODAYA SHG": "SBSHG",
                "SAVING DEPOSIT INSTITUTE": "SB",
                "SB TEMPLATE": "SB"
            },
            "LoanMTLT": {
                "LTAP LAND IMPROVEMENT LOAN": "LTAP",
                "LTNAP  STORAGE GODOWN LOAN": "LTNAP",
                "LTNAP HOUSING LOAN": "LTNAP",
                "MTAP LOAN": "MTAP",
                "MTAP PUMP  LOAN": "MTAP",
                "MTNAP LOAN": "MTNAP",
                "VEHICLE LOAN": "VehicleLoan",
                "SHG LOAN": "SHGLoan",
                "STF SALARY ADVANCE LOAN": "SalaryLoan",
                "MT MILK LOAN": "MTAP",
                "BL BUSINESS LOAN": "MTAP",
                "CATTLE SHEAD LOAN": "MTAP",
                "HOUSE HOLD DURABLE LOAN": "MTNAP",
                "MTNAP FARM HOUSE": "MTAP",
                "STAFF ADAVANCE LOAN": "SalaryLoan",
                "VL VEHICLE LOAN": "VehicleLoan",
                "LONG TERM AGRICULTURAL LOANS": "LTAP",
                "MEDIUM TERM AGRICULTURAL LOANS": "MTAP",
                "LTAP - WELL": "LTAP"
            },
            "LoanOthers": {
                "JL JEWEL LOAN": "GoldLoan",
                "DL DEPOSIT LOAN": "DepositCertLoan",
                "PL PRODUCE LOAN": "ProductPledgeLoan",
                "FERTILIZER LOAN": "ProductPledgeLoan",
                "OP OTHER PURPOSE LOAN": "ProductPledgeLoan",
                "SOLAR LOAN": "ProductPledgeLoan",
                "HOUSING LOAN": "HousingLoan",
                "JEWEL LOANS": "GoldLoan",
                "JLG LOAN": "GoldLoan",
                "LOANS AGAINST - CUMMULATIVE DEPOSIT": "DepositCertLoan",
                "LOANS AGAINST - FIXED DEPOSIT": "DepositCertLoan",
                "LOANS AGAINST - MULTIPLE DEPOSIT": "DepositCertLoan",
                "MEDIUM TERM NON AGRI. PURPOSE LOAN": "GoldLoan",
                "MORTGAGE LOAN GENERAL": "GoldLoan",
                "SHG LOANS": "GoldLoan",
                "STAFF LOAN - FESTIVAL ADVANCE": "GoldLoan",
                "STAFF LOAN - GENERAL": "GoldLoan",
                "VEHICLE LOAN": "GoldLoan",
                "CASH OVERDRAFT - INDIVIDUAL": "GoldLoan",
                "DEPOSIT LOAN - STAFF PF": "DepositCertLoan",
                "KCC - PASHU SANGOPANE": "GoldLoan",
                "LOANS AGAINST - DAILY DEPOSIT": "DepositCertLoan",
                "OTHER PURPOSE LOAN": "GoldLoan"
            },
            "Transactions": {
                "M MKCC LOAN 1": "STKCC",
                "M MKCC LOAN 2": "STKCC",
                "MKCC LOAN-2 / 2008-2011": "STKCC",
                "MKCC LOAN - 2  2016-17": "STKCC",
                "MKCC LOAN -1 / 2011-2014": "STKCC",
                "MKCC LOAN -1 2019- 20": "STKCC",
                "MKCC LOAN -2 2019-20": "STKCC",
                "LTAP LAND IMPROVEMENT LOAN": "LTAPTrans",
                "LTNAP  STORAGE GODOWN LOAN": "LTNAPTrans",
                "LTNAP HOUSING LOAN": "HousingTrans",
                "MTAP LOAN": "MTAPTrans",
                "MTAP PUMP  LOAN": "MTAPTrans",
                "MTNAP LOAN": "MTNAPTrans",
                "VEHICLE LOAN": "VehicleTrans",
                "SHG LOAN": "SHGTrans",
                "STF SALARY ADVANCE LOAN": "SalaryTrans",
                "JL JEWEL LOAN": "GoldTrans",
                "DL DEPOSIT LOAN": "DepositCertTrans",
                "PL PRODUCE LOAN": "ProductPledgeTrans",
                "MT MILK LOAN": "MTAPTrans",
                "BL BUSINESS LOAN": "MTAPTrans",
                "CATTLE SHEAD LOAN": "MTAPTrans",
                "FERTILIZER LOAN": "MTAPTrans",
                "HOUSE HOLD DURABLE LOAN": "MTAPTrans",
                "LTAP AGRI- DEVELOPMENT LOAN": "MTNAPTrans",
                "LTAP FARMHOUSE LOAN": "MTNAPTrans",
                "LTAP PUMPSET LOAN": "MTNAPTrans",
                "MKCC LOAN 3": "ProductPledgeTrans",
                "MKCC LOAN 1": "LTNAPTrans",
                "MKCC LOAN 2": "MTNAPTrans",
                "MTNAP FARM HOUSE": "GoldTrans",
                "OP OTHER PURPOSE LOAN": "DepositCertTrans",
                "SALARY SECURITYLOAN": "ProductPledgeTrans",
                "SOLAR LOAN": "GoldTrans",
                "STAFF ADAVANCE LOAN": "DepositCertTrans",
                "STAFF PF LOAN": "GoldTrans",
                "VL VEHICLE LOAN": "VehicleTrans",
                "SHG LOANS": "SHGTrans",
                "JEWEL LOANS": "GoldTrans",
                "STAFF LOAN - DOMESTIC": "SalaryTrans",
                "HOUSING LOAN": "HousingTrans",
                "SALARY LOAN": "SalaryTrans",
                "PRODUCE LOAN": "ProductPledgeTrans",
                "SHORT TERM OTHER PURPOSE LOAN": "STKCC",
                "MEDIUM TERM NON AGRI. PURPOSE LOAN": "STKCC",
                "LONG TERM AGRICULTURAL LOANS": "LTAPTrans",
                "MORTGAGE LOAN (AGRI.DEVELOPMENT)": "LTAPTrans",
                "LOANS AGAINST - DAILY DEPOSIT": "LTAPTrans",
                "LOANS AGAINST - FIXED DEPOSIT": "DepositCertTrans",
                "LOANS AGAINST - CUMMULATIVE DEPOSIT": "DepositCertTrans",
                "LOANS AGAINST - MULTIPLE DEPOSIT": "DepositCertTrans",
                "KCC DAIRY WORKING CAPITAL LOAN": "STKCC",
                "MKCC LOAN 1 GENERAL INTEREST": "STKCC",
                "MKCC LOAN 2 GENERAL INTEREST": "STKCC",
                "MKCC LOANS": "STKCC",
                "CASH OVERDRAFT - INDIVIDUAL": "STKCC",
                "MKCC LOANS 2": "STKCC",
                "MEDIUM TERM AGRICULTURAL LOANS": "MTNAPTrans",
                "MORTGAGE LOAN GENERAL": "STKCC",
                "STAFF LOAN - GENERAL": "STKCC",
                "STAFF LOAN - FESTIVAL ADVANCE": "STKCC",
                "JLG LOAN": "STKCC",
                "DEPOSIT LOAN - STAFF PF": "DepositCertTrans",
                "OTHER PURPOSE LOAN": "STKCC",
                "LTAP - WELL": "LTAPTrans",
                "KCC - PASHU SANGOPANE": "STKCC",
                "NAVODAYA SHG LOANS": "SHGTrans",
                "LAND DEVELOPMENT AND WELL LOANS": "STKCC",
                "LOANS AGAINST - RD": "STKCC",
                "AKSHAYA LOAN": "STKCC",
                "MT LT WELL": "STKCC",
                "MORTGAGE LOAN (OTHERS)": "STKCC",
                "MT PUMPSET LOANS": "STKCC"
            },
            "FDNonCumulative": {
                "FD FIXED DEPOSIT": "TermDepositNonCum",
                "FD FIXED DEPOSITE": "TermDepositNonCum",
                "FIXED DEPOSITS": "TermDepositNonCum",
                "FIXED DEPOSITS SOCIETIES": "TermDepositNonCum"
            },
            "FDTemplate": {
                "AKSHAYA CASH CERTIFICATE": "CashCertificate",
                "REINVESTMENT DEPOSITS": "CashCertificate",
                "SAMRUDHI CASH CERTIFICATE": "CashCertificate",
                "SAMRUDHI CASH CERTIFICATE -DOUBLING": "CashCertificate",
                "RECURRING DEPOSIT": "CashCertificate",
                "CASH CERTIFICATE - DOUBLING": "CashCertificate",
                "STAFF SECURITY DEPOSITS": "CashCertificate",
                "STAFF PF DEPOSITS": "CashCertificate",
                "DHANALAKSHMI CASH CERTIFICATE_X000D_": "CashCertificate",
                "AKSHAYA CASH CERTIFICATE - DOUBLING": "CashCertificate"
            }
        },
        "split_hints": {
            "SBOthers": {
                "SBPF": ["PF"],
                "SBStaffSecurity": ["STAFF", "SECURITY"],
                "SBCustomerSecurity": ["SECURITY"],
                "LifeTimeDepositNonCum": ["PERMANENT"],
                "SB": ["SAVING"],
                "SBSHG": ["SHG"],
                "SBJLG": ["JLG"],
                "SBCurrent": ["CURRENT"],
                "SBGratuity": ["GRATU"],
                "SBAssami": ["ASSAMI"],
                "SBMaturity": ["MATURITY"],
                "SBLocker": ["LOCKER"],
                "SBFreezed": ["FREEZ"],
                "SBInoperative": ["INOPERATIVE"]
            },
            "LoanMTLT": {
                "LTAP": ["LTAP"],
                "LTNAP": ["LTNAP"],
                "MTAP": ["MTAP"],
                "MTNAP": ["MTNAP"],
                "VehicleLoan": ["VEHICLE"],
                "SHGLoan": ["SHG"],
                "SalaryLoan": ["SALARY"]
            },
            "LoanOthers": {
                "GoldLoan": ["JEWEL"],
                "DepositCertLoan": ["DEPOSIT"],
                "ProductPledgeLoan": ["PRODUCE"]
            },
            "Transactions": {
                "STKCC": ["KCC"],
                "LTAPTrans": ["LTAP"],
                "LTNAPTrans": ["LTNAP"],
                "MTAPTrans": ["MTAP"],
                "MTNAPTrans": ["MTNAP"],
                "VehicleTrans": ["VEHICLE"],
                "SHGTrans": ["SHG"],
                "SalaryTrans": ["SALARY"],
                "GoldTrans": ["JEWEL"],
                "DepositCertTrans": ["DEPOSIT"],
                "ProductPledgeTrans": ["PRODUCE"],
                "HousingTrans": ["HOUSING"]
            }
        },
        "land_ownership_type_map": {
            "TENANT FARMERS": "Tenant Farmers",
            "SHARECROPPERS": "ShareCroppers",
            "OWNER": "Owner",
            "ORAL LESSEES": "Oral Lessees"
        },
        "irrigation_type_map": {
            "TANK": "Tank",
            "WELL": "Well",
            "CANAL": "Canal",
            "NOT AVAILABLE": "Not Available",
            "OTHERS": "Others"
        },
        "land_type_map": {
            "WET": "Wet",
            "DRY": "Dry",
            "NOT AVAILABLE": "Not Available"
        },
        "soil_type_map": {
            "LATERITE SOIL": "Laterite Soil",
            "BLACK SOIL": "Black Soil",
            "RED SOIL": "Red Soil",
            "YELLOW SOIL": "Yellow Soil",
            "SALINE SOIL": "Saline Soil",
            "ALLUVIAL SOIL": "Alluvial Soil",
            "DESERT SOIL": "Desert Soil",
            "MOUNTAIN SOIL": "Mountain Soil",
            "PEAT SOIL": "Peat Soil",
            "NOT AVAILABLE": "Not Available"
        },
        "custom_template_routes": {}
    }


# ---------------------------------------------------------------------------
# 3. DATE FORMATTING FUNCTIONS
# ---------------------------------------------------------------------------

def format_date_to_ddmmyyyy(v):
    """Convert any date to DD-MM-YYYY format."""
    if is_blank(v):
        return ""
    try:
        if isinstance(v, datetime.datetime):
            return v.strftime("%d-%m-%Y")
        if isinstance(v, pd.Timestamp):
            return v.strftime("%d-%m-%Y")
        parsed = pd.to_datetime(v, errors='coerce', dayfirst=True)
        if pd.notna(parsed):
            return parsed.strftime("%d-%m-%Y")
        # If it's already in DD/MM/YYYY format, convert to DD-MM-YYYY
        if re.match(r'^\d{2}/\d{2}/\d{4}$', str(v)):
            parts = str(v).split('/')
            return f"{parts[0]}-{parts[1]}-{parts[2]}"
        return str(v)
    except Exception:
        return str(v)


def parse_date_from_string(v):
    """Parse date from string in various formats."""
    if is_blank(v):
        return None
    try:
        if isinstance(v, datetime.datetime):
            return v
        if isinstance(v, pd.Timestamp):
            return v.to_pydatetime()
        s = str(v).strip()
        # Try DD-MM-YYYY
        m = re.match(r'^(\d{2})-(\d{2})-(\d{4})$', s)
        if m:
            return datetime.datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        # Try DD/MM/YYYY
        m = re.match(r'^(\d{2})/(\d{2})/(\d{4})$', s)
        if m:
            return datetime.datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        # Try YYYY-MM-DD
        m = re.match(r'^(\d{4})-(\d{2})-(\d{2})$', s)
        if m:
            return datetime.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        return pd.to_datetime(v, errors='coerce', dayfirst=True).to_pydatetime()
    except Exception:
        return None


def validate_admission_date(admission_date_str):
    """Validate that AdmissionDate is not greater than 31-03-2026."""
    if is_blank(admission_date_str):
        return False
    parsed = parse_date_from_string(admission_date_str)
    if parsed:
        return parsed <= MAX_ADMISSION_DATE
    return False


def adjust_admission_date(admission_date_str):
    """Adjust AdmissionDate to the configured cap if it's greater."""
    if is_blank(admission_date_str):
        return admission_date_cap_str()
    parsed = parse_date_from_string(admission_date_str)
    if parsed and parsed > MAX_ADMISSION_DATE:
        return admission_date_cap_str()
    return format_date_to_ddmmyyyy(admission_date_str)


def normalize_caste_description(raw_caste, caste_map):
    """
    Normalize caste description using the caste_map.
    Returns the mapped value if found, otherwise "Not Available".
    """
    if is_blank(raw_caste):
        return "Not Available"
    
    # Clean the raw value
    clean_val = str(raw_caste).strip().upper()
    # Remove extra spaces
    clean_val = RE_MULTISPACE.sub(" ", clean_val)
    
    # Check if exact match exists in caste_map
    if clean_val in caste_map:
        mapped = caste_map[clean_val]
        # Ensure the mapped value is in the valid set
        if mapped in VALID_CASTE_VALUES:
            return mapped
        else:
            return "Not Available"
    
    # Try partial match (if any key is contained in the raw value)
    for key, value in caste_map.items():
        if key in clean_val or clean_val in key:
            if value in VALID_CASTE_VALUES:
                return value
    
    # Check if raw value is already a valid caste description
    if clean_val in VALID_CASTE_VALUES:
        return clean_val
    
    # Special handling for common patterns
    if "SC" in clean_val or "SCHEDULE CASTE" in clean_val:
        return "Schedule Caste"
    if "ST" in clean_val or "SCHEDULE TRIBE" in clean_val:
        return "Schedule Tribe"
    if "OBC" in clean_val or "OTHER BACKWARD" in clean_val:
        return "Other Backward Caste"
    if "GENERAL" in clean_val:
        return "General"
    if "MINOR" in clean_val:
        return "Minorities"
    
    # Default to Not Available
    return "Not Available"


# ---------------------------------------------------------------------------
# 4. TEMPLATE DEFINITIONS (only used for Membership now; raw files are not mapped)
# ---------------------------------------------------------------------------

TEMPLATES = {
    "Membership": {
        "Membership": {
            "file": "MembershipTemplate.xlsx",
            "confidence": "verified",
            "columns": [
                "CustomerTypeDescription", "MemberTypeDescription", "AdmissionNo",
                "MemberSurName", "MemberName", "MiddleName", "FatherName", "SpouseName",
                "MemberNameRegional", "FatherNameinRegional", "SpouseNameinRegional",
                "DOB", "AGE", "AdmissionDate", "GenderDescription", "MaritalStatusDesc",
                "CommunityDescription", "CasteDescription", "FarmerTypeDescription",
                "Address1", "Address2", "VillageDescription", "LedgerFolioNo",
                "ContactNo", "ShareBalance", "ThriftBalance", "DividentBalance",
                "AdhaarCardNo", "DCCBSBACNO", "PacsIDPKey", "BranchId", "GroupCode",
                "GroupBranchCode", "GroupBranchIFSC", "PacsCode", "GroupTypeDescription",
                "GroupLocationDescription", "GroupBlockCode", "GroupGPCode",
                "GroupULBCode", "GroupCategoryDescription", "GroupNRLMCategoryDescription",
                "GroupMemberCount", "FruitsID", "CasteCertificationNo", "YeshashiviNo",
                "PANCardNo", "VoterID", "DrivingLicenceNo", "PassportNo",
                "RationCardTypeDesc", "RationCardNo", "GPAIssueDate",
                "GPACertificationNo", "GPAReferenceAdmissionNo"
            ],
        },
    },
}

MANDATORY_FIELDS = {
    "Membership": ["AdmissionNo", "MemberName", "GenderDescription", "VillageDescription"],
}

DEDUPE_KEYS = {
    "Membership": ["AdmissionNo"],
}

# ---------------------------------------------------------------------------
# 5. CONFIG LOAD / SAVE
# ---------------------------------------------------------------------------

def config_path_for(base_dir):
    return os.path.join(base_dir, CONFIG_FILENAME)


def load_config(base_dir):
    path = config_path_for(base_dir)
    cfg = _default_config()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                user_cfg = json.load(f)
            cfg = _deep_merge(cfg, user_cfg)
        except Exception:
            pass
    return cfg


def save_config(base_dir, cfg):
    path = config_path_for(base_dir)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def _deep_merge(base, override):
    out = dict(base)
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


# ---------------------------------------------------------------------------
# 6. CLEANING / VALIDATION HELPERS
# ---------------------------------------------------------------------------

def is_blank(v):
    if v is None:
        return True
    # pd.isna() catches pandas NaT (Not-a-Time), NaN, and pd.NA in one go -- these are all common
    # when a source column happens to be read with a datetime/numeric dtype. The check below this one
    # (isinstance float + np.isnan) does NOT catch NaT, and critically, bool(pd.NaT) is True in Python,
    # so before this fix a blank DOB read as NaT was silently treated as "present" everywhere -- the
    # DOB-defaulting logic never ran, and the blank literally leaked into output as the text "NaT".
    try:
        if pd.isna(v):
            return True
    except (TypeError, ValueError):
        pass  # pd.isna() can't evaluate some types (e.g. arrays) -- fall through to the string checks
    if isinstance(v, float) and np.isnan(v):
        return True
    s = str(v).strip()
    return s == "" or s.lower() in ("nan", "nat") or s == "."


def norm_key(v):
    if is_blank(v):
        return ""
    s = str(v).strip().upper()
    s = RE_MULTISPACE.sub(" ", s)
    return s


def strip_all_spaces(v):
    if is_blank(v):
        return ""
    return RE_MULTISPACE.sub("", str(v).strip())


def clean_name_field(v):
    """Clean name fields - remove special chars, numbers, replace & with 'And'."""
    if is_blank(v):
        return ""
    s = str(v)
    # Replace & with And
    s = s.replace('&', ' And ')
    # Remove numbers
    s = re.sub(r'\d+', ' ', s)
    # Keep only letters, spaces, and hyphens
    s = re.sub(r'[^A-Za-z\s\-]', ' ', s)
    # Remove multiple spaces
    s = RE_MULTISPACE.sub(" ", s).strip()
    # Remove leading/trailing hyphens
    s = s.strip('-')
    return s


def clean_special_chars(v):
    """Remove ALL special characters from text fields."""
    if is_blank(v):
        return ""
    s = str(v)
    # Remove all special characters
    s = re.sub(r'[^A-Za-z0-9\s\-]', ' ', s)
    # Remove multiple spaces
    s = RE_MULTISPACE.sub(" ", s).strip()
    return s


def clean_id_field(v):
    """Clean ID fields: remove special chars and spaces."""
    if is_blank(v):
        return ""
    s = str(v)
    # Keep only alphanumeric
    s = re.sub(r'[^A-Za-z0-9]', '', s)
    return s


def clean_mobile_number(v):
    """Clean mobile number: handle +91, 91, leading zeros, and slashes."""
    if is_blank(v):
        return ""
    s = str(v).strip()
    # If contains slash, take the first part (before slash)
    if '/' in s:
        s = s.split('/')[0].strip()
    # Remove all non-digits
    s = re.sub(r'\D', '', s)
    # Remove leading zeros
    s = s.lstrip('0')
    # If length > 10 and starts with 91, remove 91
    if len(s) == 12 and s.startswith('91'):
        s = s[2:]
    # If length is 10, keep
    if len(s) == 10:
        return s
    else:
        return ""  # invalid


def clean_voter_id(v):
    """Clean Voter ID - remove slashes and spaces."""
    if is_blank(v):
        return ""
    s = str(v).strip()
    # Remove slashes
    s = s.replace('/', '')
    # Remove spaces
    s = RE_MULTISPACE.sub("", s)
    return s.upper()


def parse_father_spouse(raw_father_name):
    """Parse FatherName to extract gender info and clean names."""
    if is_blank(raw_father_name):
        return "", "", None
    
    s = str(raw_father_name).strip()
    
    # Check for W/O (Wife of) - Female
    m = RE_WO.match(s)
    if m:
        spouse = RE_WO.sub("", s).strip()
        return "", clean_name_field(spouse), "Female"
    
    # Check for H/O (Husband of) - Male
    m = RE_HO.match(s)
    if m:
        spouse = RE_HO.sub("", s).strip()
        return "", clean_name_field(spouse), "Male"
    
    # Check for D/O (Daughter of) - Female
    m = RE_DO.match(s)
    if m:
        father = RE_DO.sub("", s).strip()
        return clean_name_field(father), "", "Female"
    
    # Check for S/O (Son of) - Male
    m = RE_SO.match(s)
    if m:
        father = RE_SO.sub("", s).strip()
        return clean_name_field(father), "", "Male"
    
    # Check for C/O (Care Of) - No gender
    m = RE_CO.match(s)
    if m:
        father = RE_CO.sub("", s).strip()
        return clean_name_field(father), "", None
    
    # No prefix - clean the name
    return clean_name_field(s), "", None


def infer_gender_from_name(father_name, spouse_name, member_name):
    """Infer gender from name patterns."""
    gender_from_father = None
    gender_from_spouse = None
    gender_from_member = None
    
    # Check FatherName patterns
    if not is_blank(father_name):
        s = str(father_name).strip().upper()
        if re.search(r"S/?\s*O", s):
            gender_from_father = "Male"
        elif re.search(r"D/?\s*O", s):
            gender_from_father = "Female"
        elif re.search(r"W/?\s*O", s):
            gender_from_father = "Female"
        elif re.search(r"H/?\s*O", s):
            gender_from_father = "Male"
        elif re.search(r"(BAI|DEVI|MAI|KUMARI|BEN)$", s):
            gender_from_father = "Female"
    
    # Check SpouseName
    if not is_blank(spouse_name):
        s = str(spouse_name).strip().upper()
        if re.search(r"W/?\s*O", s):
            gender_from_spouse = "Female"
        elif re.search(r"H/?\s*O", s):
            gender_from_spouse = "Male"
        elif re.search(r"(BAI|DEVI|MAI|KUMARI|BEN)$", s):
            gender_from_spouse = "Female"
        else:
            gender_from_spouse = "Male"  # If someone has a spouse name, they're likely male
    
    # Check MemberName
    if not is_blank(member_name):
        s = str(member_name).strip().upper()
        if re.search(r"(BAI|DEVI|MAI|KUMARI|BEN)$", s):
            gender_from_member = "Female"
    
    # Return the first non-None gender (priority: father > spouse > member)
    return gender_from_father or gender_from_spouse or gender_from_member


def parse_default_dob(settings, admission_date):
    strategy = settings.get("dob_missing_strategy", "fixed")
    if strategy == "admission_minus_years" and pd.notna(admission_date):
        years = int(settings.get("dob_admission_minus_years", 20))
        try:
            return admission_date.replace(year=admission_date.year - years)
        except ValueError:
            return admission_date.replace(year=admission_date.year - years, day=28)
    fixed = settings.get("dob_fixed_default", "01-01-1947")
    try:
        return datetime.datetime.strptime(fixed, "%d-%m-%Y")
    except Exception:
        return datetime.datetime(1947, 1, 1)


def compute_age(dob, settings, admission_date):
    if pd.isna(dob):
        return None
    as_on = settings.get("age_as_on", "admission_date")
    if as_on == "admission_date" and pd.notna(admission_date):
        ref = admission_date
    elif as_on == "custom" and settings.get("age_as_on_custom_date"):
        try:
            ref = datetime.datetime.strptime(settings["age_as_on_custom_date"], "%d-%m-%Y")
        except Exception:
            ref = datetime.datetime.today()
    else:
        ref = datetime.datetime.today()
    try:
        age = ref.year - dob.year - ((ref.month, ref.day) < (dob.month, dob.day))
    except Exception:
        return None
    return max(age, 0)


def validate_pan(v):
    if is_blank(v): return True
    s = strip_all_spaces(v).upper()
    return bool(RE_PAN.match(s))


def validate_aadhar(v):
    if is_blank(v): return True
    s = strip_all_spaces(v)
    if s.endswith('.0'):
        s = s[:-2]
    if len(s) == 12 and s.isdigit():
        return bool(RE_AADHAR.match(s)) and verhoeff_checksum_valid(s)
    return False


def validate_mobile(v):
    if is_blank(v): return True
    s = clean_mobile_number(v)
    if len(s) != 10:
        return False
    return bool(RE_MOBILE.match(s))


def validate_voterid(v):
    if is_blank(v): return True
    s = clean_voter_id(v)
    return bool(RE_VOTERID.match(s))


def validate_alpha_space(v):
    if is_blank(v): return True
    return bool(re.match(r"^[A-Za-z\s\-]+$", str(v).strip()))


def validate_numeric(v):
    if is_blank(v): return True
    return bool(re.match(r"^\d+(\.\d+)?$", str(v).strip()))


def validate_date(v):
    if is_blank(v): return True
    return pd.notna(pd.to_datetime(v, errors='coerce', dayfirst=True))


def validate_past_date(v):
    if is_blank(v): return True
    parsed = pd.to_datetime(v, errors='coerce', dayfirst=True)
    if pd.isna(parsed): return False
    return parsed <= pd.Timestamp.now()


def validate_ifsc(v):
    if is_blank(v): return True
    return bool(RE_IFSC.match(strip_all_spaces(v).upper()))


def normalize_member_type(raw):
    if is_blank(raw):
        return ""
    s = str(raw).upper()
    # Confirmed against real data: some PACS genuinely use an "E CLASS" membership tier beyond the
    # standard A-D (55 real members in one dataset), which this only matched up to D before -- E class
    # rows were falling through to a different, less clean formatting path than A-D got, so the same
    # member classification looked inconsistent in the output for no real reason.
    m = re.search(r"\b([A-E])\s*[\'\"]*\s*CLASS", s)
    if m:
        return f"{m.group(1)} Type"
    m = re.search(r"CLASS\s+([A-E])\b", s)
    if m:
        return f"{m.group(1)} Type"
    return None


def get_member_type_priority(member_type):
    """Get priority number for member type (lower = higher priority)"""
    if not member_type:
        return 5
    for key, priority in MEMBER_TYPE_PRIORITY.items():
        if key.lower() in str(member_type).lower():
            return priority
    return 5


def normalize_farmer_type(raw, ctx, rownum, admission_no, member_name):
    """Normalize farmer type. CONFIRMED with the bank: only 4 values are valid for upload --
    Big, Medium, Small Or Marginal, Not Available. Anything that isn't a farm-size classification
    (e.g. source values like "OTHERS" or "AGRI. LABOURS", which are common and legitimate -- most
    PACS members are not size-classified farmers) correctly becomes "Not Available"; that is the
    intended, correct behaviour for this field, not a bug or data loss. (An earlier version of this
    function introduced "Others" and "Agricultural Labour" as extra output categories based on a
    guess about what the target system might accept -- that guess was wrong and has been reverted.)
    Every row that lands on "Not Available" for a reason other than a truly blank source value is
    still logged to the validation report, purely so it's visible *why* (blank vs. "OTHERS" vs. an
    unrecognized value) -- not because any of those need fixing."""
    if is_blank(raw):
        return "Not Available"

    s = str(raw).strip().upper()

    if re.search(r'\bBIG\b|BF\b', s):
        return "Big"
    elif re.search(r'\bMEDIUM\b|MF\b', s):
        return "Medium"
    elif re.search(r'\bSMALL\b|SF\b|MARGINAL\b', s):
        return "Small Or Marginal"
    else:
        ctx.add_issue("Membership", "Farmer Type Normalized",
                      f"AdmNo:{admission_no} Name:{member_name} - '{raw}' -> 'Not Available' "
                      f"(not a farm-size classification -- this is expected, not an error)", rownum)
        return "Not Available"


VALIDATORS = {
    "mobile": validate_mobile,
    "aadhar": validate_aadhar,
    "pan": validate_pan,
    "voterid": validate_voterid,
    "name_format": validate_alpha_space,
    "number_format": validate_numeric,
    "date_format": validate_date,
    "past_date": validate_past_date,
    "ifsc": validate_ifsc
}

COLUMN_RULES = {
    "MemberName": "name_format",
    "MemberSurName": "name_format",
    "FatherName": "name_format",
    "SpouseName": "name_format",
    "ContactNo": "mobile",
    "AdhaarCardNo": "aadhar",
    "PANCardNo": "pan",
    "VoterID": "voterid",
    "GroupBranchIFSC": "ifsc",
    "ShareBalance": "number_format",
    "ThriftBalance": "number_format",
    "DividentBalance": "number_format",
    "DOB": "past_date",
    "AdmissionDate": "date_format",
    "SanctionedDate": "past_date",
    "DepositDate": "past_date",
    "MaturityDate": "date_format",
    "DueDate": "date_format"
}

COLUMN_LENGTHS = {
    "Address1": 100,
    "Address2": 100,
    "MemberName": 50,
    "MemberSurName": 50,
    "VillageDescription": 50,
    "AccountNo": 20,
    "LoanNo": 20,
    "ContactNo": 10
}

# ---------------------------------------------------------------------------
# 7. ROBUST FILE READER
# ---------------------------------------------------------------------------

def read_any_table(path):
    """Tries several ways to read a source file, in order of how likely each is to be correct for a
    real banking-system export, and reports the most USEFUL error if every attempt fails.

    Historical bug fixed here: this used to overwrite `last_err` on every attempt including the very
    last one (a plain-text CSV read), so if a genuine Excel file failed for some Excel-specific reason,
    the error actually shown to the person was "'utf-8' codec can't decode byte 0xd0..." -- which is
    just what happens when you try to read ANY binary .xls file (old-format Excel files start with the
    bytes D0 CF 11 E0, the OLE2 compound-file signature) as if it were plain UTF-8 text. That error is
    real but useless -- it says nothing about why the actual Excel-reading attempts failed. Now the
    original Excel-read error is preserved and shown, since that's almost always the one that actually
    explains the problem.
    """
    excel_err = None
    for engine in (None, "openpyxl", "xlrd"):
        try:
            if engine:
                return pd.read_excel(path, header=0, engine=engine)
            return pd.read_excel(path, header=0)
        except Exception as e:
            if excel_err is None:
                excel_err = e  # keep the FIRST (usually most relevant) Excel-reading failure

    # Many real-world banking/MIS "export to Excel" tools (older VB6/ASP/Crystal Reports systems
    # especially) write a .xls file that's slightly non-conformant to the strict OLE2/BIFF spec --
    # Excel itself opens these without complaint, but xlrd's default strict parsing rejects them.
    # xlrd has a specific, safe relaxed-parsing mode for exactly this; try it directly (pandas'
    # read_excel doesn't expose this option) before giving up on the file being real Excel data.
    # NOTE: this flag only guards ONE of several internal corruption checks in xlrd (the one in
    # _locate_stream) -- a defect in a different check (_get_stream, used while walking the
    # directory/short-stream tables) is NOT covered by this flag at all and will still raise. The two
    # fallbacks below exist specifically for that harder case.
    try:
        import xlrd
        book = xlrd.open_workbook(path, ignore_workbook_corruption=True, logfile=open(os.devnull, "w"))
        sheet = book.sheet_by_index(0)
        rows = [[sheet.cell_value(r, c) for c in range(sheet.ncols)] for r in range(sheet.nrows)]
        if rows:
            return pd.DataFrame(rows[1:], columns=rows[0])
    except Exception:
        pass  # fall through to the stronger repair attempts below

    # Stronger repair attempt #1 (pure Python, no external program needed): olefile is a different,
    # independently-written OLE2 parser with its own, more configurable defect tolerance. If IT can
    # walk the sector chain and extract the raw "Workbook"/"Book" stream even where xlrd's stricter
    # internal check refused to, we can hand those raw bytes straight to xlrd -- confirmed by reading
    # xlrd's own source: xlrd.book.Book.biff2_8_load() checks whether the bytes it's given start with
    # the OLE2 signature, and if not, treats them as an already-extracted raw BIFF stream and skips its
    # own OLE2/FAT-walking entirely. That's exactly what we want once olefile has done the extraction.
    try:
        import olefile
        import xlrd
        ole = olefile.OleFileIO(path, raise_defects=olefile.DEFECT_FATAL)
        stream_name = "Workbook" if ole.exists("Workbook") else ("Book" if ole.exists("Book") else None)
        if stream_name:
            raw_biff = ole.openstream(stream_name).read()
            ole.close()
            book = xlrd.open_workbook(file_contents=raw_biff, ignore_workbook_corruption=True, logfile=open(os.devnull, "w"))
            sheet = book.sheet_by_index(0)
            rows = [[sheet.cell_value(r, c) for c in range(sheet.ncols)] for r in range(sheet.nrows)]
            if rows:
                return pd.DataFrame(rows[1:], columns=rows[0])
        else:
            ole.close()
    except Exception:
        pass  # fall through to the LibreOffice-based attempt

    # Some files (confirmed on real project reference files) are plain tab-separated text saved with
    # an .xls extension, prefixed with a "## Sheet: ..." marker line and a blank line before the real
    # header -- skip past those before parsing, or the marker line gets mistaken for the header. This
    # is tried BEFORE the LibreOffice fallback below: plain delimited-text parsing is cheap and
    # deterministic for a file that's actually text, whereas LibreOffice's own "recognize almost
    # anything" import behavior was confirmed to misinterpret this exact format (silently "succeeding"
    # with a wrong 1-2 column result, so its accurate error handling below never even ran) if given
    # first crack at it.
    skiprows = 0
    try:
        with open(path, "r", errors="replace") as f:
            peek_lines = [f.readline() for _ in range(3)]
        if peek_lines and peek_lines[0].strip().startswith("##"):
            skiprows = 1
            if len(peek_lines) > 1 and not peek_lines[1].strip():
                skiprows = 2
    except Exception:
        pass

    text_err = None
    for encoding in ("utf-8", "cp1252", "latin-1"):
        for sep in ("\t", ",", ";"):
            try:
                df = pd.read_csv(path, sep=sep, header=0, engine="python", encoding=encoding, skiprows=skiprows)
                if df.shape[1] > 1:
                    return df
            except Exception as e:
                text_err = e

    # Stronger repair attempt #2: if LibreOffice is installed on this machine, its own Excel-file
    # parser is well known to tolerate structural defects that both xlrd and Excel itself can be
    # picky about. Only attempted if soffice/libreoffice is actually found -- this never requires
    # installing anything to reach this point, it just won't help if it's not already present.
    soffice_path = _find_soffice_binary()
    if soffice_path:
        try:
            import subprocess, tempfile
            with tempfile.TemporaryDirectory() as tmpdir:
                result = subprocess.run(
                    [soffice_path, "--headless", "--convert-to", "xlsx", "--outdir", tmpdir, path],
                    capture_output=True, timeout=60,
                )
                converted = os.path.join(tmpdir, os.path.splitext(os.path.basename(path))[0] + ".xlsx")
                if os.path.exists(converted):
                    df = pd.read_excel(converted, header=0, engine="openpyxl")
                    return df
        except Exception:
            pass  # fall through to the final error

    try:
        tables = pd.read_html(path)
        if tables:
            return tables[0]
    except Exception:
        pass

    libreoffice_note = ("" if soffice_path else
        "\nNote: LibreOffice was not found on this machine -- installing it (free, from "
        "libreoffice.org) sometimes lets this tool recover files that are otherwise unreadable, "
        "since its Excel-file parser tolerates more structural quirks than the alternatives.")
    raise ValueError(
        f"Could not read '{os.path.basename(path)}' as an Excel file or as delimited text, even "
        f"after trying several repair strategies.\n"
        f"  Excel-reading error: {excel_err}\n"
        f"  Text-reading error: {text_err}\n"
        f"This usually means the file is genuinely corrupted, password-protected, or in a format "
        f"this tool doesn't recognize (e.g. a very old Excel 4/5 .xls, or an encrypted workbook) -- "
        f"try opening it in Excel and re-saving it (File > Save As > Excel Workbook) to get a clean "
        f"copy.{libreoffice_note}"
    )


def _find_soffice_binary():
    """Looks for a LibreOffice/OpenOffice install in the usual places on Windows, Mac, and Linux.
    Returns the executable path if found, else None -- callers should treat None as "skip this
    fallback," not as an error, since most machines won't have it installed and that's fine."""
    import shutil
    for name in ("soffice", "soffice.exe", "libreoffice"):
        found = shutil.which(name)
        if found:
            return found
    candidates = [
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        "/usr/bin/soffice",
        "/usr/lib/libreoffice/program/soffice",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return None


ARCHIVE_EXTENSIONS = (".zip", ".rar")


def extract_archive_to_temp(archive_path, dest_dir):
    """Extracts a .zip (always supported, pure Python) or .rar (needs an external unrar/7z tool --
    most bank PCs won't have one installed, so this is best-effort with a clear message rather than a
    silent failure) into dest_dir. Returns (list_of_extracted_file_paths, warning_message_or_None).
    Only returns files with a real spreadsheet extension -- skips folders, hidden/system files, and
    anything that clearly isn't a source data file, so a zip containing a mix of the DCT output and
    other junk doesn't flood the Source Files list with irrelevant entries."""
    import zipfile as _zipfile
    ext = os.path.splitext(archive_path)[1].lower()
    extracted = []
    warning = None

    if ext == ".zip":
        try:
            with _zipfile.ZipFile(archive_path) as zf:
                for member in zf.namelist():
                    if member.endswith("/") or os.path.basename(member).startswith((".", "~$")):
                        continue
                    if not member.lower().endswith((".xls", ".xlsx", ".xlsm")):
                        continue
                    target = os.path.join(dest_dir, os.path.basename(member))
                    base, extn = os.path.splitext(target)
                    n = 1
                    while os.path.exists(target):
                        target = f"{base}_{n}{extn}"
                        n += 1
                    with zf.open(member) as src, open(target, "wb") as dst:
                        dst.write(src.read())
                    extracted.append(target)
        except Exception as e:
            warning = f"Could not read this .zip file: {e}"
    elif ext == ".rar":
        try:
            import rarfile
        except ImportError:
            return [], ("RAR support needs the 'rarfile' Python package, which isn't installed. "
                        "Easiest fix: re-zip the files as a .zip instead (Windows can do this "
                        "natively -- right-click the folder -> Send to -> Compressed (zipped) folder).")
        try:
            rf = rarfile.RarFile(archive_path)
        except Exception as e:
            return [], (
                f"Could not open this .rar file ({e}). RAR extraction needs a helper program "
                f"(unrar, 7-Zip, or The Unarchiver) installed on this computer -- most PCs don't have "
                f"one by default. Easiest fix: re-zip the files as a .zip instead (Windows can do "
                f"this natively -- right-click the folder -> Send to -> Compressed (zipped) folder), "
                f"or install 7-Zip (free, from 7-zip.org) and try again."
            )
        try:
            for member in rf.namelist():
                if member.endswith("/") or os.path.basename(member).startswith((".", "~$")):
                    continue
                if not member.lower().endswith((".xls", ".xlsx", ".xlsm")):
                    continue
                target = os.path.join(dest_dir, os.path.basename(member))
                base, extn = os.path.splitext(target)
                n = 1
                while os.path.exists(target):
                    target = f"{base}_{n}{extn}"
                    n += 1
                with rf.open(member) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                extracted.append(target)
        except Exception as e:
            warning = f"Could not extract this .rar file: {e}"
    else:
        warning = f"'{ext}' is not a supported archive format -- use .zip or .rar."

    if not extracted and not warning:
        warning = "No .xls/.xlsx files were found inside this archive."
    return extracted, warning


def detect_sheet_type(filepath):
    name = os.path.basename(filepath)
    for pattern, key in FILENAME_PATTERNS:
        if pattern.search(name):
            return key
    return "Unknown"


# ---------------------------------------------------------------------------
# 8. CONVERSION ENGINE
# ---------------------------------------------------------------------------

class ConversionContext:
    def __init__(self, cfg, pacs_info, branch_id, ask_user_callback=None, log_callback=None, progress_callback=None):
        self.cfg = cfg
        self.pacs_info = pacs_info or {}
        self.branch_id = branch_id or ""
        self.ask_user = ask_user_callback or (lambda *a, **k: None)
        self.log = log_callback or (lambda msg: None)
        self.progress = progress_callback or (lambda val, msg: None)
        self.issues = []
        self.seen_aadhaar = defaultdict(list)
        self.seen_pan = defaultdict(list)
        self.seen_mobile = defaultdict(list)
        self.seen_admission = defaultdict(list)
        self.deleted_aadhaar = []
        self.deleted_pan = []
        self.deleted_mobile = []
        self.admission_date_adjustments = []
        self.admission_account_date_adjustments = []
        self.sb_pigmy_date_adjustments = []
        self.duplicate_member_rows = []
        self.village_mapping_results = []
        self.special_member_number_rows = []
        self.dob_defaulted_rows = []
        self.member_number_reassignments = []
        self.loan_incomplete_rows = []
        self.deposit_incomplete_rows = []
        self.ai_suggestion_backup = []

    def add_issue(self, sheet, issue_type, detail, row=None):
        self.issues.append({"sheet": sheet, "type": issue_type, "detail": detail, "row": row})

    def report_duplicates(self):
        # Aadhaar duplicates - keep highest priority member type
        for aadhaar, entries in self.seen_aadhaar.items():
            if len(entries) > 1:
                sorted_entries = sorted(entries, key=lambda x: get_member_type_priority(x[2]))
                kept = sorted_entries[0]
                deleted = sorted_entries[1:]
                for admno, name, member_type, rownum in deleted:
                    self.deleted_aadhaar.append({
                        "Aadhar Number": aadhaar,
                        "AdmissionNo": admno,
                        "Name": name,
                        "MemberType": member_type,
                        "Row": rownum,
                        "Kept": f"{kept[1]} (AdmNo:{kept[0]})"
                    })
                    self.add_issue("Membership", "Duplicate Aadhaar - DELETED", 
                                  f"AdmNo:{admno} Name:{name} - Aadhaar '{aadhaar}' deleted (Kept: AdmNo:{kept[0]} Name:{kept[1]})", rownum)
                details = []
                for admno, name, member_type, rownum in entries:
                    status = "KEPT" if (admno == kept[0] and name == kept[1]) else "DELETED"
                    details.append(f"AdmNo:{admno} Name:{name} ({member_type}) - {status}")
                detail_str = f"Aadhaar '{aadhaar}' found in {len(entries)} entries: " + "; ".join(details)
                self.add_issue("Membership", "Duplicate Aadhaar - Group Summary", detail_str, kept[3])
        
        # PAN duplicates
        for pan, entries in self.seen_pan.items():
            if len(entries) > 1:
                sorted_entries = sorted(entries, key=lambda x: get_member_type_priority(x[2]))
                kept = sorted_entries[0]
                deleted = sorted_entries[1:]
                for admno, name, member_type, rownum in deleted:
                    self.deleted_pan.append({
                        "PAN Number": pan,
                        "AdmissionNo": admno,
                        "Name": name,
                        "MemberType": member_type,
                        "Row": rownum,
                        "Kept": f"{kept[1]} (AdmNo:{kept[0]})"
                    })
                    self.add_issue("Membership", "Duplicate PAN - DELETED", 
                                  f"AdmNo:{admno} Name:{name} - PAN '{pan}' deleted (Kept: AdmNo:{kept[0]} Name:{kept[1]})", rownum)
                details = []
                for admno, name, member_type, rownum in entries:
                    status = "KEPT" if (admno == kept[0] and name == kept[1]) else "DELETED"
                    details.append(f"AdmNo:{admno} Name:{name} ({member_type}) - {status}")
                detail_str = f"PAN '{pan}' found in {len(entries)} entries: " + "; ".join(details)
                self.add_issue("Membership", "Duplicate PAN - Group Summary", detail_str, kept[3])
        
        # Mobile duplicates - report only
        for mobile, entries in self.seen_mobile.items():
            if len(entries) > 1:
                details = []
                for admno, name, rownum in entries:
                    details.append(f"AdmNo:{admno} Name:{name} (row {rownum})")
                detail_str = f"Mobile '{mobile}' appears multiple times: " + "; ".join(details)
                self.add_issue("Membership", "Duplicate Mobile Number", detail_str, entries[0][2])
        
        # AdmissionNo duplicates
        for admno, entries in self.seen_admission.items():
            if len(entries) > 1:
                details = []
                for name, rownum in entries:
                    details.append(f"Name:{name} (row {rownum})")
                detail_str = f"AdmissionNo '{admno}' appears multiple times: " + "; ".join(details)
                self.add_issue("Membership", "DUPLICATE MEMBER NUMBER - RED FLAG", detail_str, entries[0][1])
                for i, (name, rownum) in enumerate(entries):
                    self.duplicate_member_rows.append({
                        "AdmissionNo": admno,
                        "Name": name,
                        "Row": rownum,
                        "OccurrenceCount": len(entries),
                        "Status": "FIRST (kept as reference)" if i == 0 else "DUPLICATE",
                    })


# ---------------------------------------------------------------------------
# Member Number format validation
# ---------------------------------------------------------------------------
# Business rule: AdmissionNo / Member Number must be an ordinary number only.
# Values like "A125" or "B226" (a letter prefix glued to digits) are NOT allowed
# for bulk upload and must be flagged for the branch to correct before submission.

RE_MEMBER_NUMBER_VALID = re.compile(r"^\d+$")


def check_special_member_numbers(membership_df, ctx):
    """Scan AdmissionNo values in the Membership sheet for anything that is not a
    plain number (e.g. 'A125', 'B226', 'M-101', 'MEM12'). Returns a list of dict
    rows for a dedicated 'Special Member Number Error Report' and also logs each
    one as a validation issue."""
    rows = []
    if membership_df is None or membership_df.empty or "AdmissionNo" not in membership_df.columns:
        return rows
    name_col = "MemberName" if "MemberName" in membership_df.columns else None
    for idx in membership_df.index:
        val = membership_df.at[idx, "AdmissionNo"]
        if is_blank(val):
            continue
        s = str(val).strip()
        # Normalise things like "125.0" (float artefact from Excel) before judging
        if re.match(r"^\d+\.0$", s):
            s = s[:-2]
        if RE_MEMBER_NUMBER_VALID.match(s):
            continue  # plain number -> OK
        row_num = idx + 2
        name = membership_df.at[idx, name_col] if name_col else ""
        reason = ("Contains letters mixed with digits (e.g. A125 / B226 style) -- "
                  "Member Number must be numeric only")
        if not re.search(r"\d", s):
            reason = "Contains no digits at all -- Member Number must be numeric only"
        elif re.search(r"[^\dA-Za-z\-\s]", s):
            reason = "Contains special characters -- Member Number must be numeric only"
        rows.append({
            "AdmissionNo (as entered)": val,
            "Name": name,
            "Row": row_num,
            "Reason": reason,
            "AssignedNewAdmissionNo": "",
        })
        ctx.add_issue(
            "Membership", "SPECIAL/INVALID MEMBER NUMBER - RED FLAG",
            f"AdmNo:'{val}' Name:{name} (row {row_num}) - {reason}", row_num
        )
    ctx.special_member_number_rows = rows
    return rows


def reassign_invalid_member_numbers(full_dfs, ctx):
    """When an AdmissionNo is alphanumeric (e.g. 'A125', 'B226'), core banking upload will reject it --
    Member Number must be a plain number. Rather than just flagging it, this assigns each invalid
    AdmissionNo a real numeric replacement and propagates that replacement to EVERY table that
    references it (Membership, every Loan/Deposit master, and Transactions), so the whole output stays
    internally consistent.

    "New" number choice: any UNUSED number below the current highest AdmissionNo is preferred (an old,
    already-in-range number that was never assigned) over simply appending a new number past the end of
    the range -- this is what "use an older/old number" means here. Only once every gap below the
    highest existing number is used up do we fall back to numbers past the current maximum.
    """
    membership_df = full_dfs.get("MembershipTemplate.xlsx")
    if membership_df is None or membership_df.empty or "AdmissionNo" not in membership_df.columns:
        return {}

    existing_numeric = set()
    invalid_entries = []  # (row_idx, raw_value, name)
    name_col = "MemberName" if "MemberName" in membership_df.columns else None
    for idx in membership_df.index:
        val = membership_df.at[idx, "AdmissionNo"]
        if is_blank(val):
            continue
        s = str(val).strip()
        if re.match(r"^\d+\.0$", s):
            s = s[:-2]
        if RE_MEMBER_NUMBER_VALID.match(s):
            existing_numeric.add(int(s))
        else:
            name = membership_df.at[idx, name_col] if name_col else ""
            invalid_entries.append((idx, val, name))

    if not invalid_entries:
        return {}

    highest = max(existing_numeric) if existing_numeric else 0
    available_gaps = sorted(set(range(1, highest + 1)) - existing_numeric)
    next_new = highest + 1

    mapping = {}  # normalized old value (str) -> new numeric value (str)
    for idx, raw_val, name in invalid_entries:
        if available_gaps:
            new_num = available_gaps.pop(0)
        else:
            new_num = next_new
            next_new += 1
        new_num_str = str(new_num)
        existing_numeric.add(new_num)
        mapping[str(raw_val).strip()] = new_num_str
        row_num = idx + 2
        ctx.member_number_reassignments.append({
            "OriginalAdmissionNo": raw_val, "Name": name, "Row": row_num,
            "AssignedNewAdmissionNo": new_num_str,
            "AssignmentMethod": "Reused an unassigned number within the existing range" if new_num <= highest
                                else "Assigned the next number past the current highest AdmissionNo",
        })
        ctx.ai_suggestion_backup.append({
            "Area": "Member Number Reassignment", "Field": "AdmissionNo",
            "OriginalValue": raw_val, "AISuggestedValue": new_num_str,
            "Reason": "AdmissionNo was alphanumeric -- core banking upload requires a plain number",
        })
        ctx.add_issue("Membership", "MEMBER NUMBER REASSIGNED",
                      f"AdmNo '{raw_val}' (Name:{name}, row {row_num}) is not numeric -- reassigned to "
                      f"'{new_num_str}' and updated everywhere this AdmissionNo appears.", row_num)

    if not mapping:
        return {}

    # Propagate the old->new mapping into every table that carries an AdmissionNo (or JointAdmissionNo).
    # Track exactly where each reassigned number gets applied (which file, which product/account),
    # so the Validation Report shows the full picture -- not just "AdmissionNo changed" but "changed
    # here, in these specific loan/deposit records" -- per the requirement that the reassignment
    # report needs to show product/account details, not just the membership-side change.
    updated_in = {new_num_str: [] for new_num_str in mapping.values()}
    for fname, df in full_dfs.items():
        if df is None or df.empty:
            continue
        has_admno = "AdmissionNo" in df.columns
        has_jointadmno = "JointAdmissionNo" in df.columns
        if not (has_admno or has_jointadmno):
            continue
        product_col = "ProductDescription" if "ProductDescription" in df.columns else None
        acct_col = next((c for c in ("LoanNo", "AccountNo") if c in df.columns), None)
        for col in ("AdmissionNo", "JointAdmissionNo"):
            if col not in df.columns:
                continue

            def _remap(v, _col=col):
                if is_blank(v):
                    return v
                key = str(v).strip()
                if re.match(r"^\d+\.0$", key):
                    key = key[:-2]
                return mapping.get(key, v)

            if fname != "MembershipTemplate.xlsx":
                for idx in df.index:
                    old_v = df.at[idx, col]
                    if is_blank(old_v):
                        continue
                    key = str(old_v).strip()
                    if re.match(r"^\d+\.0$", key):
                        key = key[:-2]
                    if key in mapping:
                        new_v = mapping[key]
                        detail = fname.replace("_Raw.xlsx", "").replace(".xlsx", "")
                        if product_col:
                            detail += f" / {df.at[idx, product_col]}"
                        if acct_col:
                            detail += f" ({acct_col}: {df.at[idx, acct_col]})"
                        updated_in[new_v].append(detail)
            df[col] = df[col].apply(_remap)

    # Now that we know everywhere each new number landed, attach it to the reassignment report.
    new_to_old = {v: k for k, v in mapping.items()}
    for entry in ctx.member_number_reassignments:
        new_num_str = entry["AssignedNewAdmissionNo"]
        places = updated_in.get(new_num_str, [])
        entry["UpdatedInRecords"] = "; ".join(places) if places else "(only appeared in Membership)"
        entry["UpdatedRecordCount"] = len(places)

    # Reflect the reassignment in the Special Member Number Errors report too.
    for row in ctx.special_member_number_rows:
        old_val = str(row.get("AdmissionNo (as entered)", "")).strip()
        if old_val in mapping:
            row["AssignedNewAdmissionNo"] = mapping[old_val]
    return mapping


LOAN_MANDATORY_FIELDS = ["AdmissionNo", "ProductDescription", "SanctionedAmount", "SanctionedDate",
                          "LoanPeriod", "RepaymentFrequency"]
DEPOSIT_MANDATORY_FIELDS = {
    "FDNonCumulative_Raw.xlsx": ["AdmissionNo", "DepositAmount", "DepositDate", "MaturityDate", "TerminMonths"],
    "FDTemplate_Raw.xlsx": ["AdmissionNo", "DepositAmount", "DepositDate", "MaturityDate", "TerminMonths"],
    "RD_Raw.xlsx": ["AdmissionNo", "InstallmentAmount", "DepositDate", "MaturityDate", "TerminMonths"],
    "SBOthers_Raw.xlsx": ["AdmissionNo", "AccountNo"],
    "Pigmy_Raw.xlsx": ["AdmissionNo", "AccountNo", "InstallmentAmount"],
}
LOAN_RAW_FILES = ["LoanKCC_Raw.xlsx", "LoanMTLT_Raw.xlsx", "LoanOthers_Raw.xlsx"]


def check_incomplete_loans(full_dfs, ctx):
    """Every mandatory field a loan needs before it can go to core banking upload. Missing values are
    reported (not invented) -- this is the person's own source data telling them what's incomplete."""
    rows = []
    for fname in LOAN_RAW_FILES:
        df = full_dfs.get(fname)
        if df is None or df.empty:
            continue
        for idx in df.index:
            missing = [f for f in LOAN_MANDATORY_FIELDS if f in df.columns and is_blank(df.at[idx, f])]
            if missing:
                row_num = idx + 2
                admno = df.at[idx, "AdmissionNo"] if "AdmissionNo" in df.columns else ""
                loanno = df.at[idx, "LoanNo"] if "LoanNo" in df.columns else ""
                rows.append({"File": fname, "AdmissionNo": admno, "LoanNo": loanno, "Row": row_num,
                             "MissingFields": ", ".join(missing)})
                ctx.add_issue("Loans", "INCOMPLETE LOAN RECORD",
                              f"AdmNo:{admno} LoanNo:{loanno} (row {row_num}) missing: {', '.join(missing)}", row_num)
    ctx.loan_incomplete_rows = rows
    return rows


def check_incomplete_deposits(full_dfs, ctx):
    """Same idea for every deposit type (FD, RD, SB, Pigmy) -- missing mandatory fields reported."""
    rows = []
    for fname, mandatory in DEPOSIT_MANDATORY_FIELDS.items():
        df = full_dfs.get(fname)
        if df is None or df.empty:
            continue
        for idx in df.index:
            missing = [f for f in mandatory if f in df.columns and is_blank(df.at[idx, f])]
            if missing:
                row_num = idx + 2
                admno = df.at[idx, "AdmissionNo"] if "AdmissionNo" in df.columns else ""
                acct = df.at[idx, "AccountNo"] if "AccountNo" in df.columns else ""
                rows.append({"File": fname, "AdmissionNo": admno, "AccountNo": acct, "Row": row_num,
                             "MissingFields": ", ".join(missing)})
                ctx.add_issue("Deposits", "INCOMPLETE DEPOSIT RECORD",
                              f"AdmNo:{admno} AccountNo:{acct} (row {row_num}) missing: {', '.join(missing)}", row_num)
    ctx.deposit_incomplete_rows = rows
    return rows


def _resolve_mapping(ctx, mapping_dict, category_label, raw_value, hints=None, options=None):
    key = norm_key(raw_value)
    if key == "":
        return ""
    if key in mapping_dict:
        return mapping_dict[key]
    chosen = ctx.ask_user(category_label, raw_value, options, None)
    if chosen is None:
        chosen = options[0] if options else key
        ctx.add_issue(category_label, "Unmapped value (used default)",
                      f"'{raw_value}' -> '{chosen}'")
    mapping_dict[key] = chosen
    return chosen


# ---------------------------------------------------------------------------
# Mapping helpers for RationCardTypeDesc, OperationTypeDesc, ChequeOption, IsOrganisation
# (only used for Membership now, but kept for completeness)
# ---------------------------------------------------------------------------

def map_ration_card_type(raw, ration_map):
    if is_blank(raw):
        return ""
    raw_str = str(raw).strip().upper()
    if raw_str in ration_map:
        return ration_map[raw_str]
    for key, value in ration_map.items():
        if key in raw_str or raw_str in key:
            return value
    return str(raw).strip()


def map_operation_type(raw, op_map):
    if is_blank(raw):
        return "Not Available"
    raw_str = str(raw).strip().upper()
    if raw_str in op_map:
        return op_map[raw_str]
    for key, value in op_map.items():
        if key in raw_str or raw_str in key:
            return value
    return "Not Available"


def map_cheque_option(raw):
    if is_blank(raw):
        return "No"
    raw_str = str(raw).strip().upper()
    if raw_str in ("YES", "Y", "1", "TRUE"):
        return "Yes"
    else:
        return "No"


def map_is_organisation(raw):
    if is_blank(raw):
        return "No"
    raw_str = str(raw).strip().upper()
    if raw_str in ("YES", "Y", "1", "TRUE", "ORGANISATION", "ORGANIZATION"):
        return "Yes"
    else:
        return "No"


# ---------------------------------------------------------------------------
# 9. CONVERT FUNCTIONS
# ---------------------------------------------------------------------------

def convert_membership(df, ctx):
    """Convert raw membership data to the DCT MembershipTemplate, applying all rules from Modification.pdf."""
    cfg = ctx.cfg
    settings = cfg["settings"]
    caste_mapping_disabled = settings.get("caste_mapping_disabled", False)
    caste_map = cfg.get("caste_map", {})
    out_rows = []
    
    df_columns = [str(c).strip() for c in df.columns]
    ctx.log(f"   Found columns: {', '.join(df_columns[:15])}...")
    
    column_mappings = {
        "AdmissionNo": ["AdmissionNo", "Member No", "MemberNo", "Member Number", "ADMISSIONNO", "SL.NO", "SL NO"],
        "CustomerTypeDescription": ["CustomerTypeDescription", "Customer Type"],
        "MemberTypeDescription": ["MemberTypeDescription", "Member Type"],
        "MemberSurName": ["MemberSurName", "Surname", "Last Name", "SURNAME"],
        "MemberName": ["MemberName", "Name", "First Name", "Given Name", "MEMBERNAME"],
        "MiddleName": ["MiddleName", "Middle Name"],
        "FatherName": ["FatherName", "Father", "Father's Name", "FATHERNAME"],
        "SpouseName": ["SpouseName", "Spouse", "Spouse's Name", "Wife Name", "SPOUSENAME"],
        "GenderDescription": ["GenderDescription", "Gender", "Sex", "GENDER"],
        "MaritalStatusDesc": ["MaritalStatusDesc", "Marital Status", "MaritalStatus"],
        # Group fields (Organisation-type members only) -- previously had NO alias coverage at all,
        # meaning any source file using a different column name for these silently left them blank.
        # Confirmed as the real cause of a real, complete-failure batch: 108 Organisation members
        # (all Self-Help Groups by name) failed 100% of the time with "Could not find GroupType for
        # Description :" because every Group* field came back blank. Best-effort common variants
        # added below; if a source still doesn't match any of these, the safety-net check further
        # down surfaces the row's actual raw column names so the real name can be added precisely
        # instead of guessed again.
        "GroupCode": ["GroupCode", "Group Code", "Group Id", "GroupID"],
        "GroupTypeDescription": ["GroupTypeDescription", "Group Type Description", "Group Type", "GroupType", "Organisation Type", "OrganisationType"],
        "GroupCategoryDescription": ["GroupCategoryDescription", "Group Category Description", "Group Category", "GroupCategory"],
        "GroupNRLMCategoryDescription": ["GroupNRLMCategoryDescription", "Group NRLM Category Description", "NRLM Category", "GroupNRLMCategory"],
        "GroupBranchCode": ["GroupBranchCode", "Group Branch Code"],
        "GroupBranchIFSC": ["GroupBranchIFSC", "Group Branch IFSC", "Group IFSC"],
        "GroupLocationDescription": ["GroupLocationDescription", "Group Location Description", "Group Location", "GroupLocation"],
        "GroupBlockCode": ["GroupBlockCode", "Group Block Code"],
        "GroupGPCode": ["GroupGPCode", "Group GP Code", "Group Gram Panchayat Code"],
        "GroupULBCode": ["GroupULBCode", "Group ULB Code"],
        "GroupMemberCount": ["GroupMemberCount", "Group Member Count", "Group Members", "No of Members", "Member Count"],
        "CommunityDescription": ["CommunityDescription", "Community", "Religion", "COMMUNITY"],
        "CasteDescription": ["CasteDescription", "Caste", "Caste Name", "CASTE"],
        "FarmerTypeDescription": ["FarmerTypeDescription", "Farmer Type", "FarmerCategory"],
        "Address1": ["Address1", "Address", "Address Line 1"],
        "Address2": ["Address2", "Address Line 2"],
        "VillageDescription": ["VillageDescription", "Village", "Village Name"],
        "LedgerFolioNo": ["LedgerFolioNo", "Ledger Folio", "Folio No"],
        "ShareBalance": ["ShareBalance", "Share Balance", "Shares"],
        "ThriftBalance": ["ThriftBalance", "Thrift Balance", "Thrift"],
        "DividentBalance": ["DividentBalance", "Dividend Balance", "Dividend"],
        "DOB": ["DOB", "DateOfBirth", "BirthDate", "Date of Birth", "D.O.B"],
        "AdmissionDate": ["AdmissionDate", "Admission Date", "Join Date", "Date of Joining"],
        "AGE": ["Age", "AGE"],
        "ContactNo": ["ContactNo", "Contact", "Mobile", "MobileNo", "Phone", "PhoneNo"],
        "AdhaarCardNo": ["AdhaarCardNo", "Aadhaar", "AadhaarNo", "Aadhar", "UID", "UIDAI"],
        "PANCardNo": ["PANCardNo", "PAN", "PANNo", "Pan", "PAN Card"],
        "VoterID": ["VoterID", "Voter ID", "VoterId", "EPIC", "EPIC No"],
        "RationCardNo": ["RationCardNo", "Ration Card", "Ration No", "RC No"],
        "DCCBSBACNO": ["DCCBSBACNO", "DCCB", "DCCB Account", "DCCB A/c", "SB Account", "Savings Account"],
        "CasteCertificationNo": ["CasteCertificationNo", "Caste Certificate", "Caste Cert No", "CC No"],
        "YeshashiviNo": ["YeshashiviNo", "Yeshasvini", "Yashasvini", "Yeshasvini No"],
        "FruitsID": ["FruitsID", "Fruits ID", "Fruit ID"],
        "PacsIDPKey": ["PacsIDPKey", "Pacs ID"],
        "PacsCode": ["PacsCode", "Pacs Code"],
        "BranchId": ["BranchId", "Branch ID", "Branch"],
        "RationCardTypeDesc": ["RationCardTypeDesc", "Ration Card Type", "RC Type"],
        "GPAIssueDate": ["GPAIssueDate", "GPA Issue Date"],
        "GPACertificationNo": ["GPACertificationNo", "GPA Certificate", "GPA No"],
        "GPAReferenceAdmissionNo": ["GPAReferenceAdmissionNo", "GPA Reference", "Reference No"],
        "DrivingLicenceNo": ["DrivingLicenceNo", "Driving License", "DL No", "LICENSE", "Driving Licence"],
        "PassportNo": ["PassportNo", "Passport", "Passport No", "Passport Number"],
    }
    
    column_map = {}
    for field, aliases in column_mappings.items():
        found = None
        for alias in aliases:
            if alias in df_columns:
                found = alias
                break
            for col in df_columns:
                if col.lower() == alias.lower():
                    found = col
                    break
            if found:
                break
            for col in df_columns:
                if alias.lower() in col.lower() or col.lower() in alias.lower():
                    found = col
                    break
            if found:
                break
        if found:
            column_map[field] = found
    
    ctx.log(f"   Mapped {len(column_map)} columns")
    
    ctx.seen_aadhaar = defaultdict(list)
    ctx.seen_pan = defaultdict(list)
    ctx.seen_mobile = defaultdict(list)
    ctx.seen_admission = defaultdict(list)
    ctx.admission_date_adjustments = []
    
    # First pass: collect all data for duplicate tracking
    rows_data = []
    for idx, row in df.iterrows():
        rownum = idx + 2
        r = {}
        
        def get_val(field, default=""):
            if field in column_map and column_map[field] in row.index:
                val = row[column_map[field]]
                if not is_blank(val):
                    return val
            if field in row.index:
                val = row[field]
                if not is_blank(val):
                    return val
            return default
        
        admission_no = get_val("AdmissionNo")
        if is_blank(admission_no):
            for col in row.index:
                if any(k in str(col).lower() for k in ["admission", "member no", "sl.no"]):
                    val = row[col]
                    if not is_blank(val):
                        admission_no = val
                        break
        
        r["AdmissionNo"] = admission_no
        member_name_raw = get_val("MemberName")
        member_name = clean_name_field(member_name_raw)
        r["MemberName"] = member_name
        
        # Member type
        member_type_raw = get_val("MemberTypeDescription")
        normalized_mt = normalize_member_type(member_type_raw)
        if normalized_mt is not None:
            r["MemberTypeDescription"] = normalized_mt
            if normalized_mt == "E Type":
                ctx.add_issue("Membership", "Uncommon Member Type (E Type)",
                              f"AdmNo:{admission_no} Name:{member_name} - source value '{member_type_raw}' "
                              f"normalized to 'E Type'. This is outside the standard A-D range -- verify "
                              f"the core banking system accepts this classification before upload.", rownum)
        else:
            r["MemberTypeDescription"] = _resolve_mapping(
                ctx, cfg["member_type_map"], "MemberTypeDescription", member_type_raw)
        
        # Clean Aadhaar
        aadhaar_val = strip_all_spaces(get_val("AdhaarCardNo"))
        if not is_blank(aadhaar_val):
            if aadhaar_val.endswith('.0'):
                aadhaar_val = aadhaar_val[:-2]
            if validate_aadhar(aadhaar_val):
                r["AdhaarCardNo"] = aadhaar_val
                ctx.seen_aadhaar[aadhaar_val].append((admission_no, member_name, r["MemberTypeDescription"], rownum))
            else:
                r["AdhaarCardNo"] = ""
                ctx.add_issue("Membership", "Invalid Aadhaar Number - DELETED", 
                              f"AdmNo:{admission_no} Name:{member_name} - '{aadhaar_val}' removed", rownum)
        else:
            r["AdhaarCardNo"] = ""
        
        # Clean PAN
        pan_val = strip_all_spaces(get_val("PANCardNo")).upper()
        if not is_blank(pan_val):
            if validate_pan(pan_val):
                r["PANCardNo"] = pan_val
                ctx.seen_pan[pan_val].append((admission_no, member_name, r["MemberTypeDescription"], rownum))
            else:
                r["PANCardNo"] = ""
                ctx.add_issue("Membership", "Invalid PAN Number - DELETED", 
                              f"AdmNo:{admission_no} Name:{member_name} - '{pan_val}' removed", rownum)
        else:
            r["PANCardNo"] = ""
        
        rows_data.append((idx, row, rownum, r, get_val))
    
    # Process duplicates
    aadhaar_to_keep = set()
    for aadhaar, entries in ctx.seen_aadhaar.items():
        if len(entries) > 1:
            sorted_entries = sorted(entries, key=lambda x: get_member_type_priority(x[2]))
            kept_entry = sorted_entries[0]
            aadhaar_to_keep.add((kept_entry[0], kept_entry[1]))
    
    pan_to_keep = set()
    for pan, entries in ctx.seen_pan.items():
        if len(entries) > 1:
            sorted_entries = sorted(entries, key=lambda x: get_member_type_priority(x[2]))
            kept_entry = sorted_entries[0]
            pan_to_keep.add((kept_entry[0], kept_entry[1]))
    
    # Second pass
    for idx, row, rownum, r, get_val in rows_data:
        # Delete duplicate Aadhaar/PAN if not the kept one
        if r.get("AdhaarCardNo") and r["AdhaarCardNo"] in ctx.seen_aadhaar:
            aadhaar = r["AdhaarCardNo"]
            entries = ctx.seen_aadhaar[aadhaar]
            if len(entries) > 1:
                is_kept = (r["AdmissionNo"], r["MemberName"]) in aadhaar_to_keep
                if not is_kept:
                    kept_entry = sorted(entries, key=lambda x: get_member_type_priority(x[2]))[0]
                    r["AdhaarCardNo"] = ""
                    ctx.add_issue("Membership", "Duplicate Aadhaar - DELETED", 
                                  f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - Aadhaar '{aadhaar}' deleted (Kept: AdmNo:{kept_entry[0]} Name:{kept_entry[1]})", rownum)
        
        if r.get("PANCardNo") and r["PANCardNo"] in ctx.seen_pan:
            pan = r["PANCardNo"]
            entries = ctx.seen_pan[pan]
            if len(entries) > 1:
                is_kept = (r["AdmissionNo"], r["MemberName"]) in pan_to_keep
                if not is_kept:
                    kept_entry = sorted(entries, key=lambda x: get_member_type_priority(x[2]))[0]
                    r["PANCardNo"] = ""
                    ctx.add_issue("Membership", "Duplicate PAN - DELETED", 
                                  f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - PAN '{pan}' deleted (Kept: AdmNo:{kept_entry[0]} Name:{kept_entry[1]})", rownum)
        
        # Process other fields
        customer_type_raw = get_val("CustomerTypeDescription")
        r["CustomerTypeDescription"] = _resolve_mapping(
            ctx, cfg["customer_type_map"], "CustomerTypeDescription", customer_type_raw)
        is_organisation = r["CustomerTypeDescription"].lower() == "organisation"
        
        if not is_blank(r["AdmissionNo"]):
            key = str(r["AdmissionNo"]).strip()
            ctx.seen_admission[key].append((r["MemberName"], rownum))
        
        # ===== MODIFICATIONS FROM PDF =====
        # MemberSurName → always blank
        r["MemberSurName"] = ""
        
        r["MiddleName"] = clean_name_field(get_val("MiddleName"))
        
        father_raw = get_val("FatherName")
        father, spouse_from_father, gender_from_father = parse_father_spouse(father_raw)
        r["FatherName"] = father
        existing_spouse = clean_name_field(get_val("SpouseName"))
        r["SpouseName"] = existing_spouse or spouse_from_father
        if is_blank(r["SpouseName"]):
            r["SpouseName"] = "Not Available"
        
        # Regional fields → always blank
        r["MemberNameRegional"] = ""
        r["FatherNameinRegional"] = ""
        r["SpouseNameinRegional"] = ""
        
        if is_blank(r["MemberName"]):
            ctx.add_issue("Membership", "Missing mandatory field", 
                          f"AdmNo:{r['AdmissionNo']} MemberName blank", rownum)
        
        # AdmissionDate cap
        admission_date_raw = get_val("AdmissionDate")
        admission_date = parse_date_from_string(admission_date_raw)
        admission_date_formatted = format_date_to_ddmmyyyy(admission_date_raw)
        if admission_date and admission_date > MAX_ADMISSION_DATE:
            old_date = admission_date_formatted
            new_date = admission_date_cap_str()
            r["AdmissionDate"] = new_date
            ctx.admission_date_adjustments.append({
                "AdmissionNo": r["AdmissionNo"],
                "Name": r["MemberName"],
                "OriginalDate": old_date,
                "AdjustedDate": new_date,
                "Row": rownum
            })
            ctx.add_issue("Membership", "AdmissionDate Adjusted", 
                          f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - '{old_date}' → '{new_date}' (capped at {admission_date_cap_str()})", rownum)
            admission_date_parsed = parse_date_from_string(new_date)
        else:
            r["AdmissionDate"] = admission_date_formatted
            admission_date_parsed = admission_date
        
        # DOB & AGE
        # A DOB value counts as "needs filling" if it's truly blank OR if it's non-blank text that
        # doesn't parse as a date at all (e.g. "Not Available", "NA", "-", random letters). The old logic
        # only filled DOB when AdmissionDate was ALSO present, so a blank/garbage DOB on a row that also
        # had a missing AdmissionDate was silently left blank forever -- fixed below to always fill.
        dob_raw = get_val("DOB")
        dob = parse_date_from_string(dob_raw)
        dob_was_defaulted = False
        dob_had_unparseable_text = (not is_blank(dob_raw)) and (dob is None)
        # BUG FIX: this used to check `if dob and admission_date_parsed:` -- but pd.NaT is TRUTHY in
        # Python (bool(pd.NaT) == True), so a source DOB that parse_date_from_string couldn't turn into
        # a real date (returning NaT) was treated as "a valid DOB present," skipping the defaulting
        # fallback entirely and leaving the row with an unusable NaT that rendered as blank in the
        # final output. Confirmed on real data: a source DOB value that was literally a bare
        # datetime.time(0,0) (no date component -- an unusual but real Excel export artifact) parsed to
        # NaT, and because NaT is truthy, 2,648 of 5,583 real members ended up with blank DOB even
        # though every one of them had a DOB value on file. Using pd.notna()/pd.isna() instead of plain
        # truthiness is what correctly routes an unparseable-but-non-blank DOB into the same defaulting
        # path a truly blank one already used.
        if pd.notna(dob) and pd.notna(admission_date_parsed):
            age = compute_age(dob, settings, admission_date_parsed)
            original_age = age
            if age is not None and age < 20:
                new_dob = admission_date_parsed - datetime.timedelta(days=20*365.25)
                new_age = compute_age(new_dob, settings, admission_date_parsed)
                dob = new_dob
                dob_was_defaulted = True
                ctx.add_issue("Membership", "Age Adjusted", 
                              f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - Original Age: {original_age}, Adjusted Age: {new_age}, DOB adjusted to {format_date_to_ddmmyyyy(dob)}", rownum)
        elif pd.isna(dob):
            # Covers a truly blank DOB, a non-blank DOB that couldn't be parsed as any date (garbage/
            # alphabetic text), AND a non-blank DOB that parsed to NaT (e.g. a time-only value) --
            # parse_default_dob() itself falls back to the fixed default even when admission_date_parsed
            # is also missing, so this always produces a usable DOB.
            dob = parse_default_dob(settings, admission_date_parsed)
            dob_was_defaulted = True
            reason = f"contained non-date text ('{dob_raw}')" if dob_had_unparseable_text else "was blank"
            ctx.add_issue("Membership", "DOB Defaulted",
                          f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - DOB {reason} -> filled with "
                          f"{format_date_to_ddmmyyyy(dob)}", rownum)
            ctx.dob_defaulted_rows.append({
                "AdmissionNo": r["AdmissionNo"], "Name": r["MemberName"], "Row": rownum,
                "OriginalValue": dob_raw if not is_blank(dob_raw) else "(blank)",
                "Reason": "Non-date text" if dob_had_unparseable_text else "Blank",
                "FilledDOB": format_date_to_ddmmyyyy(dob),
            })
        
        r["DOB"] = format_date_to_ddmmyyyy(dob) if pd.notna(dob) else ""
        
        existing_age = get_val("AGE")
        if is_blank(existing_age):
            existing_age = get_val("Age")
        try:
            existing_age = float(existing_age)
        except (TypeError, ValueError):
            existing_age = 0
        if existing_age and existing_age > 0 and not dob_was_defaulted:
            r["AGE"] = int(existing_age)
        else:
            computed = compute_age(dob, settings, admission_date_parsed) if pd.notna(dob) else None
            r["AGE"] = computed if computed is not None else (int(existing_age) if existing_age else "")
        
        # Gender → only Male, Female, Others
        gender_raw = get_val("GenderDescription")
        if is_organisation:
            r["GenderDescription"] = "Others"
        elif not is_blank(gender_raw):
            mapped = _resolve_mapping(ctx, cfg["gender_map"], "GenderDescription", gender_raw)
            if mapped not in ["Male", "Female", "Others"]:
                mapped = "Others"
            r["GenderDescription"] = mapped
        else:
            inferred_gender = infer_gender_from_name(
                r["FatherName"], r["SpouseName"], r["MemberName"]
            )
            if inferred_gender:
                if inferred_gender not in ["Male", "Female", "Others"]:
                    inferred_gender = "Others"
                r["GenderDescription"] = inferred_gender
                ctx.add_issue("Membership", "Gender inferred", 
                              f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} → '{inferred_gender}'", rownum)
            else:
                r["GenderDescription"] = "Others"
                ctx.add_issue("Membership", "Gender defaulted", 
                              f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - set to 'Others'", rownum)
        
        # MaritalStatusDesc forced to "Not Available"
        r["MaritalStatusDesc"] = "Not Available"

        # FatherName is mandatory for Male members in the core system -- confirmed on real data:
        # 5,589 records failed upload with "Father Name is required, if Gender is Male" because the
        # source simply had no FatherName for these members. Per explicit instruction: fill blank
        # FatherName with "Not Available" for Male members only -- confirmed this is safe and won't
        # trigger any duplicate-record detection, since that's based on other fields, not FatherName.
        if r["GenderDescription"] == "Male" and is_blank(r.get("FatherName")):
            r["FatherName"] = "Not Available"
            ctx.add_issue("Membership", "FatherName filled as Not Available",
                          f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} -- Male with no FatherName "
                          f"in source; filled as 'Not Available' to avoid upload rejection.", rownum)
        
        # CommunityDescription default "Not Available" if not found
        community_raw = get_val("CommunityDescription")
        community_mapped = _resolve_mapping(ctx, cfg["community_map"], "CommunityDescription", community_raw)
        r["CommunityDescription"] = community_mapped if not is_blank(community_mapped) else "Not Available"
        
        # CasteDescription with default "Not Available"
        raw_caste = get_val("CasteDescription")
        if caste_mapping_disabled:
            mapped_caste = normalize_caste_description(raw_caste, caste_map)
            r["CasteDescription"] = mapped_caste
            if mapped_caste != raw_caste and not is_blank(raw_caste):
                ctx.add_issue("Membership", "Caste Normalized", 
                              f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - '{raw_caste}' → '{mapped_caste}'", rownum)
        else:
            mapped_caste = normalize_caste_description(raw_caste, caste_map)
            r["CasteDescription"] = mapped_caste
            if mapped_caste != raw_caste and not is_blank(raw_caste):
                ctx.add_issue("Membership", "Caste Mapped", 
                              f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - '{raw_caste}' → '{mapped_caste}'", rownum)
        
        raw_farmer = get_val("FarmerTypeDescription")
        r["FarmerTypeDescription"] = normalize_farmer_type(raw_farmer, ctx, rownum, r["AdmissionNo"], r["MemberName"])
        
        raw_addr1 = get_val("Address1")
        r["Address1"] = clean_special_chars(raw_addr1) if not is_blank(raw_addr1) else "Not Found"
        r["Address2"] = clean_special_chars(get_val("Address2"))
        # BUG FIX: this used to unconditionally blank VillageDescription (probably meant as "leave
        # blank for apply_village_mapping() to fill in later from Address1/Address2"), but that threw
        # away the source's own VillageDescription whenever it was already present -- confirmed against
        # real data where the source had real village names (e.g. "KOLLUR") for the large majority of
        # rows, yet 100% of rows came out blank in the output. Now: carry the source value through when
        # it exists; only leave it blank (for the address-matching fallback) when the source truly had
        # no village on file.
        raw_village = get_val("VillageDescription")
        r["VillageDescription"] = "" if is_blank(raw_village) else str(raw_village).strip()
        
        r["LedgerFolioNo"] = get_val("LedgerFolioNo")
        r["ShareBalance"] = get_val("ShareBalance")
        r["ThriftBalance"] = get_val("ThriftBalance")
        r["DividentBalance"] = get_val("DividentBalance")
        
        mobile_raw = get_val("ContactNo")
        mobile_clean = clean_mobile_number(mobile_raw)
        if not is_blank(mobile_clean):
            if validate_mobile(mobile_clean):
                r["ContactNo"] = mobile_clean
                ctx.seen_mobile[mobile_clean].append((r["AdmissionNo"], r["MemberName"], rownum))
            else:
                r["ContactNo"] = ""
                ctx.add_issue("Membership", "Invalid Mobile Number - DELETED", 
                              f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - '{mobile_raw}' removed", rownum)
        else:
            r["ContactNo"] = ""
        
        voter_raw = get_val("VoterID")
        r["VoterID"] = clean_voter_id(voter_raw)
        if not is_blank(r["VoterID"]) and not validate_voterid(r["VoterID"]):
            ctx.add_issue("Membership", "Invalid Voter ID", 
                          f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - '{voter_raw}' → '{r['VoterID']}' (needs check)", rownum)
        
        # RationCardTypeDesc mapping
        ration_raw = get_val("RationCardTypeDesc")
        r["RationCardTypeDesc"] = map_ration_card_type(ration_raw, cfg.get("ration_card_type_map", {}))
        
        r["RationCardNo"] = clean_id_field(get_val("RationCardNo"))
        r["DCCBSBACNO"] = strip_all_spaces(get_val("DCCBSBACNO"))
        r["CasteCertificationNo"] = clean_id_field(get_val("CasteCertificationNo"))
        r["YeshashiviNo"] = clean_id_field(get_val("YeshashiviNo"))
        r["FruitsID"] = clean_id_field(get_val("FruitsID"))
        
        gpa_date_raw = get_val("GPAIssueDate")
        r["GPAIssueDate"] = format_date_to_ddmmyyyy(gpa_date_raw)
        r["GPACertificationNo"] = strip_all_spaces(get_val("GPACertificationNo"))
        r["GPAReferenceAdmissionNo"] = strip_all_spaces(get_val("GPAReferenceAdmissionNo"))
        
        r["DrivingLicenceNo"] = clean_id_field(get_val("DrivingLicenceNo"))
        r["PassportNo"] = clean_id_field(get_val("PassportNo"))
        
        r["PacsIDPKey"] = ctx.pacs_info.get("PacsIDPKey", get_val("PacsIDPKey"))
        r["PacsCode"] = get_val("PacsCode")
        r["BranchId"] = ctx.branch_id or get_val("BranchId")
        
        for fld in ["GroupCode", "GroupBranchCode", "GroupBranchIFSC", "GroupTypeDescription",
                    "GroupLocationDescription", "GroupBlockCode", "GroupGPCode", "GroupULBCode",
                    "GroupCategoryDescription", "GroupNRLMCategoryDescription",
                    "GroupMemberCount"]:
            r[fld] = get_val(fld)

        # Safety net: confirmed on real data that an Organisation-type member with no GroupType gets
        # a 100%-failure upload rejection ("Could not find GroupType for Description :"). The alias
        # coverage above handles common real-world column-name variants, but if a source uses
        # something genuinely different, this makes that visible with the row's ACTUAL column names
        # instead of a silent blank -- so the real name can be added precisely rather than guessed at
        # again.
        if r["CustomerTypeDescription"] == "Organisation" and is_blank(r.get("GroupTypeDescription")):
            ctx.add_issue("Membership", "Organisation member missing GroupType",
                          f"AdmNo:{r['AdmissionNo']} MemberName:{r.get('MemberName','')} -- "
                          f"CustomerTypeDescription is Organisation but no GroupType/GroupCode could "
                          f"be found. This upload WILL be rejected by the core system. Source columns "
                          f"in this row: {list(row.index)}", rownum)

        # Truncate and validate
        for col_name, val in r.items():
            max_len = COLUMN_LENGTHS.get(col_name)
            if max_len and not is_blank(val):
                val_str = str(val).strip()
                if len(val_str) > max_len:
                    trimmed = val_str[:max_len]
                    r[col_name] = trimmed
                    ctx.add_issue("Membership", "Value Trimmed", 
                                  f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - '{col_name}' length {len(val_str)} > {max_len}, trimmed to '{trimmed}'", rownum)
            rule_name = COLUMN_RULES.get(col_name)
            if rule_name and not is_blank(r[col_name]):
                is_valid = VALIDATORS[rule_name](r[col_name])
                if not is_valid:
                    ctx.add_issue("Membership", f"Invalid {rule_name.replace('_', ' ').title()}", 
                                  f"AdmNo:{r['AdmissionNo']} Name:{r['MemberName']} - Column '{col_name}' has invalid value: {r[col_name]}", rownum)
        
        out_rows.append(r)
    
    ctx.report_duplicates()
    
    out_df = pd.DataFrame(out_rows)
    cols = TEMPLATES["Membership"]["Membership"]["columns"]
    for c in cols:
        if c not in out_df.columns:
            out_df[c] = ""
    out_df = out_df[cols]
    
    if ctx.admission_date_adjustments:
        ctx.log(f"\n   AdmissionDate Adjustments: {len(ctx.admission_date_adjustments)} rows capped to {admission_date_cap_str()}")
        for adj in ctx.admission_date_adjustments[:5]:
            ctx.log(f"      AdmNo:{adj['AdmissionNo']} {adj['Name']}: {adj['OriginalDate']} → {adj['AdjustedDate']}")
        if len(ctx.admission_date_adjustments) > 5:
            ctx.log(f"      ... and {len(ctx.admission_date_adjustments) - 5} more")
    
    # Return with the correct filename
    return {TEMPLATES["Membership"]["Membership"]["file"]: out_df}  # <--- FIXED


GENERAL_COLUMN_ALIASES = {
    # Fields that mean the same thing across every loan/deposit/transaction file type -- safe to
    # apply universally.
    "ProductDescription": ["ProductDescription", "Product Description", "Product", "ProductName",
                           "Product Name", "LoanProduct", "Loan Product", "SchemeDescription"],
    "AdmissionNo": ["AdmissionNo", "Admission No", "Member No", "MemberNo", "Member Number", "AdmNo"],
    "LoanNo": ["LoanNo", "Loan No", "Loan Number", "LoanAccountNo", "Loan A/c No"],
    "AccountNo": ["AccountNo", "Account No", "Account Number", "A/c No", "AcNo"],
}
LOAN_ONLY_COLUMN_ALIASES = {
    # SanctionedAmount and OutstandingPrincipal are the exact field names KCC/MTLT/OTHERS' SIGNATURES
    # entries look up directly for the mapping-combo amount -- these must be scoped to loan sheet types
    # ONLY. (Confirmed the hard way: an earlier version of this alias table listed "OutstandingPrincipal"
    # as an acceptable alternate name for the transaction-side "BalancePrincipal" field, not realizing
    # the SAME alias table also runs for loan files -- which silently renamed every loan's genuine,
    # correctly-named OutstandingPrincipal column away, making every KCC/MTLT/OTHERS combo's amount
    # compute as 0. Splitting the alias table by sheet-type category, as done here, is what prevents
    # that class of cross-contamination from happening again for any other field.)
    "SanctionedAmount": ["SanctionedAmount", "Sanctioned Amount", "SanctionAmount", "LoanAmount", "Loan Amount"],
}
DEPOSIT_ONLY_COLUMN_ALIASES = {
    "DepositAmount": ["DepositAmount", "Deposit Amount"],
}
TRANSACTION_ONLY_COLUMN_ALIASES = {
    # Transaction amount fields -- confirmed on real data: a PACS whose LoanTrans export uses different
    # column names for these (e.g. "Disbursement" instead of "DisbursementAmount") would have EVERY
    # transaction row fail the has-a-nonzero-amount check in process_transactions, since none of the 8
    # expected column names would be found at all -- causing the entire file to be reported as "all
    # dropped, zero amount" even though the real amounts are sitting right there under a different header.
    "DisbursementAmount": ["DisbursementAmount", "Disbursement Amount", "Disbursement", "DisbursedAmount"],
    "CollectedPrincipal": ["CollectedPrincipal", "Collected Principal", "PrincipalCollected", "Principal Collected", "PrincipalPaid"],
    "CollectedInterest": ["CollectedInterest", "Collected Interest", "InterestCollected", "Interest Collected", "InterestPaid"],
    "CollectedPenalInterest": ["CollectedPenalInterest", "Collected Penal Interest", "PenalInterestCollected", "PenalCollected"],
    "CollectedIOD": ["CollectedIOD", "Collected IOD", "IODCollected", "IOD Collected"],
    "CollectedOthers": ["CollectedOthers", "Collected Others", "OthersCollected", "Others Collected"],
    "OtherChargesDebitAmount": ["OtherChargesDebitAmount", "Other Charges Debit Amount", "OtherCharges", "Other Charges"],
    "Charges": ["Charges", "Charge", "ChargeAmount", "Charge Amount"],
    # Deliberately does NOT list "OutstandingPrincipal" as a BalancePrincipal alias -- that field name
    # is reserved for loan files (see LOAN_ONLY_COLUMN_ALIASES's warning above). If a transaction export
    # genuinely uses "OutstandingPrincipal" for its running balance, add it here with a scoped alias
    # table rather than a shared one.
    "BalancePrincipal": ["BalancePrincipal", "Balance Principal", "PrincipalBalance"],
}
LOAN_SHEET_TYPES = {"LoanKCC", "LoanMTLT", "LoanOthers"}
DEPOSIT_SHEET_TYPES = {"FDNonCumulative", "FDTemplate", "RD", "Pigmy", "SBOthers"}


def _normalize_loan_deposit_columns(df, sheet_type, ctx=None, fname_for_log=""):
    """Applies the alias table(s) relevant to this specific sheet_type only -- e.g. a loan file only
    ever gets loan-relevant aliases applied, never transaction-only ones, so a field name collision
    between categories (like the OutstandingPrincipal/BalancePrincipal case) can't silently corrupt a
    different category's data the way it did before this was split by sheet type."""
    aliases = dict(GENERAL_COLUMN_ALIASES)
    if sheet_type in LOAN_SHEET_TYPES:
        aliases.update(LOAN_ONLY_COLUMN_ALIASES)
    elif sheet_type in DEPOSIT_SHEET_TYPES:
        aliases.update(DEPOSIT_ONLY_COLUMN_ALIASES)
    elif sheet_type == "Transactions":
        aliases.update(TRANSACTION_ONLY_COLUMN_ALIASES)

    rename_map = {}
    renamed_log = []
    for canonical, variants in aliases.items():
        if canonical in df.columns:
            continue  # already correctly named -- nothing to do
        for variant in variants:
            if variant == canonical:
                continue
            match = next((c for c in df.columns if str(c).strip().lower() == variant.lower()), None)
            if match:
                rename_map[match] = canonical
                renamed_log.append((match, canonical))
                break
    if rename_map:
        df = df.rename(columns=rename_map)
        if ctx is not None:
            for src_col, canon in renamed_log:
                ctx.add_issue("Column Naming", "Loan/Deposit Column Auto-Renamed",
                              f"{fname_for_log}: source column '{src_col}' recognized as '{canon}' "
                              f"and renamed -- verify this is correct.", None)
    return df


def convert_raw_loan_deposit(df, sheet_type, ctx):
    """
    For loan/deposit files: keep all original columns, format dates to DD-MM-YYYY,
    add PACS ID and Branch ID, and return as raw (no mapping).
    """
    g = df.copy()
    g = _normalize_loan_deposit_columns(g, sheet_type, ctx, sheet_type)
    # Format date columns
    date_columns = ["SanctionedDate", "DepositDate", "MaturityDate", "DueDate", "TransactionDate",
                    "FirstInstallmentDate", "GPAIssueDate", "GoldStockRegDate", "AppraisalDate",
                    "LastPaidInstallDate", "LastInterestPostingDate", "LCDate"]
    for col in date_columns:
        if col in g.columns:
            g[col] = g[col].apply(format_date_to_ddmmyyyy)
    
    # Add PACS and Branch IDs
    pacs_id = ctx.pacs_info.get("PacsIDPKey", "")
    branch_id = ctx.branch_id or ""
    if "PacsId" not in g.columns:
        g["PacsId"] = pacs_id
    else:
        g["PacsId"] = g["PacsId"].fillna(pacs_id)
    # BUG FIX: this used to always do g["BranchId"].fillna(branch_id) when the column already existed
    # -- .fillna() only replaces genuinely-blank values, so if the source file already had SOME
    # BranchId populated (which real core-banking exports almost always do), the person's entered
    # Branch code was silently ignored for every one of those rows. Confirmed against the Setup tab's
    # own documented behavior ("leave blank to keep whatever BranchId is already in the source file"),
    # which implies entering a value SHOULD override the source -- exactly what Membership conversion
    # already did correctly (ctx.branch_id or get_val("BranchId")), but Loans/Deposits/Transactions
    # did not. Now: an explicitly entered Branch code overrides every row in every sheet, matching
    # Membership; leaving it blank preserves whatever the source already has, exactly as documented.
    if branch_id:
        g["BranchId"] = branch_id
    elif "BranchId" not in g.columns:
        g["BranchId"] = ""
    else:
        g["BranchId"] = g["BranchId"].fillna("")
    # Also add PacsIDPKey if needed (some templates use it)
    if "PacsIDPKey" not in g.columns:
        g["PacsIDPKey"] = pacs_id
    else:
        g["PacsIDPKey"] = g["PacsIDPKey"].fillna(pacs_id)
    
    # Define output filename (raw)
    raw_filename_map = {
        "LoanKCC": "LoanKCC_Raw.xlsx",
        "LoanMTLT": "LoanMTLT_Raw.xlsx",
        "LoanOthers": "LoanOthers_Raw.xlsx",
        "FDNonCumulative": "FDNonCumulative_Raw.xlsx",
        "FDTemplate": "FDTemplate_Raw.xlsx",
        "RD": "RD_Raw.xlsx",
        "Pigmy": "Pigmy_Raw.xlsx",
        "SBOthers": "SBOthers_Raw.xlsx",
        "Transactions": "Transactions_Raw.xlsx",
        "Collateral": "Collateral_Raw.xlsx",
        "LandDetails": "LandDetails_Raw.xlsx",
        "Agent": "Agent_Raw.xlsx",
        "ShareTrans": "ShareTrans_Raw.xlsx"
    }
    out_fname = raw_filename_map.get(sheet_type, f"{sheet_type}_Raw.xlsx")
    return {out_fname: g}


def convert_sheet(sheet_type, df, ctx):
    """Main entry point: membership uses mapping, others use raw converter."""
    if sheet_type == "Membership":
        return convert_membership(df, ctx)
    else:
        return convert_raw_loan_deposit(df, sheet_type, ctx)


# ---------------------------------------------------------------------------
# AdmissionDate vs Account Master date cross-check (still applied to all)
# ---------------------------------------------------------------------------

def check_admission_vs_account_dates(full_dfs, ctx):
    """
    full_dfs: dict of {output_filename: DataFrame}
    For raw loan/deposit files, we need to know which sheet type they came from.
    We'll use the filename patterns to detect.
    We'll adjust the logic to work with raw filenames.
    """
    membership_file = "MembershipTemplate.xlsx"
    membership_df = full_dfs.get(membership_file)
    if membership_df is None or membership_df.empty:
        return [], []
    if "AdmissionNo" not in membership_df.columns or "AdmissionDate" not in membership_df.columns:
        return [], []

    # Build mapping from raw filename to sheet type
    raw_to_sheet = {
        "LoanKCC_Raw.xlsx": "LoanKCC",
        "LoanMTLT_Raw.xlsx": "LoanMTLT",
        "LoanOthers_Raw.xlsx": "LoanOthers",
        "FDNonCumulative_Raw.xlsx": "FDNonCumulative",
        "FDTemplate_Raw.xlsx": "FDTemplate",
        "RD_Raw.xlsx": "RD",
        "Pigmy_Raw.xlsx": "Pigmy",
        "SBOthers_Raw.xlsx": "SBOthers",
        "Transactions_Raw.xlsx": "Transactions",
        "Collateral_Raw.xlsx": "Collateral",
    }
    
    sb_files = ["SBOthers_Raw.xlsx"]
    pigmy_files = ["Pigmy_Raw.xlsx"]
    loan_files = ["LoanKCC_Raw.xlsx", "LoanMTLT_Raw.xlsx", "LoanOthers_Raw.xlsx"]
    deposit_files = ["FDNonCumulative_Raw.xlsx", "FDTemplate_Raw.xlsx", "RD_Raw.xlsx"]

    # --- Step 1: Loans & Deposits -> pull AdmissionDate backward ---
    earliest = {}
    for fname, df in full_dfs.items():
        if fname not in (loan_files + deposit_files):
            continue
        if df is None or df.empty or "AdmissionNo" not in df.columns:
            continue
        date_col = "SanctionedDate" if "SanctionedDate" in df.columns else (
            "DepositDate" if "DepositDate" in df.columns else None)
        if date_col is None:
            continue
        for admno_val, date_val in zip(df["AdmissionNo"], df[date_col]):
            if is_blank(admno_val):
                continue
            dt = parse_date_from_string(date_val)
            if dt is None:
                continue
            key = str(admno_val).strip()
            cur = earliest.get(key)
            if cur is None or dt < cur[0]:
                earliest[key] = (dt, fname, date_col)

    admission_adjustments = []
    for idx in membership_df.index:
        admno_val = membership_df.at[idx, "AdmissionNo"]
        if is_blank(admno_val):
            continue
        key = str(admno_val).strip()
        acc = earliest.get(key)
        if acc is None:
            continue
        acc_date, acc_file, acc_col = acc
        old_str = membership_df.at[idx, "AdmissionDate"]
        adm_date = parse_date_from_string(old_str)
        if adm_date is None or adm_date <= acc_date:
            continue

        new_str = acc_date.strftime("%d-%m-%Y")
        membership_df.at[idx, "AdmissionDate"] = new_str
        name = membership_df.at[idx, "MemberName"] if "MemberName" in membership_df.columns else ""
        row_num = idx + 2
        admission_adjustments.append({
            "AdmissionNo": admno_val,
            "Name": name,
            "OriginalAdmissionDate": old_str,
            "AdjustedAdmissionDate": new_str,
            "EarliestAccountFile": acc_file,
            "EarliestAccountDateField": acc_col,
            "EarliestAccountDate": new_str,
            "Row": row_num,
        })
        ctx.add_issue(
            "Membership", "AdmissionDate Adjusted (Loan/Deposit Precedence)",
            f"AdmNo:{admno_val} Name:{name} - AdmissionDate '{old_str}' -> '{new_str}' "
            f"(earliest {acc_col} found in {acc_file} was {new_str})",
            row_num
        )

    # --- Step 2: SB & Pigmy -> pull account date forward ---
    admission_dates = {}
    for idx in membership_df.index:
        admno_val = membership_df.at[idx, "AdmissionNo"]
        if is_blank(admno_val):
            continue
        dt = parse_date_from_string(membership_df.at[idx, "AdmissionDate"])
        if dt is not None:
            admission_dates[str(admno_val).strip()] = dt

    sb_pigmy_adjustments = []
    for fname in (sb_files + pigmy_files):
        df = full_dfs.get(fname)
        if df is None or df.empty or "AdmissionNo" not in df.columns or "DepositDate" not in df.columns:
            continue
        for idx in df.index:
            admno_val = df.at[idx, "AdmissionNo"]
            if is_blank(admno_val):
                continue
            adm_dt = admission_dates.get(str(admno_val).strip())
            if adm_dt is None:
                continue
            old_str = df.at[idx, "DepositDate"]
            acc_dt = parse_date_from_string(old_str)
            if acc_dt is None or acc_dt >= adm_dt:
                continue
            new_str = adm_dt.strftime("%d-%m-%Y")
            df.at[idx, "DepositDate"] = new_str
            row_num = idx + 2
            sb_pigmy_adjustments.append({
                "AdmissionNo": admno_val,
                "File": fname,
                "OriginalDepositDate": old_str,
                "AdjustedDepositDate": new_str,
                "AdmissionDate": new_str,
                "Row": row_num,
            })
            ctx.add_issue(
                fname, "Account Date Adjusted to AdmissionDate (SB/Pigmy)",
                f"AdmNo:{admno_val} in {fname} - DepositDate '{old_str}' -> '{new_str}' "
                f"(cannot be before AdmissionDate {new_str})",
                row_num
            )

    ctx.admission_account_date_adjustments = admission_adjustments
    ctx.sb_pigmy_date_adjustments = sb_pigmy_adjustments
    return admission_adjustments, sb_pigmy_adjustments


# ---------------------------------------------------------------------------
# Missing Membership check
# ---------------------------------------------------------------------------

def check_missing_membership(full_dfs, ctx):
    membership_file = "MembershipTemplate.xlsx"
    membership_df = full_dfs.get(membership_file)
    if membership_df is None or "AdmissionNo" not in membership_df.columns:
        return []

    membership_nos = set()
    for v in membership_df["AdmissionNo"]:
        if not is_blank(v):
            membership_nos.add(str(v).strip())

    missing_rows = []
    for fname, df in full_dfs.items():
        if fname == membership_file or df is None or df.empty:
            continue
        if "AdmissionNo" not in df.columns:
            continue
        amount_col = next((c for c in ("SanctionedAmount", "DepositAmount") if c in df.columns), None)
        date_col = next((c for c in ("SanctionedDate", "DepositDate") if c in df.columns), None)
        id_col = next((c for c in ("LoanNo", "AccountNo") if c in df.columns), None)
        for idx in df.index:
            admno_val = df.at[idx, "AdmissionNo"]
            if is_blank(admno_val):
                continue
            key = str(admno_val).strip()
            if key in membership_nos:
                continue
            row_num = idx + 2
            missing_rows.append({
                "AdmissionNo": admno_val,
                "File": fname,
                "Row": row_num,
                "ID": df.at[idx, id_col] if id_col else "",
                "ProductDescription": df.at[idx, "ProductDescription"] if "ProductDescription" in df.columns else "",
                "Amount": df.at[idx, amount_col] if amount_col else "",
                "Date": df.at[idx, date_col] if date_col else "",
            })
            ctx.add_issue(
                fname, "Missing Membership",
                f"AdmNo:{admno_val} in {fname} (row {row_num}) has no matching Membership record",
                row_num
            )

    ctx.missing_membership_rows = missing_rows
    return missing_rows


# ---------------------------------------------------------------------------
# Village Description mapping (unchanged)
# ---------------------------------------------------------------------------

_VILLAGE_COMMON_WORDS = ['karnataka', 'andhra', 'pradesh', 'tamil', 'nadu', 'kerala', 'goa',
                          'maharashtra', 'gujarat', 'rajasthan', 'delhi', 'mumbai', 'chennai',
                          'bangalore', 'bengaluru', 'mysore', 'hubli', 'dharwad', 'belgaum']


def extract_balance_sheet_amounts(path):
    """Generic balance-sheet line-item extractor -- doesn't assume a fixed layout (real PACS balance
    sheets vary), just scans every cell for text that looks like a line-item label with a numeric
    amount nearby in the same row (checking up to 3 columns to either side, since these statements
    routinely have Liabilities and Assets side by side with several spacer/sub-total columns between).
    Returns {normalized_label: amount} for every label+amount pair found -- normalized to upper-case
    with special characters stripped, matching the same normalization used for product-name matching
    elsewhere, so lookups against it can use the same matching approach as everything else."""
    try:
        raw = pd.read_excel(path, header=None)
    except Exception:
        return {}
    items = {}
    for i in range(len(raw)):
        row = raw.iloc[i]
        for j, val in enumerate(row):
            if not isinstance(val, str) or is_blank(val):
                continue
            label = val.strip()
            if len(label) < 4 or label.replace(".", "").replace("-", "").isdigit():
                continue
            # Look for a numeric value in a nearby column of the SAME row (checking right first,
            # since that's the far more common layout, then left as a fallback).
            amount = None
            for offset in (1, 2, 3, -1, -2):
                col = j + offset
                if col < 0 or col >= len(row):
                    continue
                v = row.iloc[col]
                if isinstance(v, (int, float)) and not pd.isna(v) and v != 0:
                    amount = float(v)
                    break
            if amount is not None:
                key = clean_special_chars_for_match(label)
                if key and (key not in items or amount > items[key]):
                    items[key] = amount  # keep the larger value if a label appears more than once
    return items


def clean_special_chars_for_match(s):
    return re.sub(r"\s+", " ", re.sub(r"[^A-Z0-9\s]", " ", str(s).upper())).strip()


def build_balance_sheet_tally(state, bs_amounts):
    """For every raw PRODUCT (aggregated across all its Purpose/Crop variants -- confirmed against
    real data that a balance sheet reports one total per product, not per product+purpose, e.g. "LTAP
    LOAN" split across two purpose-combos in Product Mapping summed to the balance sheet's single LTAP
    LOAN line to the exact rupee once aggregated), finds the best-matching Balance Sheet line item and
    compares amounts. Matches against RAW product names, not the mapped/canonical ones -- a balance
    sheet's own wording (e.g. "HOUSING PURPUSE LOAN") lines up with the SOURCE file's raw product text
    almost exactly, while the canonical target name ("Housing Loans") often doesn't share enough
    characters with the balance sheet's phrasing to match well. Each balance sheet line can only be
    claimed by ONE product (greedy highest-amount-first assignment) so two different products can't
    both claim the same line."""
    if not bs_amounts or not state.combos:
        return []
    grouped = {}
    for c in state.combos.values():
        if not c.get("mappedProduct"):
            continue
        key = (c["category"], c["rawProduct"])
        g = grouped.setdefault(key, {"category": c["category"], "rawProduct": c["rawProduct"],
                                      "mappedProduct": c["mappedProduct"], "count": 0, "amount": 0.0,
                                      "purposes": 0})
        g["count"] += c["count"]
        g["amount"] += c["amount"]
        g["purposes"] += 1

    available = dict(bs_amounts)
    rows = []
    for g in sorted(grouped.values(), key=lambda g: -g["amount"]):
        search_key = clean_special_chars_for_match(g["rawProduct"])
        bs_labels = list(available.keys())
        best_label, best_score = best_match(search_key, bs_labels) if bs_labels else (None, 0.0)
        if not best_label or best_score < 0.55:
            rows.append({
                "Category": CATEGORY_LABEL.get(g["category"], g["category"]),
                "Raw Product": g["rawProduct"], "Mapped Product": g["mappedProduct"],
                "Purpose Variants Merged": g["purposes"], "Accounts": g["count"],
                "Master Amount": round(g["amount"], 2),
                "Balance Sheet Line Item": "(no confident match found)", "Balance Sheet Amount": "",
                "Difference": "", "Match Confidence": f"{round(best_score*100)}%" if best_label else "0%",
                "Status": "Not Found in Balance Sheet",
            })
            continue
        bs_amount = available.pop(best_label)  # claim it -- no other product can match this line now
        diff = g["amount"] - bs_amount
        diff_pct = abs(diff) / max(1.0, abs(bs_amount))
        status = "Tallied" if diff_pct <= 0.02 else ("Review" if diff_pct <= 0.15 else "Not Tallied")
        rows.append({
            "Category": CATEGORY_LABEL.get(g["category"], g["category"]),
            "Raw Product": g["rawProduct"], "Mapped Product": g["mappedProduct"],
            "Purpose Variants Merged": g["purposes"], "Accounts": g["count"],
            "Master Amount": round(g["amount"], 2),
            "Balance Sheet Line Item": best_label, "Balance Sheet Amount": round(bs_amount, 2),
            "Difference": round(diff, 2), "Match Confidence": f"{round(best_score*100)}%",
            "Status": status,
        })
    return sorted(rows, key=lambda r: -abs(r["Master Amount"]))


def load_village_reference(path):
    """Reads every sheet in the reference workbook, not just the first -- confirmed necessary against
    a real file that ships village lists split across multiple sheets by district/region (e.g. a
    general 'VillagesList' sheet plus separate 'UDUPI', 'DAKSHINA KANNADA' sheets); reading only the
    default first sheet would silently miss every village that lives in the other sheets."""
    try:
        all_sheets = pd.read_excel(path, sheet_name=None, dtype=str)
    except Exception:
        return {}
    village_data = {}
    for sheet_name, df in all_sheets.items():
        district_col = mandal_col = village_col = None
        for col in df.columns:
            col_lower = str(col).lower().strip()
            if 'district' in col_lower:
                district_col = col
            elif 'mandal' in col_lower or 'taluk' in col_lower:
                mandal_col = col
            elif 'village' in col_lower:
                village_col = col
        if not village_col:
            continue  # this sheet doesn't look like a village list -- skip it, keep reading others
        for _, row in df.iterrows():
            raw_name = row.get(village_col)
            village_name = str(raw_name).strip() if not is_blank(raw_name) else ""
            if not village_name:
                continue
            district = str(row.get(district_col)).strip() if district_col and not is_blank(row.get(district_col)) else ""
            mandal = str(row.get(mandal_col)).strip() if mandal_col and not is_blank(row.get(mandal_col)) else ""
            village_key = village_name.lower()
            if village_key not in village_data:  # first sheet's entry wins on a rare name collision
                village_data[village_key] = {
                    "name": village_name, "district": district, "mandal": mandal,
                    "source": f"{os.path.basename(path)} [{sheet_name}]", "display": village_name,
                }
    return village_data


def find_village_match(text, village_data):
    if not text or not village_data:
        return None, None
    text_lower = text.lower()

    clean = re.sub(r'\b\d{6}\b', '', text_lower)
    for word in _VILLAGE_COMMON_WORDS:
        clean = re.sub(r'\b' + word + r'\b', '', clean)
    clean = re.sub(r'\bdist\.?\b|\bdistrict\b|\btq\.?\b|\btaluk\b', '', clean)
    clean = re.sub(r'\bpost\b|\bp\.o\.?\b|\bpincode\b', '', clean)
    clean = re.sub(r'\bvlg\.?\b|\bvillage\b', '', clean)
    clean = re.sub(r'\d+[-\s]*\d*', '', clean)
    clean = re.sub(r'[^\w\s]', ' ', clean)
    clean = ' '.join(clean.split())

    words = set(re.findall(r'\b[a-z]{3,}\b', clean))
    original_words = set(re.findall(r'\b[a-z]{3,}\b', text_lower))

    for village_key, info in village_data.items():
        if village_key == clean:
            return info["name"], info["display"]

    for word in sorted(words, key=len, reverse=True):
        if len(word) < 4:
            continue
        if word in village_data:
            info = village_data[word]
            return info["name"], info["display"]

    for word in sorted(words, key=len, reverse=True)[:20]:
        if len(word) > 5:
            for village_key, info in village_data.items():
                if len(village_key) > 5 and (word in village_key or village_key in word):
                    return info["name"], info["display"]

    for word in sorted(original_words, key=len, reverse=True)[:10]:
        if len(word) > 4:
            word_lower = word.lower()
            if word_lower in _VILLAGE_COMMON_WORDS:
                continue
            for village_key, info in village_data.items():
                if len(village_key) > 4 and (word_lower == village_key or word_lower in village_key or village_key in word_lower):
                    return info["name"], info["display"]

    return None, None


def apply_village_mapping(membership_df, village_data, ctx):
    if membership_df is None or membership_df.empty or not village_data:
        return []
    if "VillageDescription" not in membership_df.columns:
        membership_df["VillageDescription"] = ""

    results = []
    for idx in membership_df.index:
        existing = membership_df.at[idx, "VillageDescription"]
        if not is_blank(existing):
            continue

        parts = []
        for col in ("Address1", "Address2"):
            if col in membership_df.columns:
                v = membership_df.at[idx, col]
                if not is_blank(v):
                    parts.append(str(v).strip())
        address_text = " ".join(parts)
        if not address_text:
            continue

        village_name, village_display = find_village_match(address_text, village_data)
        admno_val = membership_df.at[idx, "AdmissionNo"] if "AdmissionNo" in membership_df.columns else ""
        row_num = idx + 2
        if village_display:
            membership_df.at[idx, "VillageDescription"] = village_display
            results.append({
                "AdmissionNo": admno_val, "Row": row_num,
                "AddressSource": address_text[:100], "MatchedVillage": village_display,
                "Status": "Matched",
            })
            ctx.add_issue(
                "Membership", "Village Mapped",
                f"AdmNo:{admno_val} (row {row_num}) VillageDescription set to '{village_display}' "
                f"from address text",
                row_num
            )
        else:
            results.append({
                "AdmissionNo": admno_val, "Row": row_num,
                "AddressSource": address_text[:100], "MatchedVillage": "",
                "Status": "Not Found",
            })

    ctx.village_mapping_results = results
    return results


# ===========================================================================
# Split by ProductDescription (unchanged, works on any DataFrame)
# ===========================================================================

def split_by_product_description(full_dfs, outdir, ctx):
    split_dir = os.path.join(outdir, "Split_By_Product")
    os.makedirs(split_dir, exist_ok=True)
    
    split_count = 0
    for fname, df in full_dfs.items():
        # Only split files that have a ProductDescription column
        if "ProductDescription" not in df.columns:
            continue
        if df.empty:
            continue
        # Group by ProductDescription
        for prod, group in df.groupby("ProductDescription", dropna=False):
            if is_blank(prod):
                prod = "Unknown"
            safe_prod = re.sub(r'[^a-zA-Z0-9_\- ]', '_', str(prod).strip())
            safe_prod = safe_prod[:50]
            base, ext = os.path.splitext(fname)
            out_fname = f"{safe_prod}_{base}{ext}"
            out_path = os.path.join(split_dir, out_fname)
            try:
                group.to_excel(out_path, index=False)
                ctx.log(f"   Split {fname}: Product '{prod}' -> {out_fname} ({len(group)} rows)")
                split_count += 1
            except Exception as e:
                ctx.log(f"   ERROR writing split file {out_path}: {e}")
    
    if split_count > 0:
        ctx.log(f"   Created {split_count} split files in '{os.path.basename(split_dir)}'")
    else:
        ctx.log("   No split files created (no ProductDescription data found).")


# ===========================================================================
# Split Membership by MemberTypeDescription
# ===========================================================================

def split_membership_by_type(membership_df, outdir, ctx):
    """
    Split the membership DataFrame by MemberTypeDescription and save separate Excel files
    in a 'Split_By_MemberType' folder.
    """
    if membership_df is None or membership_df.empty:
        ctx.log("   Membership split skipped: membership DataFrame is empty.")
        return
    if "MemberTypeDescription" not in membership_df.columns:
        ctx.log("   Membership split skipped: no MemberTypeDescription column.")
        return

    split_dir = os.path.join(outdir, "Split_By_MemberType")
    os.makedirs(split_dir, exist_ok=True)

    split_count = 0
    for member_type, group in membership_df.groupby("MemberTypeDescription", dropna=False):
        if is_blank(member_type):
            member_type = "Unknown"
        safe_type = re.sub(r'[^a-zA-Z0-9_\- ]', '_', str(member_type).strip())
        safe_type = safe_type[:30]
        out_fname = f"Membership_{safe_type}.xlsx"
        out_path = os.path.join(split_dir, out_fname)
        try:
            group_native = convert_membership_dates_to_native(group)
            write_excel_dd_mm_yyyy(group_native, out_path)
            ctx.log(f"   Split Membership: Type '{member_type}' -> {out_fname} ({len(group)} rows)")
            split_count += 1
        except Exception as e:
            ctx.log(f"   ERROR writing split file {out_path}: {e}")

    if split_count > 0:
        ctx.log(f"   Created {split_count} membership split files in '{os.path.basename(split_dir)}'")
    else:
        ctx.log("   No membership split files created.")


# ---------------------------------------------------------------------------
# Date-format alignment: Membership dates used to be written as plain "dd-mm-yyyy"
# TEXT strings, while Master files (built by the mapping engine) use real Excel date
# cells. This converts Membership's date columns to real dates too, and provides a
# shared writer that formats every date column the same way (dd-mm-yyyy) everywhere
# in the final output, so Membership and Masters look and sort identically in Excel.
# ---------------------------------------------------------------------------
MEMBERSHIP_DATE_COLUMNS = ["DOB", "AdmissionDate", "GPAIssueDate"]


def convert_membership_dates_to_native(df):
    if df is None or df.empty:
        return df
    df = df.copy()
    for col in MEMBERSHIP_DATE_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(lambda s: parse_date_from_string(s) if not is_blank(s) else None)
    return df


def write_excel_dd_mm_yyyy(df, path, sheet_name="Sheet1"):
    """Write a dataframe to .xlsx with every date/datetime column displayed as dd-mm-yyyy -- the one
    date format used everywhere in the final output (Membership splits, Masters, Transactions)."""
    with pd.ExcelWriter(path, engine="openpyxl", date_format="dd-mm-yyyy", datetime_format="dd-mm-yyyy") as writer:
        df.to_excel(writer, sheet_name=sheet_name, index=False)


import zipfile
import threading
from datetime import datetime as _pdt, timedelta as _ptd
from pathlib import Path
from openpyxl import Workbook

try:
    import requests
    HAVE_REQUESTS = True
except ImportError:
    HAVE_REQUESTS = False

def _script_dir():
    """The folder this script (or, once packaged, the .exe) actually lives in -- used so the app's
    config/history/taxonomy files save right next to the script/exe instead of a hidden folder in the
    user's home directory, per explicit request: everything the tool needs stays together in one
    portable location that's easy to find, back up, or move as a unit."""
    try:
        if getattr(sys, "frozen", False):
            return Path(sys.executable).resolve().parent
        return Path(os.path.abspath(__file__)).resolve().parent
    except Exception:
        return Path.home()


def _resolve_app_data_dir():
    """Prefers a folder next to the script/exe; falls back to the home directory if that location
    isn't writable (e.g. the script sits in Program Files, or another read-only/shared location) --
    the app should never fail to start just because it can't write beside itself."""
    preferred = _script_dir() / ".pacs_mapping_tool"
    try:
        preferred.mkdir(exist_ok=True)
        test_file = preferred / ".write_test"
        test_file.write_text("ok")
        test_file.unlink()
        return preferred
    except Exception:
        fallback = Path.home() / ".pacs_mapping_tool"
        fallback.mkdir(exist_ok=True)
        return fallback


APP_DATA_DIR = _resolve_app_data_dir()

# =====================================================================
# TAXONOMY  (extracted from Logic_maping.xlsx — "Loan Type" + "Savings & Deposit" sheets)
# =====================================================================
TAXONOMY_BASE = {
"KCC_products": ["Normal KCC", "KCC Animal Husbandary", "KCC Own Funds", "KCC Rabi", "KCC Kharif", "Provident Fund Loan", "KCC Weaver Loan", "Consumption Loan"],
"KCC_crops": ["paddy", "Maize", "GroundNut", "Cotton", "Chillies", "Sunflower", "Tomato", "Lemon", "Country Tobacco", "SugarCane", "FCV TOBACCO", "Vermi Compost", "ST Commercial Ownfunds", "KCC Own Ownfunds", "Fish Feed(ST Working Capital)", "Turmeric", "Banana", "Jowar", "Onion", "Bajra", "Gingelle", "Sugar Cane Plant", "Sugar Cane Rotten", "Sapota", "Sugar Cane Eksali", "Cotton HYVP", "Groundnut Wet", "Paddy Dry", "Ragi", "Mango", "Grams and Pulses", "Ginger", "Corriander", "Topica", "Nursery", "Vegetables", "Cashew", "Wheat", "Rose Hybrid Irrigated", "MaizeHYYP", "Vegetableslrrigated", "Cotton Local", "Cotton Variety", "Special Crop", "Grapes", "Soyabean", "Cow", "Buffalo", "Sheep", "Poultry", "Chanadal", "Areca Plant", "Potato", "Areca Nut", "Pepper", "Modified Potato", "Rubber", "Coconut Tree", "Dairy", "Coffee", "Pine Apple", "Fertilizer", "Mulberry", "Red Gram", "Fire Wood", "Chickpea", "Green Gram", "Gladiolus", "Pashubagya", "Small/Marginal Farmer", "Medium Farmer", "Large Farmer", "Multi Crops"],
"MTLT_products": ["Medium Term Agri Loans", "Long Term Agri Loans", "Medium Term Non Agri Loans", "Long Term Non Agri Loans", "MT Agri Own Fund Loans", "Marriage Loan"],
"MTLT_purposes": ["A,Ma,Ni, Ka", "AH Poultry and Other Birds", "Agri Development", "Agri Implements - Equipments", "Agri Vehicles", "Agricultural Drainage", "Agriculture Machinaries", "Allied Agriculture Machinaries Purchase", "Animal Husbandary-Others", "Annato Plants-MTO", "BBC", "Bajra", "Banana plant", "Barber Shop", "BasicNeeds", "Bio Gas", "Bohr motor - LTO", "Bore Well", "Bridge", "Building Construction", "Building/House Repairing", "Bullock and Carts", "Bullocks", "Business Loan", "CADA", "Calf Rearing", "Carpenter", "Cattle", "Cattle Shed", "Channel Repair", "CheckDams", "Chikoo Garden", "Citrus-LTO", "Coco and Coconut Garden", "Coconut Garden", "Coffee Drying yard", "Coffee Godown", "Consumption Loan", "Conversions", "Crane-MTO", "Dairy LTO", "Dairy-MTO", "Drag Well", "Drainage System", "Dryer", "Drip Irrigation", "Drip-MTO", "Drug Well", "Education Loan", "Electric Motors-MTO", "Electrical Shop", "Electronic Shop", "Farm House", "Farm Mechanism", "Farm Pond", "Fencing", "Fertiliser", "Fish Tank", "Fish Tank Repairs", "FishTank", "Fisheries", "Flowers Shop", "Floriculture", "Foot Wear", "Gas Plant", "Generator", "Godown Building", "Godown Construction", "Gold Purchase", "Goat", "Grape Garden", "Green House", "Guava Garden", "Harvester", "Hotel Business", "House Hold Articales", "House Loan", "House Purchase", "IRDP", "ICDP Loan", "ICDP SC Con (Share Capital Contribution)", "ICDP Subsidy", "Irrigation Equipment", "JCB", "Joint Liability Group", "JointLiabilitiesGroup", "Kirana Shop", "Kisan Chakra", "LPG Gas-MTO", "LS-Sheep", "Land Development / Land Purchase", "Land Improvement", "Land Purchase", "Later or Survivor", "Latrines-MTO", "Laundry Shop", "Lavetry/Bathroom", "Lift Irrigation", "Machinary Purchase", "Machinery-MTO", "Maduve/Munji Loan", "Mango", "Marginal Money", "Marriage Hall", "Marketyard", "Medical Treatment", "Medical Treatment-MTO", "Milch Animal", "Milk", "Mini Tractor", "Minor Irrigation", "Mortagage Loan", "Mortagege", "Mortgage/Security Loan", "Motor Mechanic Shop", "MSME", "MT Reschedulement", "Mutton Shop", "New Tota", "NFS Loans", "Old Well-MTO", "Open Well", "Others", "Paddy Reaper", "Paddy Transplanter", "Papaya", "Pawn Shop", "Pepper", "Personal Loans", "Personal Surity", "Pipe Line-LTO", "Pipe Line-MTO", "Piggery", "Plantation Or Horticulture", "Poly House", "Pomegranate", "Poultry-MTO", "Power Tiller & Tractor", "Power Tiller-MTO", "Power Trailar", "Pretty Traders", "Product Pledge Loans", "Pump House", "Pumpset", "Purchase Solar Fencing", "Repair Fish Tank", "Reschedulement", "Rice Plant", "Rig-MTO", "Rikshaw", "SAO Reschedulement", "Seri Culture-MTO", "Sewing Machine", "SHG", "Shade Net", "Sheep LT", "Sheep-MTO", "Shoe Mart", "Shopping Complex", "Six Wheeler", "Small Industry/Business", "Soil Laying", "Soil Laying And Surface Drainage", "Soil Laying-MTO", "Solar Fencing", "Solar Rooftop", "SolarLantern-MTO", "Sprinkler", "Stall - Fed Goat", "Storage and Marketyard", "Submersible Pump", "Subabuel", "Supergas", "Surface Drainage", "Surface Soil Application", "Swayamupadhi", "Tanker", "Three Wheeler", "Tiller", "Tractor Implements", "Tractor Purchase", "Tractors-LTO", "Trailar", "TV/Computer Etc", "Tube Well", "Turmeric Boiler", "Turmeric Boiler Machine", "Two Wheeler-LTO", "Under Ground Drainage", "Vegetable Vendor", "Vehicle Loan", "Venilla", "Vermi Compost - MTO", "Water Pump/Pipe", "Water Tank", "Weavers-MTO"],
"OTHERS_products": ["Gold Loan Simple", "FD Loan", "Housing Loans", "Two Wheeler Loan", "Cash Credit", "Product Pledge Loans", "Staff Loans", "Small Business Development Loan", "Self Help Group Loans", "Joint Liability", "Mortgage Loan OL", "Vehicle Loans", "Pigmy Loan", "Salary Loan Others OL", "Surity Loans", "Provident Fund Loan OL", "Manure Loans", "RD Loan", "Over Draft Loans", "Other Loans", "Cash Certificate Deposit Loan", "Gold Loan Express", "Personal Loan", "SHG Own Fund Loan", "JLG Own Fund Loan", "Swarojgar Loan", "Agriculture Activities Loan", "Consumer Loan Others", "Coffee Advance", "Pepper Advance", "Animal Husbandry OL", "Agri Implements - Equipments", "Pigmy Overdraft Loan", "Home Appliances Loan", "Super Gold Loan Express", "Business Loan", "Deposit Certificate Loans", "Deposit Loans-Non Cumulative FD", "Consumption Loan", "Emergency Loan", "Staff Housing Loan", "Staff Vehicle Loan", "Gold Purchase Loan", "Marriage Loan", "Swa Udyoga Loan"],
"OTHERS_purposes": ["(Animal Husbandry) Dairy Development", "Agri Gold Loans", "Agri Implements - Equipments", "Agriculture Activities", "Areca Nut Pledge", "Artisans", "Bee Keeping", "Business", "Cash Credit", "Cattle Rearing", "Cement Channels", "Check Dams", "Chillies", "Cloth Showroom", "Computer", "Concrete Block Factory", "Consumer Durables Loan", "Cremation", "Crop Loan", "Cut Pieces", "Dairy Development", "Dealer Loans", "Deposit Loans", "Development", "Dwacra Loans", "Education Loan QL", "Emergency Small Loan", "EV Purchase", "ICDP", "Farm Mechanism (highlighted)", "Farm Ponds", "Fertilizer", "Fertilizer Processing", "Festival Advances", "Fish Feed Loans", "Fish Tank", "Floriculture", "Four Wheeler", "Gold", "Hair Cutting Saloon", "Hand Loans", "Heavy Vehicle Purchase", "Hotel Business", "House Contruction", "House Purchase", "House Renovation", "Housing Loan", "Kisan Vikas Patra", "LT Reshedulment", "Land Development/Land Purchase", "Machinary", "Manure Loans", "Marriage Loans", "Micro Loans", "Minor Irrigation", "Mushroom", "NFS (Non-Farm Sectors)", "NSC Certificate", "National Savings", "Others", "Personal Loan", "Petty Loans", "Plantation/Horticulture", "Pledge", "Postal Loan", "Product Pledge Loans", "Radio TV Services", "Rhythumithra", "Rural Godown", "Rythu Mithra", "SHG Own Fund Loan", "Self Helf Group", "Sheep Rearing", "Small Business Loans", "Small Farmer Loans", "Solar", "Special Component Scheme", "Staff Loans", "Submersible Pumpset", "SuperGas", "Swa Udyogini Loan", "Swayam Upadhi", "Tailoring", "Tamarind", "Three Wheeler", "Trade", "Turmeric", "Two Wheeler", "Used Vehicle Purchase", "Vehicle Purchase", "Weavers Loan", "Women Self Development Loan"],
"SB_products": ["Saving Deposits", "SHG Saving Deposits", "PF SB Account", "JLG Saving Deposits", "Staff Security Deposit SB", "Current Deposits", "SB Customer Security Deposit", "Saving Deposit Gratuty", "Maturity Deposit SB", "Saving Deposit inoperative", "Members SB Death Fund", "Locker Deposit SB", "Thrift Deposits", "Pigmy Agent Security Deposit SB", "Apprisar Security Deposits", "Health Security Deposits", "Mangala Deposits", "No-Frils SB"],
"FD_products": ["Term Deposit Cummulative", "Term Deposit Non Cummulative", "Recurring Deposits", "Staff Security Deposits", "Cash Certificate Deposit", "Life Time Deposits", "Compulsory Fixed Deposit", "Amruta Fixed Deposits", "Dattu Nidhi Non-Cumulative Deposits", "Lakhpati Deposit Scheme"],
"PIGMY_products": ["Pigmy Deposits"],
}

# =====================================================================
# PRODUCT -> ALLOWED PURPOSE/CROP REQUIREMENT
# (from the "Crop / Purpose Requirement" + "Product requirement" attachment)
# When a raw row's mapped Product matches a key here, the Purpose/Crop combo in the
# mapping UI is narrowed to just this list instead of the full taxonomy — this is what
# keeps e.g. "Normal KCC" restricted to farmer-size categories, and "Vehicle Loans"
# restricted to the specific vehicle-purchase purposes the attachment specifies.
# Any product NOT listed here keeps using the full taxonomy list, unrestricted.
# =====================================================================
PRODUCT_PURPOSE_REQUIREMENTS = {
    "KCC": {
        "Normal KCC": ["Small/Marginal Farmer", "Medium Farmer", "Large Farmer", "Multi Crops"],
    },
    "OTHERS": {
        # "House Purchase" alone excluded "House Contruction" and "House Renovation" -- both already
        # exist in the taxonomy and are standard purposes for a housing loan (a housing loan is
        # routinely used to build or renovate, not only to buy outright).
        "Housing Loans": ["House Purchase", "House Contruction", "House Renovation"],
        # BUG FIX: was restricted to ["Vehicle Purchase"] only -- but "Staff Vehicle Loan" already
        # exists as its own separate product for that exact purpose, so restricting the GENERIC
        # "Staff Loans" product to the same single purpose looks like a mix-up between the two, not a
        # deliberate design choice. Removed the restriction entirely so it uses the full purpose list,
        # same as every other product with no specific entry here.
        "Vehicle Loans": ["Vehicle Purchase", "EV Purchase", "Used Vehicle Purchase", "Heavy Vehicle Purchase"],
        "Mortgage Loan OL": ["Business", "Others"],
    },
}


def allowed_second_options(state, category, product):
    """Purpose/Crop options for the second combo, narrowed by PRODUCT_PURPOSE_REQUIREMENTS
    when the product has a specific requirement list, else the full taxonomy for the category."""
    tax = CATEGORY_TAXKEY.get(category, {})
    sec_key = tax.get("second")
    if not sec_key:
        return []
    restricted = PRODUCT_PURPOSE_REQUIREMENTS.get(category, {}).get(product)
    if restricted:
        return restricted
    return state.tax_list(sec_key)

# =====================================================================
# MASTER OUTPUT MASTER_TEMPLATES (fixed column order per category)
# =====================================================================
MASTER_TEMPLATES = {
    "KCC":   ["SlNo","ProductDescription","AdmissionNo","LoanNo","Scheme","CropDescription","SanctionedDate","SanctionedAmount","LoanPeriod","DueDate","ROIPercentage","PenalROIPercentage","IODPercentage","OutstandingPrincipal","OutstandingInterest","OutstandingPenalInterest","PacsId","BranchId"],
    "MTLT":  ["SlNo","Name","AdmissionNo","ProductDescription","LoanNo","Scheme","PurposeDescription","SanctionedDate","SanctionedAmount","RepaymentFrequency","LoanPeriod","GestationPeriod","FirstInstallmentDate","InstallmentAmount","DueDate","ROIPercentage","PenalROIPercentage","IODPercentage","LANo","LCNo","LCDate","DCCBLoanAccountNo","OutstandingPrincipal","OutstandingInterest","OutstandingPenalInterest","PacsId","BranchId"],
    "OTHERS":["SlNo","ProductDescription","AdmissionNo","LoanNo","PurposeDescription","SanctionedDate","SanctionedAmount","LoanPeriod","DueDate","Scheme","RepaymentFrequency","FirstInstallmentDate","InstallmentAmount","ROI","PenalROI","IOD","LedgerFolioNo","OutstandingPrincipal","OutstandingInterest","OutstandingPenalInterest","PacsId","BranchId"],
    "SB":    ["NAME","AdmissionNo","ProductDescription","AccountNo","DepositDate","IntroducerNo","ChequeOption","OperationTypeDesc","IsOrganisation","RegisterSlNo","Balance","InterestBalance","LedgerFolioNo","JointAdmissionNo","PacsIDPkey","BranchId"],
    "FD":    ["ProductDescription","AdmissionNo","AccountNo","OperationTypeDesc","DepositDate","DepositAmount","TerminDays","TerminMonths","MaturityDate","MaturityAmount","RateOfInterest","Status","PacsIDPkey","LedgerFolioNo","DepositTypeDesc","InterestAmount","InstallmentAmount","InterestPaymentModeDesc","InstallmentsPaid","TotalInstallmentAmountPaid","LastPaidInstallDate","IsInterestPosted","chkIsInterestPostingToCB","LastInterestPostingDate","TotalInterestAmount","JointAdmissionNo","CERTINO","BranchId","PacsId"],
    "RD":    ["NAME","ProductDescription","AdmissionNo","AccountNo","OperationTypeDesc","DepositDate","DepositAmount","TerminDays","TerminMonths","MaturityDate","MaturityAmount","RateOfInterest","Status","PacsIDPkey","LedgerFolioNo","DepositTypeDesc","InterestAmount","InstallmentAmount","InterestPaymentModeDesc","InstallmentsPaid","TotalInstallmentAmountPaid","LastPaidInstallDate","IsInterestPosted","chkIsInterestPostingToCB","LastInterestPostingDate","TotalInterestAmount","JointAdmissionNo","BranchId","PacsId"],
    "PIGMY": ["NAME","AdmissionNo","ProductDescription","AccountNo","DepositDate","OperationTypeDesc","InstallmentAmount","PeriodinMonths","PeriodinYears","MaturityDate","TotalAmount","RateOfInterest","AgentNo","FrequencyDescription","LedgerFolioNo","IsPayable","totalInterestAmount","PacsIDPKey","BranchId"],
}
TRANSACTION_TEMPLATE = ["AdmissionNo","ProductDescription","LoanNo","TransactionDate","LedgerFolioNo","DisbursementAmount","OtherChargesDebitAmount","CollectedPrincipal","CollectedInterest","CollectedPenalInterest","CollectedIOD","CollectedOthers","BalancePrincipal","BalanceInterest","BalancePenalInterest","BalanceIOD","Charges","PacsId","BranchId","PurposeDescription"]

ALIASES = {
    "SlNo":["SlNo","Slno"], "Name":["Name","NAME"], "AdmissionNo":["AdmissionNo"], "LoanNo":["LoanNo"],
    "Scheme":["Scheme"], "CropDescription":["CropDescription"], "PurposeDescription":["PurposeDescription","LoanPurposeName"],
    "SanctionedDate":["SanctionedDate"], "SanctionedAmount":["SanctionedAmount"], "LoanPeriod":["LoanPeriod"],
    "DueDate":["DueDate"], "ROIPercentage":["ROIPercentage","ROI"], "PenalROIPercentage":["PenalROIPercentage","PenalROI"],
    "IODPercentage":["IODPercentage","IOD"], "OutstandingPrincipal":["OutstandingPrincipal"],
    "OutstandingInterest":["OutstandingInterest"], "OutstandingPenalInterest":["OutstandingPenalInterest"],
    "PacsId":["PacsId","PacsIDPKey","PacsIDPkey"], "BranchId":["BranchId","BRANCHID"],
    "RepaymentFrequency":["RepaymentFrequency"], "GestationPeriod":["GestationPeriod"],
    "FirstInstallmentDate":["FirstInstallmentDate"], "InstallmentAmount":["InstallmentAmount","Installment Amount","InstalmentAmount"],
    "LANo":["LANo"], "LCNo":["LCNo"], "LCDate":["LCDate"], "DCCBLoanAccountNo":["DCCBLoanAccountNo"],
    "LedgerFolioNo":["LedgerFolioNo"], "ROI":["ROI","ROIPercentage"], "PenalROI":["PenalROI","PenalROIPercentage"],
    "IOD":["IOD","IODPercentage"], "ProductDescription":["ProductDescription"],
    "NAME":["NAME","Name"], "AccountNo":["AccountNo"], "DepositDate":["DepositDate"], "IntroducerNo":["IntroducerNo"],
    "ChequeOption":["ChequeOption"], "OperationTypeDesc":["OperationTypeDesc"], "IsOrganisation":["IsOrganisation"],
    "RegisterSlNo":["RegisterSlNo"], "Balance":["Balance","BalanceAmount","AccountBalance","CurrentBalance",
                                                  "ClosingBalance","AvailableBalance","SBBalance","LedgerBalance","Bal"],
    "InterestBalance":["InterestBalance"],
    "JointAdmissionNo":["JointAdmissionNo"], "PacsIDPkey":["PacsIDPkey","PacsIDPKey","PacsId"],
    "DepositAmount":["DepositAmount"], "TerminDays":["TerminDays"], "TerminMonths":["TerminMonths"],
    "SourceBalance":["SourceBalance", "Source Balance", "Source_Balance"],
    "MaturityDate":["MaturityDate"], "MaturityAmount":["MaturityAmount"], "RateOfInterest":["RateOfInterest"],
    "Status":["Status"], "DepositTypeDesc":["DepositTypeDesc"], "InterestAmount":["InterestAmount"],
    "InterestPaymentModeDesc":["InterestPaymentModeDesc"],
    "InstallmentsPaid":["InstallmentsPaid","Installme9ntsPaid"],
    "TotalInstallmentAmountPaid":["TotalInstallmentAmountPaid","TotInstallmentsPaid"],
    "LastPaidInstallDate":["LastPaidInstallDate","LastPaidInstlDate"],
    "IsInterestPosted":["IsInterestPosted"], "chkIsInterestPostingToCB":["chkIsInterestPostingToCB"],
    "LastInterestPostingDate":["LastInterestPostingDate"], "TotalInterestAmount":["TotalInterestAmount","totalInterestAmount"],
    "CERTINO":["CERTINO"], "PeriodinMonths":["PeriodinMonths"], "PeriodinYears":["PeriodinYears"],
    "TotalAmount":["TotalAmount"], "AgentNo":["AgentNo"], "FrequencyDescription":["FrequencyDescription"],
    "IsPayable":["IsPayable"], "PacsIDPKey":["PacsIDPKey","PacsIDPkey","PacsId"],
    "TransactionDate":["TransactionDate"], "DisbursementAmount":["DisbursementAmount"],
    "OtherChargesDebitAmount":["OtherChargesDebitAmount"], "CollectedPrincipal":["CollectedPrincipal"],
    "CollectedInterest":["CollectedInterest"], "CollectedPenalInterest":["CollectedPenalInterest"],
    "CollectedIOD":["CollectedIOD"], "CollectedOthers":["CollectedOthers"], "BalancePrincipal":["BalancePrincipal"],
    "BalanceInterest":["BalanceInterest"], "BalancePenalInterest":["BalancePenalInterest"], "BalanceIOD":["BalanceIOD"],
    "Charges":["Charges"],
}

# category detection signatures: (must-have headers, amount field, group keys)
SIGNATURES = [
    {"cat":"KCC",    "must":["CropDescription","SanctionedAmount","ProductDescription"], "amount":"OutstandingPrincipal", "group":["ProductDescription","CropDescription"]},
    {"cat":"MTLT",   "must":["GestationPeriod","SanctionedAmount","ProductDescription"], "amount":"OutstandingPrincipal", "group":["ProductDescription","PurposeDescription"]},
    {"cat":"OTHERS", "must":["SanctionedAmount","PurposeDescription","ProductDescription"], "amount":"OutstandingPrincipal", "group":["ProductDescription","PurposeDescription"]},
    {"cat":"FD",     "must":["MaturityAmount","DepositAmount","ProductDescription","CERTINO"], "amount":"DepositAmount", "group":["ProductDescription"]},
    {"cat":"RD",     "must":["MaturityAmount","DepositAmount","ProductDescription","NAME"], "amount":"DepositAmount", "group":["ProductDescription"]},
    {"cat":"SB",     "must":["AccountNo","ProductDescription","RegisterSlNo"], "amount":"Balance", "group":["ProductDescription"]},
    {"cat":"PIGMY",  "must":["PeriodinMonths","ProductDescription","FrequencyDescription","AgentNo"], "amount":"TotalAmount", "group":["ProductDescription"]},
]
CATEGORY_LABEL = {"KCC":"Short Term / KCC","MTLT":"Term Loan MT&LT","OTHERS":"Other Loans","FD":"Term Deposit","RD":"Recurring Deposit","SB":"Savings","PIGMY":"Pigmy Deposit"}
CATEGORY_TAXKEY = {
    "KCC":{"products":"KCC_products","second":"KCC_crops"},
    "MTLT":{"products":"MTLT_products","second":"MTLT_purposes"},
    "OTHERS":{"products":"OTHERS_products","second":"OTHERS_purposes"},
    "FD":{"products":"FD_products","second":None}, "RD":{"products":"FD_products","second":None},
    "SB":{"products":"SB_products","second":None}, "PIGMY":{"products":"PIGMY_products","second":None},
}
LOAN_CATEGORIES = {"KCC","MTLT","OTHERS"}

# =====================================================================
# BRIDGE: feed DCT-module output straight into the mapping engine
# =====================================================================
# The DCT step writes raw templates named e.g. "LoanKCC_Raw.xlsx" / "SBOthers_Raw.xlsx"
# in-memory as {filename: DataFrame} (full_dfs). Rather than making the user save those
# to disk and re-upload them into a second app, we know exactly which raw filename maps
# to which mapping-engine category, so we can wire the DataFrames straight into
# AppState.uploaded / trans_rows without ever touching the filesystem or auto-detection.
DCT_RAW_TO_CATEGORY = {
    "LoanKCC_Raw.xlsx": "KCC",
    "LoanMTLT_Raw.xlsx": "MTLT",
    "LoanOthers_Raw.xlsx": "OTHERS",
    "FDNonCumulative_Raw.xlsx": "FD",
    "FDTemplate_Raw.xlsx": "FD",
    "RD_Raw.xlsx": "RD",
    "Pigmy_Raw.xlsx": "PIGMY",
    "SBOthers_Raw.xlsx": "SB",
}
DCT_TRANSACTIONS_FILE = "Transactions_Raw.xlsx"

_SIG_BY_CAT = {s["cat"]: s for s in SIGNATURES}


def load_dct_output_into_state(full_dfs, state: "AppState"):
    """Populate state.uploaded and state.trans_rows directly from the DCT module's
    in-memory conversion output (full_dfs: {raw_filename: DataFrame}).
    Returns a short summary dict for logging/status display."""
    state.uploaded = []
    state.trans_rows = []
    state.membership_admission_dates = {}  # AdmissionNo -> AdmissionDate, used to cross-check loan
    # SanctionedDate against the member's own AdmissionDate (a loan can't be sanctioned before the
    # member even joined). Membership itself is intentionally excluded from state.uploaded below (it's
    # not part of the Product Mapping pipeline), so this is captured separately here instead.
    summary = {}
    for fname, df in (full_dfs or {}).items():
        if df is None or df.empty:
            continue
        if fname == "MembershipTemplate.xlsx":
            adm_col = "AdmissionNo" if "AdmissionNo" in df.columns else None
            date_col = "AdmissionDate" if "AdmissionDate" in df.columns else None
            if adm_col and date_col:
                for _, r in df[[adm_col, date_col]].iterrows():
                    if pd.notna(r[adm_col]) and pd.notna(r[date_col]):
                        state.membership_admission_dates[str(r[adm_col]).strip()] = r[date_col]
            summary[fname] = ("Membership", len(df))
            continue
        if fname == DCT_TRANSACTIONS_FILE:
            state.trans_rows = df.to_dict(orient="records")
            summary[fname] = ("Transactions", len(df))
            continue
        cat = DCT_RAW_TO_CATEGORY.get(fname)
        if not cat:
            continue  # LandDetails / Collateral / Agent / ShareTrans -- not part of mapping
        sig = _SIG_BY_CAT[cat]
        rows = df.to_dict(orient="records")
        state.uploaded.append({"category": cat, "sig": sig, "rows": rows, "source_file": fname})
        summary[fname] = (cat, len(rows))
    rebuild_combos(state)
    apply_autofill(state)
    return summary

KNOWN_HEADER_WORDS = {"productdescription","loanno","admissionno","transactiondate","accountno",
    "sanctionedamount","depositamount","branchid","pacsid","purposedescription","cropdescription",
    "outstandingprincipal","disbursementamount","collectedprincipal","ledgerfoliono","maturitydate"}


# =====================================================================
# CORE HELPERS (mirrors the web tool's logic exactly)
# =====================================================================
def bigrams(s):
    s = re.sub(r"[^a-z0-9 ]", "", str(s or "").lower()).strip()
    return [s[i:i+2] for i in range(len(s)-1)]

def dice_score(a, b):
    if not a or not b:
        return 0.0
    A, B = bigrams(a), bigrams(b)
    if not A or not B:
        return 1.0 if str(a).lower() == str(b).lower() else 0.0
    from collections import Counter
    cb = Counter(B)
    hits = 0
    for x in A:
        if cb[x] > 0:
            hits += 1
            cb[x] -= 1
    return (2*hits)/(len(A)+len(B))

def best_match(raw, candidates):
    best, score = None, -1.0
    for c in candidates:
        s = dice_score(raw, c)
        if s > score:
            score, best = s, c
    return best, score

def digits_only(v):
    return re.sub(r"[^0-9]", "", str(v) if v is not None else "")

def valid_branch(v):
    if v is None or v == "":
        return None
    n = re.sub(r"[^0-9]", "", str(v))
    return int(n) if n else None

def derive_branch_from_account(acc):
    s = str(acc or "").strip()
    if len(s) >= 6 and s.startswith("110"):
        code = s[3:6]
        if code.isdigit():
            return 101 + int(code[0])
    return None

def clean_number(v, default_if_zero=None, allow_negative=False):
    if v is None or v == "":
        v = 0
    s = re.sub(r"[^0-9.\-]", "", str(v))
    try:
        n = float(s) if s not in ("", "-", ".") else 0.0
    except ValueError:
        n = 0.0
    if not allow_negative:
        n = abs(n)
    if n == 0 and default_if_zero is not None:
        n = default_if_zero
    return round(n, 2)

def clean_date(v, fallback=None):
    # Always return a pure date (no time-of-day). The Masters.zip sample showed every
    # date carrying a stray 05:30:00 (IST) time component baked into the file -- banking
    # dates should never have a time part, so we normalize to midnight in every branch.
    if isinstance(v, _pdt):
        return _pdt(v.year, v.month, v.day)
    if v is None or v == "":
        return fallback
    if isinstance(v, (int, float)):
        try:
            base = _pdt(1899, 12, 30) + _ptd(days=float(v))
            return _pdt(base.year, base.month, base.day)
        except Exception:
            pass
    s = str(v).strip()
    m = re.match(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})", s)
    if m:
        try:
            return _pdt(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            pass
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        try:
            return _pdt(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            pass
    try:
        # dayfirst=True -- same ambiguous-date fix as the DCT engine (Indian dd-mm-yyyy
        # convention, not US mm-dd-yyyy). Without this, "01-04-2020" silently becomes 4-Jan.
        parsed = pd.to_datetime(s, dayfirst=True, errors="coerce")
        if pd.isna(parsed):
            return fallback
        return _pdt(parsed.year, parsed.month, parsed.day)
    except Exception:
        return fallback

def add_months(date, months):
    if not date:
        return None
    try:
        months = int(float(months))
    except Exception:
        months = 0
    month = date.month - 1 + months
    year = date.year + month // 12
    month = month % 12 + 1
    day = min(date.day, [31,29 if year%4==0 and (year%100!=0 or year%400==0) else 28,31,30,31,30,31,31,30,31,30,31][month-1])
    return _pdt(year, month, day)

def sanitize_filename(s):
    s = re.sub(r'[\\/:*?"<>|]', "", str(s))
    return re.sub(r"\s+", " ", s).strip()

# ---- fixed-enum normalizers (per Logic_maping.xlsx: "Fetch From Source then convert to Below one") ----
FREQUENCY_ENUM = ["Monthly", "Quarterly", "Halfyearly", "Yearly", "Closing Time"]
DEPOSIT_TYPE_ENUM = ["Cumulative", "Installment Type", "Non-Cumulative"]

def normalize_frequency(raw):
    if raw is None or raw == "":
        return ""
    s = str(raw).lower()
    if re.search(r"clos|matur", s):
        return "Closing Time"
    if re.search(r"half|h\.?y\b", s):
        return "Halfyearly"
    if re.search(r"quart|qtr|qrtly", s):
        return "Quarterly"
    if re.search(r"year|annual|yrly", s):
        return "Yearly"
    if re.search(r"month", s):
        return "Monthly"
    val, score = best_match(raw, FREQUENCY_ENUM)
    return val if score >= 0.3 else str(raw)

def normalize_deposit_type(raw):
    if raw is None or raw == "":
        return ""
    s = str(raw).lower()
    if re.search(r"non[\s-]?cum", s):
        return "Non-Cumulative"
    if re.search(r"compulsory", s):
        # "Compulsory (Fixed) Deposit" is a periodic/installment-style deposit at PACS level -- without
        # this it fell through to a low-confidence fuzzy match and stayed as raw, uncategorized text,
        # which made the "Install" in dep_type check downstream miss it and produce a zero/wrong balance.
        return "Installment Type"
    if re.search(r"install", s):
        return "Installment Type"
    if re.search(r"cum", s):
        return "Cumulative"
    val, score = best_match(raw, DEPOSIT_TYPE_ENUM)
    return val if score >= 0.3 else str(raw)

OPERATION_TYPE_ENUM = ["Either", "Either or Survivor", "Former or Survivor", "Later or Survivor",
                       "Both Jointly", "Joint Operation", "Any Two Jointly", "Others", "Single", "Not Available"]

def normalize_operation_type(raw):
    if raw is None or raw == "":
        return "Not Available"
    s = str(raw).lower().strip()
    if s == "self":
        return "Single"  # explicit business rule: Self = Single
    if re.match(r"^single$", s):
        return "Single"
    if re.search(r"former.*surv", s):
        return "Former or Survivor"
    if re.search(r"later.*surv", s):
        return "Later or Survivor"
    if re.search(r"either.*surv", s):
        return "Either or Survivor"
    if re.match(r"^either$", s):
        return "Either"
    if re.search(r"both.*joint", s):
        return "Both Jointly"
    if re.search(r"joint.*oper", s):
        return "Joint Operation"
    if re.search(r"any\s*two", s):
        return "Any Two Jointly"
    if re.search(r"not\s*avail", s):
        return "Not Available"
    val, score = best_match(raw, OPERATION_TYPE_ENUM)
    return val if score >= 0.3 else str(raw)

def operation_type_confidence(raw):
    """Like normalize_operation_type, but returns (matched_value, confidence, rule_matched) instead of
    silently falling back to raw text -- used to find values that need a human decision rather than a
    guess (e.g. 'PRESIDENT AND SECRETORY', found in the real sample data, is not a confident match for
    anything in the allowed list)."""
    if raw is None or raw == "":
        return "Not Available", 1.0, True
    s = str(raw).lower().strip()
    if s in ("self", "single"):
        return "Single", 1.0, True
    if re.search(r"former.*surv", s):
        return "Former or Survivor", 1.0, True
    if re.search(r"later.*surv", s):
        return "Later or Survivor", 1.0, True
    if re.search(r"either.*surv", s):
        return "Either or Survivor", 1.0, True
    if s == "either":
        return "Either", 1.0, True
    if re.search(r"both.*joint", s):
        return "Both Jointly", 1.0, True
    if re.search(r"joint.*oper", s):
        return "Joint Operation", 1.0, True
    if re.search(r"any\s*two", s):
        return "Any Two Jointly", 1.0, True
    if re.search(r"not\s*avail", s):
        return "Not Available", 1.0, True
    val, score = best_match(raw, OPERATION_TYPE_ENUM)
    return val, score, False


OPERATION_TYPE_CONFIDENCE_THRESHOLD = 0.55


def scan_operation_type_values(state):
    """Scan every uploaded SB/FD/RD row for OperationTypeDesc values that don't confidently match the
    allowed list. Returns one entry per unique raw value (not per row) for a resolution UI -- desktop
    shows this as a popup, web shows it as an inline table -- rather than silently guessing."""
    seen = {}
    for uf in state.uploaded:
        if uf["category"] not in ("SB", "FD", "RD"):
            continue
        for row in uf["rows"]:
            raw = get_field(row, "OperationTypeDesc")
            if raw is None or str(raw).strip() == "":
                continue
            key = str(raw).strip()
            if key.lower() in [k.lower() for k in OPERATION_TYPE_ENUM]:
                continue
            if key not in seen:
                val, score, rule_matched = operation_type_confidence(raw)
                seen[key] = {"RawValue": key, "BestGuess": val, "Confidence": score, "Count": 0}
            seen[key]["Count"] += 1
    unresolved = [v for v in seen.values() if v["Confidence"] < OPERATION_TYPE_CONFIDENCE_THRESHOLD]
    unresolved.sort(key=lambda v: -v["Count"])
    return unresolved


YES_NO_SYNONYMS = {
    "y": "Yes", "yes": "Yes", "true": "Yes", "t": "Yes", "1": "Yes", "1.0": "Yes", "ok": "Yes",
    "n": "No", "no": "No", "false": "No", "f": "No", "0": "No", "0.0": "No", "none": "No",
}


def normalize_yes_no(raw, default="No"):
    """Fuzzy-match any free-text affirmative/negative value to a strict 'Yes'/'No' -- used for
    ChequeOption and IsOrganisation, which must only ever contain those two values."""
    if raw is None or str(raw).strip() == "":
        return default
    s = str(raw).strip().lower()
    if s in YES_NO_SYNONYMS:
        return YES_NO_SYNONYMS[s]
    val, score = best_match(s, ["yes", "no"])
    if score >= 0.3:
        return "Yes" if val == "yes" else "No"
    return default


_SPECIAL_CHAR_RE = re.compile(r"[^0-9A-Za-z\.\-\s]")
_MULTISPACE_RE = re.compile(r"\s+")


def clean_special_chars(text):
    """Strip characters that aren't letters/digits/dot/hyphen/space, replacing them with a space so
    words don't get glued together, then collapse repeated spaces. Example from the actual requirement:
    '30.05.2023(bmr date)' -> '30.05.2023 bmr date'. Used on LedgerFolioNo and similar free-text fields
    in Masters/Transactions -- these values get pasted into free-text bulk-upload cells, and the source
    core-banking systems reject several punctuation characters there."""
    if text is None:
        return text
    s = str(text)
    cleaned = _SPECIAL_CHAR_RE.sub(" ", s)
    cleaned = _MULTISPACE_RE.sub(" ", cleaned).strip()
    return cleaned


# Filenames used in Split_By_Products / Split_By_Transactions are the mapped ProductDescription itself
# (e.g. "Normal KCC.xlsx", "Housing Loans.xlsx") -- one workbook per final mapped product, not per
# category/template. This matches the real production Masters output and keeps every report nameable
# after the product it belongs to.
def product_master_filename(product_name):
    return sanitize_filename(str(product_name).strip()) + ".xlsx"

SCHEME_ENUM = ["SAO", "OPP/NODP", "DTP", "Nabard", "NCDC", "ICDP", "Normal"]



def normalize_scheme(raw):
    if raw is None or raw == "":
        return "Normal"
    s = str(raw).lower()
    if "nabard" in s:
        return "Nabard"
    if "ncdc" in s:
        return "NCDC"
    if "icdp" in s:
        return "ICDP"
    if "dtp" in s:
        return "DTP"
    if "opp" in s or "nodp" in s:
        return "OPP/NODP"
    if "sao" in s:
        return "SAO"
    if "normal" in s:
        return "Normal"
    val, score = best_match(raw, SCHEME_ENUM)
    return val if score >= 0.3 else str(raw)

def normalize_pigmy_frequency(raw):
    # Per Logic_maping.xlsx: Pigmy FrequencyDescription is fixed to "Daily".
    if raw is None or raw == "":
        return "Daily"
    s = str(raw).lower()
    if "daily" in s:
        return "Daily"
    return str(raw)  # unusual, non-daily Pigmy variant — keep source value rather than guess

def frequency_to_months(freq):
    return {"Monthly": 1, "Quarterly": 3, "Halfyearly": 6, "Yearly": 12}.get(str(freq or ""))

def pacs_is_blank(v):
    if v is None or v == "":
        return True
    # Same fix as the DCT engine's is_blank(): pd.isna() catches NaT (which this function otherwise
    # misses, since NaT is not a float and bool(NaT)/NaT=="" don't behave like a normal blank check).
    try:
        if pd.isna(v):
            return True
    except (TypeError, ValueError):
        pass
    try:
        import math
        return isinstance(v, float) and math.isnan(v)
    except Exception:
        return False

def get_field(row, key):
    for alias in ALIASES.get(key, [key]):
        if alias in row and not pacs_is_blank(row[alias]):
            return row[alias]
    low = {str(k).lower(): k for k in row.keys()}
    for alias in ALIASES.get(key, [key]):
        hit = low.get(alias.lower())
        if hit and not pacs_is_blank(row.get(hit)):
            return row[hit]
    return None

def detect_category(headers):
    hset = set(str(h).strip() for h in headers)
    best, best_score = None, 0.0
    for sig in SIGNATURES:
        hits = sum(1 for m in sig["must"] if m in hset)
        score = hits/len(sig["must"])
        if score > best_score:
            best_score, best = score, sig
    return best if best_score >= 0.66 else None

def _convert_via_libreoffice(path):
    """Fallback for .xls files xlrd can't parse (some real-world exports have minor
    OLE stream corruption that Excel/LibreOffice tolerate but xlrd does not)."""
    import shutil, subprocess, tempfile
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return None
    tmpdir = tempfile.mkdtemp(prefix="pacs_conv_")
    try:
        subprocess.run([soffice, "--headless", "--convert-to", "xlsx", "--outdir", tmpdir, str(path)],
                       check=True, capture_output=True, timeout=120)
        out_path = Path(tmpdir) / (Path(path).stem + ".xlsx")
        return out_path if out_path.exists() else None
    except Exception:
        return None

def read_sheet_smart(path, sheet_name=0):
    """Reads a sheet, auto-detecting the true header row (handles raw exports
    that have a junk description row before the real headers)."""
    path = str(path)
    engine = "xlrd" if path.lower().endswith(".xls") else "openpyxl"
    try:
        raw = pd.read_excel(path, sheet_name=sheet_name, header=None, dtype=str, engine=engine)
    except Exception as first_err:
        if engine == "xlrd":
            converted = _convert_via_libreoffice(path)
            if converted:
                raw = pd.read_excel(converted, sheet_name=sheet_name, header=None, dtype=str, engine="openpyxl")
            else:
                raise RuntimeError(
                    f"Could not read '{Path(path).name}' — this legacy .xls file has minor internal "
                    f"corruption that Python's xls reader can't tolerate (LibreOffice auto-conversion "
                    f"wasn't available to work around it either). The reliable fix: open it in Excel or "
                    f"LibreOffice and use 'Save As' -> .xlsx, then re-upload that file. "
                    f"(Original error: {first_err})"
                ) from first_err
        else:
            raise
    best_row, best_score = 0, -1
    for i in range(min(5, len(raw))):
        cells = [re.sub(r"[^a-z]", "", str(c).lower()) for c in raw.iloc[i].tolist()]
        score = sum(1 for c in cells if c in KNOWN_HEADER_WORDS)
        if score > best_score:
            best_score, best_row = score, i
    headers = [str(h).strip() if h is not None and str(h) != "nan" else f"col{i}" for i, h in enumerate(raw.iloc[best_row].tolist())]
    data = raw.iloc[best_row+1:].copy()
    data.columns = headers
    data = data.dropna(how="all")
    return data.to_dict(orient="records")


# =====================================================================
# APPLICATION STATE
# =====================================================================
class AppState:
    def __init__(self):
        self.pacs_id = ""
        self.pacs_name = ""
        # BUG FIX: this was hardcoded to 101 and never once connected to the Setup tab's actual
        # "Branch for this upload batch" textbox (self.var_branch) anywhere in the app. Since 101 is
        # always a "valid" branch value, build_master_row()'s priority chain (explicit_branch first)
        # ALWAYS won with this wrong hardcoded value -- meaning Masters/Transactions never saw the
        # branch code actually typed into Setup, and even ignored the source file's own BranchId
        # (which the earlier Loans/Deposits/Transactions Branch Code fix correctly set) because this
        # stale 101 short-circuited ahead of it. None here means "nothing explicit yet" -- it's set
        # from the real UI value in _run_conversion_body() and _run_split(), and build_master_row()
        # already correctly falls through to the source's own BranchId when this is None.
        self.default_branch = None
        self.custom_tax = {k: [] for k in TAXONOMY_BASE}
        self.uploaded = []       # list of dict: {category, sig, rows}
        self.membership_admission_dates = {}  # AdmissionNo -> AdmissionDate, for loan cross-checks
        self.combos = {}         # key -> dict
        self.skipped_no_product = {}  # source_file -> {category, skipped_rows, total_rows} -- see rebuild_combos()
        self.masters_output = {} # filename -> {category, rows: [...], amount}
        self.loan_lookup = {}    # loanno-digits -> {product, purpose, branch}
        self.trans_rows = []
        self.trans_output = {}   # filename -> rows
        self.trans_unmatched = {}  # loanno -> count
        self.trans_ambiguous_loanno = {}  # loanno -> details, when a cross-category collision couldn't be resolved
        self.field_cleanup_log = {}  # normally (re)populated by generate_masters(); safe empty default
        self.trans_product_stats = {}  # filename -> completeness stats (see process_transactions)
        self.trans_all_dropped_warning = None  # set by process_transactions() if every row dropped
        self.trans_kept = 0
        self.trans_dropped = 0
        self.trans_matched = 0
        self.operation_type_overrides = {}   # raw value (as typed) -> resolved OPERATION_TYPE_ENUM value
        self.validation_reports = {}         # report name -> list of row dicts (see validate_masters_output)

    def tax_list(self, key):
        return list(dict.fromkeys(TAXONOMY_BASE.get(key, []) + self.custom_tax.get(key, [])))

    def store_path(self):
        return APP_DATA_DIR / f"{self.pacs_id}.json"

    def save(self):
        if not self.pacs_id:
            return
        data = {"pacs_id": self.pacs_id, "pacs_name": self.pacs_name, "default_branch": self.default_branch,
                "combos": self.combos}
        self.store_path().write_text(json.dumps(data, indent=2, default=str))
        index_path = APP_DATA_DIR / "index.json"
        idx = json.loads(index_path.read_text()) if index_path.exists() else []
        if self.pacs_id not in idx:
            idx.append(self.pacs_id)
            index_path.write_text(json.dumps(idx))

    def load(self, pacs_id):
        p = APP_DATA_DIR / f"{pacs_id}.json"
        if p.exists():
            data = json.loads(p.read_text())
            self.pacs_id = data.get("pacs_id", pacs_id)
            self.pacs_name = data.get("pacs_name", "")
            self.default_branch = data.get("default_branch", 101)
            self.combos = data.get("combos", {})
            return True
        return False

    # Custom taxonomy (Configuration tab) is stored globally, independent of any PACS session,
    # so it works immediately on launch and isn't silently dropped before Setup is filled in.
    @staticmethod
    def custom_tax_path():
        return APP_DATA_DIR / "custom_taxonomy.json"

    def save_custom_tax(self):
        try:
            self.custom_tax_path().write_text(json.dumps(self.custom_tax, indent=2))
        except Exception as e:
            print("custom taxonomy save error:", e)

    def load_custom_tax(self):
        p = self.custom_tax_path()
        if p.exists():
            try:
                self.custom_tax = json.loads(p.read_text())
            except Exception:
                pass

    @staticmethod
    def saved_list():
        index_path = APP_DATA_DIR / "index.json"
        return json.loads(index_path.read_text()) if index_path.exists() else []


# =====================================================================
# PIPELINE FUNCTIONS
# =====================================================================
def rebuild_combos(state: AppState):
    # Reset before rebuilding — see matching comment in the HTML tool's rebuildCombos()
    # for why this must be a deterministic recompute, not an incremental accumulator.
    for c in state.combos.values():
        c["count"] = 0
        c["amount"] = 0.0
    # Rows with no ProductDescription can't form a mapping combo at all -- there's nothing to map.
    # This used to drop them with NO visibility whatsoever, which looked exactly like "my source file's
    # data just isn't showing up in Product Mapping" with no way to tell why. Now every skip is counted
    # per category and file, and surfaced as a proper report, so a whole category quietly vanishing (as
    # opposed to a few genuinely-blank rows) is immediately visible instead of just "feels incomplete."
    state.skipped_no_product = {}
    for uf in state.uploaded:
        sig = uf["sig"]
        skipped = 0
        for r in uf["rows"]:
            prod = str(get_field(r, "ProductDescription") or "").strip()
            if not prod:
                skipped += 1
                continue
            second = ""
            if len(sig["group"]) > 1:
                second = str(get_field(r, sig["group"][1]) or "").strip()
            key = f'{uf["category"]}|{prod}|{second}'
            c = state.combos.setdefault(key, {
                "category": uf["category"], "rawProduct": prod, "rawSecond": second,
                "count": 0, "amount": 0.0, "mappedProduct": "", "mappedSecond": "",
                "confidence": 0.0, "locked": False,
            })
            c["count"] += 1
            # Use the same corrected computation as the actual Master output for DepositAmount --
            # see compute_correct_deposit_amount()'s docstring for why this specific field can't just
            # be read straight off the source column.
            amt = (compute_correct_deposit_amount(r) if sig["amount"] == "DepositAmount"
                   else clean_number(get_field(r, sig["amount"])))
            c["amount"] += amt
        if skipped:
            src = uf.get("source_file", "?")
            state.skipped_no_product[src] = {
                "category": uf["category"], "skipped_rows": skipped, "total_rows": len(uf["rows"]),
            }

# =====================================================================
# PERSISTENT MAPPING HISTORY / AI SUGGESTION BACKUP
# A cross-PACS, cross-session store of every Product/Purpose mapping decision ever confirmed,
# plus every AI-driven correction (member renumbering, deposit-field corrections, etc.). This is
# what lets the auto-fill step get smarter over time instead of re-guessing from scratch on every
# fresh PACS, and it doubles as a durable backup of every AI suggestion the tool has ever made.
# =====================================================================
def mapping_history_path():
    return APP_DATA_DIR / "mapping_history.json"


def load_mapping_history():
    p = mapping_history_path()
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            pass
    return {"product_purpose": {}, "ai_suggestions_log": []}


def save_mapping_history(history):
    try:
        mapping_history_path().write_text(json.dumps(history, indent=2, default=str))
    except Exception as e:
        print("mapping history save error:", e)


def update_mapping_history(state, ctx=None):
    """Called once Masters are generated (i.e. the mapping is being acted on) -- remembers every
    raw->mapped Product/Purpose decision keyed by category + raw values, and appends every AI
    suggestion made this run (member renumbering, deposit/loan field corrections) to a running,
    timestamped backup log. Safe to call every run; entries are merged/deduped, never lost."""
    history = load_mapping_history()
    pp = history.setdefault("product_purpose", {})
    now_str = _pdt.now().strftime("%d-%m-%Y %H:%M")
    for c in state.combos.values():
        if not c.get("mappedProduct"):
            continue
        key = f'{c["category"]}|{c["rawProduct"]}|{c["rawSecond"]}'
        prior = pp.get(key, {})
        pp[key] = {
            "mappedProduct": c["mappedProduct"], "mappedSecond": c["mappedSecond"],
            "lastSeen": now_str, "lastPacs": state.pacs_name,
            "timesConfirmed": prior.get("timesConfirmed", 0) + (1 if c.get("locked") else 0),
        }
    log = history.setdefault("ai_suggestions_log", [])
    for entry in (getattr(ctx, "ai_suggestion_backup", []) or []):
        log.append({**entry, "Timestamp": now_str, "Pacs": state.pacs_name})
    if len(log) > 20000:  # keep the backup bounded but generous
        history["ai_suggestions_log"] = log[-20000:]
    save_mapping_history(history)
    return history


def history_lookup(category, raw_product, raw_second):
    """Exact-match lookup against the persisted mapping history -- used as the FIRST thing
    apply_autofill tries, before falling back to fresh fuzzy matching."""
    history = load_mapping_history()
    key = f'{category}|{raw_product}|{raw_second}'
    return history.get("product_purpose", {}).get(key)


def deposit_product_keyword_hint(raw_product, available_products):
    """Generic character-similarity matching doesn't know that "FD" is banking shorthand for "Fixed
    Deposit" (itself synonymous with "Term Deposit") -- confirmed against a real case where "FD- FIXED
    DEPOSIT" scored HIGHER against "Recurring Deposits" (0.51) than either actual Term Deposit option
    (0.44/0.40), purely because of shared letters, with no notion that "Term Deposit" IS what "FD"
    means. This checks a short list of well-known, unambiguous banking abbreviations/keywords BEFORE
    falling back to generic fuzzy matching, and only returns a hint when the keyword is actually
    present -- everything else still goes through the normal matching path unchanged."""
    s = str(raw_product).upper()
    is_fd_like = bool(re.search(r'\bFD\b|FIXED\s*DEPOSIT', s))
    is_cash_cert = bool(re.search(r'CASH\s*CERTIF|KALPAVRAKSHA', s))
    is_recurring = bool(re.search(r'\bRD\b|RECUR', s))
    is_locker = bool(re.search(r'\bLOCKER\b', s))

    if is_locker:
        # A bank-locker rental fee isn't a deposit product at all -- there's no correct target in
        # this taxonomy, so deliberately DON'T offer a confident guess (better to leave it low-
        # confidence so a human notices and decides, e.g. excluding it, than to silently mis-map it
        # into whichever deposit product happens to score highest by coincidence).
        return None, 0.0
    if is_fd_like and not is_cash_cert:
        is_cumulative = bool(re.search(r'\bCUM\b|CUMMULATIVE|CUMULATIVE', s)) and not re.search(r'NON', s)
        target = "Term Deposit Cummulative" if is_cumulative else "Term Deposit Non Cummulative"
        if target in available_products:
            return target, 0.9
    if is_cash_cert:
        target = "Cash Certificate Deposit"
        if target in available_products:
            return target, 0.9
    if is_recurring:
        target = "Recurring Deposits"
        if target in available_products:
            return target, 0.9
    return None, 0.0


def apply_keep_source_as_mapped(state: AppState, only_unlocked=True):
    """'Keep Product Mapping As Per Source Data' -- for every combo not yet confirmed, sets the mapped
    Product/Purpose to exactly what the source already says, and confirms it. Useful when the source
    file's own product/purpose text is already the correct, final wording and doesn't need to change --
    lets the person skip individually reviewing every row instead of forcing it through fuzzy-match
    suggestions first. Returns how many combos were affected."""
    n = 0
    for c in state.combos.values():
        if only_unlocked and c.get("locked"):
            continue
        c["mappedProduct"] = c["rawProduct"]
        c["mappedSecond"] = c["rawSecond"]
        c["locked"] = True
        c["confidence"] = 1.0
        n += 1
    return n


def apply_merge_by_raw_product(state: AppState):
    """'Merge Product-wise' -- once you've correctly mapped ONE combo for a given raw product, this
    applies that SAME mapped product to every other combo sharing that raw product name (different
    Purpose/Crop variants of the same product), so you don't have to repeat the same product choice for
    every purpose variant individually. Only touches combos that are still unconfirmed; never overrides
    a combo someone has already separately confirmed. Picks the highest-confidence CONFIRMED mapping
    within each raw-product group as the one to propagate; if none are confirmed yet, does nothing for
    that group (there's nothing correct yet to propagate). Returns how many combos were changed."""
    by_raw_product = {}
    for c in state.combos.values():
        by_raw_product.setdefault((c["category"], c["rawProduct"]), []).append(c)

    n_changed = 0
    for group in by_raw_product.values():
        if len(group) < 2:
            continue  # nothing to merge -- this raw product only has one combo anyway
        confirmed = [c for c in group if c.get("locked") and c.get("mappedProduct")]
        if not confirmed:
            continue  # no correct answer confirmed yet within this group to propagate
        source = max(confirmed, key=lambda c: c["amount"])  # the largest confirmed one, most likely representative
        for c in group:
            if c.get("locked") or c is source:
                continue
            c["mappedProduct"] = source["mappedProduct"]
            c["locked"] = True
            c["confidence"] = 0.95
            n_changed += 1
    return n_changed


def apply_autofill(state: AppState, overwrite=False):
    for c in state.combos.values():
        if c.get("locked"):
            continue
        if c.get("mappedProduct") and not overwrite:
            continue
        tax = CATEGORY_TAXKEY[c["category"]]
        # 1) Has this exact raw Product/Purpose combination been mapped before (any PACS, any past
        #    run)? If so, reuse it with high confidence instead of guessing fresh every time.
        hist = history_lookup(c["category"], c["rawProduct"], c["rawSecond"])
        if hist and hist.get("mappedProduct"):
            c["mappedProduct"] = hist["mappedProduct"]
            c["mappedSecond"] = hist.get("mappedSecond", "") or c["rawSecond"]
            c["confidence"] = 0.95 if hist.get("timesConfirmed", 0) > 0 else 0.8
            continue
        prod_list = state.tax_list(tax["products"])
        # 2) Deposit categories (FD/RD/PIGMY) share a small, well-known set of real-world abbreviations
        #    ("FD", "RD", cash certificate brand names) that generic string-similarity matching gets
        #    wrong more often than not -- check those first.
        keyword_target, keyword_conf = (deposit_product_keyword_hint(c["rawProduct"], prod_list)
                                          if c["category"] in ("FD", "RD", "PIGMY") else (None, 0.0))
        if keyword_target:
            pm, pscore = keyword_target, keyword_conf
        else:
            pm, pscore = best_match(c["rawProduct"], prod_list)
        c["mappedProduct"] = pm or c["rawProduct"]
        confidence = pscore
        if tax["second"] and c["rawSecond"]:
            # BUG FIX: this used to match against tax_list(tax["second"]) -- the FULL, unrestricted
            # taxonomy for this field type -- rather than the PRODUCT-SPECIFIC allowed list. Confirmed
            # on real data: a "SHORT TERM NON AGRL LOAN" / "NON AGRICULTURE" combo (₹64M) was mapped to
            # product "Mortgage Loan OL" (whose allowed purposes are only ["Business", "Others"]) with
            # mappedSecond="Floriculture" -- a value that isn't even in that product's allowed list,
            # and directly contradicts "NON AGRICULTURE". Restricting the match to the actual allowed
            # list for the chosen product is what PRODUCT_PURPOSE_REQUIREMENTS exists for; the old code
            # computed it but then ignored it during autofill.
            sec_list = allowed_second_options(state, c["category"], c["mappedProduct"])
            if not sec_list:
                sec_list = state.tax_list(tax["second"])  # product has no specific restriction -- use the full list
            sm, sscore = best_match(c["rawSecond"], sec_list)
            c["mappedSecond"] = sm or c["rawSecond"]
            confidence = min(confidence, sscore)
        elif tax["second"]:
            c["mappedSecond"] = c["rawSecond"]
        c["confidence"] = confidence

def compute_correct_deposit_amount(raw):
    """DepositAmount is a direct copy of the source's own DepositAmount field. CONFIRMED EXPLICITLY:
    do NOT substitute TotalInstallmentAmountPaid here, even for Installment Type (RD) deposits -- an
    earlier version of this function did that, and it was wrong for this bank's actual requirement.
    TotalInstallmentAmountPaid is still used separately in REPORT/VALIDATION calculations (e.g. RD
    Deep Validation's InterestAmount check) -- that logic is confirmed correct and is untouched by
    this change; this function is specifically about what value the MASTER FILE'S DepositAmount
    column (and the Product Mapping combo amount shown alongside it) should hold, which is the raw
    source value, full stop.

    Exception: Term Deposit Non Cummulative accounts carry a separate "Source Balance" field that IS
    confirmed as the authoritative current balance for that specific case -- that still takes
    priority when present, since that's a distinct, separately-confirmed instruction."""
    source_balance = clean_number(get_field(raw, "SourceBalance"))
    if source_balance > 0:
        return source_balance
    return clean_number(get_field(raw, "DepositAmount"))


def build_master_row(category, raw, combo, slno, default_branch, pacs_id, operation_type_overrides=None):
    tpl = MASTER_TEMPLATES[category]
    out = {}
    # BUG FIX (priority order): this used to try the SOURCE row's own BranchId first, and only use
    # default_branch (the Setup tab's "Branch for this upload batch" field) as a last resort -- exactly
    # backwards from what the Setup tab itself says ("leave blank to keep whatever BranchId is already
    # in the source file"), and inconsistent with Membership conversion, which already correctly
    # prioritizes the Setup value. Confirmed as a real, user-visible inconsistency: typing a branch code
    # in Setup only affected Membership, while Masters and Transactions silently kept using whatever was
    # in the source file (or a stale/hardcoded fallback) regardless. default_branch is now None whenever
    # the Setup field was left blank (see the wiring in _run_split/_generate_masters), so "does the
    # explicit override win" and "was nothing configured, fall back to source" are no longer conflated.
    explicit_branch = valid_branch(default_branch)
    branch = (explicit_branch
              or valid_branch(get_field(raw, "BranchId"))
              or derive_branch_from_account(get_field(raw, "AccountNo") or get_field(raw, "LoanNo"))
              or 101)
    pacs = get_field(raw, "PacsId") or get_field(raw, "PacsIDPkey") or get_field(raw, "PacsIDPKey") or pacs_id
    operation_type_overrides = operation_type_overrides or {}

    date_keys = {"SanctionedDate","DepositDate","LCDate","LastPaidInstallDate","LastInterestPostingDate"}
    amount_keys = {"OutstandingInterest","OutstandingPenalInterest","ROIPercentage","PenalROIPercentage","IODPercentage",
                   "ROI","PenalROI","IOD","SanctionedAmount","MaturityAmount",
                   "InterestAmount","TotalInterestAmount","TotalInstallmentAmountPaid","Balance","InterestBalance","TotalAmount"}
    yes_no_keys = {"ChequeOption", "IsOrganisation"}
    text_clean_keys = {"LedgerFolioNo"}
    # LoanNo/AccountNo are pure numeric identifiers to the core system -- confirmed as a real cause of
    # transaction rejections: a special character left in one of these (e.g. "1125/A") gets written
    # verbatim into Master output, and if the Transaction output for the same underlying loan happens
    # to carry a differently-formatted or clean version, the core system sees them as two different
    # loan numbers even though this tool's own internal LoanNo matching (which already uses
    # digits_only() for lookups) correctly treated them as the same loan. Cleaning both consistently
    # here, in the same place a person would otherwise have to notice and fix by hand.
    numeric_id_clean_keys = {"LoanNo", "AccountNo"}

    for key in tpl:
        if key == "SlNo":
            val = slno
        elif key == "ProductDescription":
            val = combo["mappedProduct"]
        elif key in ("CropDescription", "PurposeDescription"):
            val = combo["mappedSecond"]
        elif key == "BranchId":
            val = branch
        elif key in ("PacsId", "PacsIDPkey", "PacsIDPKey"):
            val = pacs
        elif key in date_keys:
            val = clean_date(get_field(raw, key))
        elif key == "FirstInstallmentDate":
            fid = clean_date(get_field(raw, key))
            if not fid:
                sd = clean_date(get_field(raw, "SanctionedDate"))
                freq_months = frequency_to_months(normalize_frequency(get_field(raw, "RepaymentFrequency")))
                if sd and freq_months:
                    fid = add_months(sd, freq_months)
            val = fid
        elif key == "MaturityDate":
            # Per explicit instruction: MaturityDate is NEVER auto-corrected -- the source value is
            # always kept as-is in the output. Any DepositDate+Term mismatch is only ever reported
            # (see "Deposit Calculation Issues" in validate_masters_output), never silently overwritten,
            # since some renewed deposits legitimately store the renewal date in DepositDate rather
            # than the true original start date -- overwriting MaturityDate in that case would be wrong.
            stored_md = clean_date(get_field(raw, key))
            if stored_md:
                val = stored_md
            else:
                dep_date = clean_date(get_field(raw, "DepositDate"))
                td_raw, tm_raw = get_field(raw, "TerminDays"), get_field(raw, "TerminMonths")
                try:
                    if dep_date and td_raw and float(td_raw) > 0:
                        val = dep_date + _ptd(days=float(td_raw))
                    elif dep_date and tm_raw and float(tm_raw) > 0:
                        val = add_months(dep_date, tm_raw)
                    else:
                        val = None
                except (TypeError, ValueError):
                    val = None
        elif key == "DueDate":
            dd = clean_date(get_field(raw, key))
            if not dd:
                sd = clean_date(get_field(raw, "SanctionedDate"))
                lp = get_field(raw, "LoanPeriod")
                if sd and lp:
                    dd = add_months(sd, lp)
            val = dd
        elif key == "OutstandingPrincipal":
            val = clean_number(get_field(raw, key), default_if_zero=0.01)
        elif key == "InstallmentAmount":
            ia = clean_number(get_field(raw, key))
            if ia == 0:
                sa = clean_number(get_field(raw, "SanctionedAmount"))
                try:
                    lp = float(get_field(raw, "LoanPeriod") or 0)
                except (TypeError, ValueError):
                    lp = 0
                if sa and lp:
                    ia = round(sa / lp, 2)
            val = ia
        elif key == "DepositAmount":
            val = compute_correct_deposit_amount(raw)
        elif key in ("InterestPaymentModeDesc", "IsInterestPosted"):
            val = normalize_frequency(get_field(raw, key))
        elif key == "RepaymentFrequency":
            val = normalize_frequency(get_field(raw, key))
        elif key == "DepositTypeDesc":
            val = normalize_deposit_type(get_field(raw, key))
        elif key == "OperationTypeDesc":
            raw_op = get_field(raw, key)
            override = operation_type_overrides.get(str(raw_op).strip()) if raw_op is not None else None
            val = override or normalize_operation_type(raw_op)
        elif key == "Scheme":
            val = normalize_scheme(get_field(raw, key))
        elif key == "FrequencyDescription":
            val = normalize_pigmy_frequency(get_field(raw, key))
        elif key in yes_no_keys:
            val = normalize_yes_no(get_field(raw, key))
        elif key in text_clean_keys:
            raw_val = get_field(raw, key)
            val = clean_special_chars(raw_val) if raw_val not in (None, "") else (raw_val if raw_val is not None else "")
        elif key in numeric_id_clean_keys:
            raw_val = get_field(raw, key)
            if raw_val not in (None, ""):
                cleaned = digits_only(raw_val)
                val = cleaned if cleaned else raw_val  # never blank out a value we couldn't parse as numeric
            else:
                val = ""
        elif key == "JointAdmissionNo":
            raw_val = get_field(raw, key)
            s = str(raw_val).strip() if raw_val is not None else ""
            val = "" if s in ("", "0", "0.0", "nan") else raw_val
        elif key in amount_keys:
            val = clean_number(get_field(raw, key))
        else:
            val = get_field(raw, key)
            if val is None:
                val = ""
        out[key] = val
    return out

def generate_masters(state: AppState, ctx=None):
    state.masters_output = {}
    counters = {}
    state.field_cleanup_log = {
        "LedgerFolioNo Cleanup": [], "JointAdmissionNo Cleanup": [],
        "ChequeOption-IsOrganisation Cleanup": [], "OperationTypeDesc Mapping": [],
        "BranchId Defaulted to 101": [],
        "LoanNo Special Character Cleanup": [], "AccountNo Special Character Cleanup": [],
        "LoanNo Reassigned (collision avoided)": [], "AccountNo Reassigned (collision avoided)": [],
        "Transaction AdmissionNo Corrected": [],
    }
    for uf in state.uploaded:
        sig = uf["sig"]
        for raw in uf["rows"]:
            prod = str(get_field(raw, "ProductDescription") or "").strip()
            if not prod:
                continue
            second = str(get_field(raw, sig["group"][1]) or "").strip() if len(sig["group"]) > 1 else ""
            key = f'{uf["category"]}|{prod}|{second}'
            combo = state.combos.get(key)
            if not combo or not combo.get("mappedProduct"):
                continue
            target_category = combo.get("category") or uf["category"]  # respects a user's category override
            # One workbook PER MAPPED PRODUCT (e.g. "Normal KCC.xlsx", "Housing Loans.xlsx") -- not
            # per category/template. This is what actually goes to core banking upload.
            fname = product_master_filename(combo["mappedProduct"])
            mo = state.masters_output.setdefault(fname, {"category": target_category,
                                                           "product": combo["mappedProduct"],
                                                           "rows": [], "amount": 0.0})
            counters[fname] = counters.get(fname, 0) + 1
            slno = counters[fname]
            row = build_master_row(target_category, raw, combo, slno, state.default_branch, state.pacs_id,
                                    operation_type_overrides=state.operation_type_overrides)

            admno = get_field(raw, "AdmissionNo") or ""
            acct = get_field(raw, "AccountNo") or get_field(raw, "LoanNo") or ""
            # Tracks when BranchId had to fall all the way through to the hardcoded 101 last-resort
            # default -- i.e. the Setup override was blank AND the source had no BranchId of its own
            # AND nothing could be derived from the account/loan number. Recomputes the same chain
            # build_master_row() already applied (rather than changing its return signature) purely
            # to log this specific case with a before/after entry, matching the same audit-trail
            # pattern already used for LedgerFolioNo/JointAdmissionNo below.
            if (not valid_branch(state.default_branch)
                    and not valid_branch(get_field(raw, "BranchId"))
                    and not derive_branch_from_account(get_field(raw, "AccountNo") or get_field(raw, "LoanNo"))):
                state.field_cleanup_log["BranchId Defaulted to 101"].append({
                    "File": fname, "AdmissionNo": admno, "Account/LoanNo": acct,
                    "Before": "(none available -- no Setup override, no source BranchId, none derivable)",
                    "After": 101})
            if "LedgerFolioNo" in row:
                raw_lf = get_field(raw, "LedgerFolioNo")
                if raw_lf not in (None, "") and str(raw_lf) != str(row["LedgerFolioNo"]):
                    state.field_cleanup_log["LedgerFolioNo Cleanup"].append({
                        "File": fname, "AdmissionNo": admno, "Account/LoanNo": acct,
                        "Before": raw_lf, "After": row["LedgerFolioNo"]})
            # Per-PACS instruction: LoanNo/AccountNo are pure numeric identifiers to the core system --
            # a leftover special character here (e.g. "1125/A") was confirmed as a real cause of
            # transaction rejections, since the Master and Transaction outputs for the same loan could
            # end up with differently-formatted values even though this tool's own internal LoanNo
            # matching already treated them as the same loan. Tracked here with the same Before/After
            # pattern as LedgerFolioNo above, so any account whose identifier had to be corrected is
            # visible for review, not silently changed.
            for id_field in ("LoanNo", "AccountNo"):
                if id_field in row:
                    raw_id = get_field(raw, id_field)
                    if raw_id not in (None, "") and str(raw_id).strip() != str(row[id_field]).strip():
                        state.field_cleanup_log[f"{id_field} Special Character Cleanup"].append({
                            "File": fname, "AdmissionNo": admno, "Account/LoanNo": acct,
                            "Before": raw_id, "After": row[id_field]})
            if "JointAdmissionNo" in row:
                raw_jn = get_field(raw, "JointAdmissionNo")
                if raw_jn is not None and str(raw_jn).strip() in ("0", "0.0") and row["JointAdmissionNo"] == "":
                    state.field_cleanup_log["JointAdmissionNo Cleanup"].append({
                        "File": fname, "AdmissionNo": admno, "Account/LoanNo": acct,
                        "Before": raw_jn, "After": "(blank)"})
            for f in ("ChequeOption", "IsOrganisation"):
                if f in row:
                    raw_v = get_field(raw, f)
                    if raw_v not in (None, "") and str(raw_v).strip() != str(row[f]):
                        state.field_cleanup_log["ChequeOption-IsOrganisation Cleanup"].append({
                            "File": fname, "Field": f, "AdmissionNo": admno, "Account/LoanNo": acct,
                            "Before": raw_v, "After": row[f]})
            if "OperationTypeDesc" in row:
                raw_op = get_field(raw, "OperationTypeDesc")
                if raw_op not in (None, "") and str(raw_op).strip() != str(row["OperationTypeDesc"]):
                    state.field_cleanup_log["OperationTypeDesc Mapping"].append({
                        "File": fname, "AdmissionNo": admno, "Account/LoanNo": acct,
                        "Before": raw_op, "After": row["OperationTypeDesc"]})
            mo["rows"].append(row)
            mo["amount"] += clean_number(get_field(raw, sig["amount"]))

    # Safety check for the LoanNo/AccountNo cleaning above: cleaning can only ever be SAFE if the
    # cleaned result doesn't collide with a genuinely different loan already using that exact number
    # in the same product. Confirmed as a real, important edge case: "1125" and "1125-A" can both be
    # real, distinct loans already present in the same product -- blindly cleaning "1125-A" to "1125"
    # would silently MERGE two different loans into one number, exactly the kind of misassignment the
    # LoanNo-collision fix (build_loan_lookup) exists to prevent elsewhere.
    #
    # Per explicit instruction: when this happens, don't revert to the messy original -- instead,
    # reassign the colliding row to the next unused whole number starting just above the cleaned
    # value (e.g. cleaned to "1125" but already taken -> try 1126, then 1127, ... until one isn't
    # already used by another loan in this same product). Tracked in its own sheet either way, since
    # an auto-assigned number is exactly the kind of change that should be visible and checkable.
    for id_field in ("LoanNo", "AccountNo"):
        log_key = f"{id_field} Special Character Cleanup"
        reassign_key = f"{id_field} Reassigned (collision avoided)"
        for entry in list(state.field_cleanup_log.get(log_key, [])):
            fname = entry["File"]
            mo = state.masters_output.get(fname)
            if not mo:
                continue
            cleaned_val = str(entry["After"]).strip()
            # How many rows in this product currently hold the cleaned value?
            holders = [r for r in mo["rows"] if str(r.get(id_field, "")).strip() == cleaned_val]
            if len(holders) <= 1:
                continue  # no collision -- exactly the row we just cleaned, nothing else to check
            # Find the specific row this log entry came from (by AdmissionNo, among the colliding rows)
            target = next((r for r in holders if str(r.get("AdmissionNo", "")).strip() == str(entry["AdmissionNo"]).strip()), None)
            if target is None:
                continue
            used = {str(r.get(id_field, "")).strip() for r in mo["rows"]}
            try:
                base = int(cleaned_val)
            except (TypeError, ValueError):
                base = None
            new_val = None
            if base is not None:
                candidate = base + 1
                # Reasonable ceiling so a pathological run of consecutive used numbers can't loop
                # forever -- if 10,000 consecutive numbers are all taken, something else is wrong.
                for _ in range(10000):
                    if str(candidate) not in used:
                        new_val = str(candidate)
                        break
                    candidate += 1
            if new_val is None:
                # Couldn't safely find a next number (e.g. non-numeric base) -- fall back to keeping
                # the original value rather than guessing at something that might be wrong.
                new_val = entry["Before"]
            target[id_field] = new_val
            state.field_cleanup_log[log_key].remove(entry)
            state.field_cleanup_log.setdefault(reassign_key, []).append({
                "File": fname, "AdmissionNo": entry["AdmissionNo"], "Account/LoanNo": entry["Before"],
                "Before": entry["Before"], "After": new_val,
                "Reason": f"Cleaning '{entry['Before']}' would have produced '{cleaned_val}', which was "
                          f"already in use by a different loan in this same product -- reassigned to "
                          f"the next unused number, '{new_val}', instead of merging the two."})

    build_loan_lookup(state)
    arithmetic_reports = validate_masters_output(state)
    state.validation_reports = {**state.field_cleanup_log, **arithmetic_reports}
    update_mapping_history(state, ctx)


def validate_masters_output(state: AppState):
    """Report-only pass over the already-built Masters (no mutation): checks the banking date/amount
    arithmetic the person asked us to validate. Every sheet uses ONE consistent set of columns for every
    row (Field / Actual / Expected / Difference / Note) so the report reads cleanly in Excel -- filter,
    sort, or pivot on 'Field' to see just the DueDate problems, just the InstallmentAmount problems, etc.
    Nothing here is silently corrected in the Master output -- these are report-only findings."""
    reports = {"Deposit Calculation Issues": [], "Loan Calculation Issues": [],
               "RD Deep Validation": [], "Deposit Data Quality Issues": [],
               "OperationTypeDesc Unresolved": [], "Account Number Format Errors": []}
    unresolved = scan_operation_type_values(state)
    for u in unresolved:
        if u["RawValue"] in state.operation_type_overrides:
            continue  # already resolved by the user
        reports["OperationTypeDesc Unresolved"].append({
            "RawValue": u["RawValue"], "BestGuess": u["BestGuess"],
            "Confidence": f'{round(u["Confidence"]*100)}%', "OccurrenceCount": u["Count"]})

    def loan_issue(fname, product, row, field, actual, expected, note):
        actual_s = actual.strftime("%d-%m-%Y") if isinstance(actual, _pdt) else actual
        expected_s = expected.strftime("%d-%m-%Y") if isinstance(expected, _pdt) else expected
        diff = ""
        if isinstance(actual, _pdt) and isinstance(expected, _pdt):
            diff = f"{(actual - expected).days} day(s)"
        elif isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
            diff = round(actual - expected, 2)
        reports["Loan Calculation Issues"].append({
            "File": fname, "ProductDescription": product,
            "AdmissionNo": row.get("AdmissionNo", ""), "LoanNo": row.get("LoanNo", ""),
            "SanctionedDate": row.get("SanctionedDate").strftime("%d-%m-%Y") if isinstance(row.get("SanctionedDate"), _pdt) else row.get("SanctionedDate"),
            "RepaymentFrequency": row.get("RepaymentFrequency", ""), "LoanPeriod": row.get("LoanPeriod", ""),
            "Field": field, "Actual": actual_s, "Expected": expected_s, "Difference": diff, "Note": note})

    def deposit_issue(fname, product, row, field, actual, expected, note, reverse_alt=""):
        actual_s = actual.strftime("%d-%m-%Y") if isinstance(actual, _pdt) else actual
        expected_s = expected.strftime("%d-%m-%Y") if isinstance(expected, _pdt) else expected
        reverse_s = reverse_alt.strftime("%d-%m-%Y") if isinstance(reverse_alt, _pdt) else reverse_alt
        diff = ""
        if isinstance(actual, _pdt) and isinstance(expected, _pdt):
            diff = f"{(actual - expected).days} day(s)"
        elif isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
            diff = round(actual - expected, 2)
        reports["Deposit Calculation Issues"].append({
            "File": fname, "ProductDescription": product,
            "AdmissionNo": row.get("AdmissionNo", ""), "AccountNo": row.get("AccountNo", "") or row.get("LoanNo", ""),
            "Field": field, "Actual": actual_s, "Expected": expected_s,
            "Reverse-Calc Alternate": reverse_s, "Difference": diff, "Note": note})

    for fname, mo in state.masters_output.items():
        category = mo["category"]
        product = mo.get("product", fname.replace(".xlsx", ""))
        for row in mo["rows"]:
            admno = row.get("AdmissionNo", "")
            acct = row.get("AccountNo") or row.get("LoanNo") or ""
            acct_field_name = "LoanNo" if row.get("LoanNo") else "AccountNo"

            # Account/Loan number must be plain digits only -- same rule as the Member Number check,
            # applied here across every template (deposits use AccountNo, loans use LoanNo). Reported
            # per-template (the "File"/"ProductDescription" columns) so it's clear exactly where each
            # bad value lives, as requested.
            acct_str = str(acct).strip()
            if acct_str and re.match(r"^\d+\.0$", acct_str):
                acct_str = acct_str[:-2]  # Excel float artifact, e.g. "12345.0" -> "12345"
            if acct_str and not re.match(r"^\d+$", acct_str):
                reports["Account Number Format Errors"].append({
                    "File": fname, "ProductDescription": product, "AdmissionNo": admno,
                    "Field": acct_field_name, "Value (as entered)": acct,
                    "Reason": "Contains letters or special characters -- must be numeric only" if re.search(r"\d", acct_str)
                              else "Contains no digits at all -- must be numeric only",
                })

            if category in ("FD", "RD"):
                dep_date, td, tm = row.get("DepositDate"), row.get("TerminDays"), row.get("TerminMonths")
                maturity_date = row.get("MaturityDate")

                # Forward calc: MaturityDate expected FROM DepositDate + Term
                expected_md = None
                try:
                    if dep_date and td and float(td) > 0:
                        expected_md = dep_date + _ptd(days=float(td))
                    elif dep_date and tm and float(tm) > 0:
                        expected_md = add_months(dep_date, tm)
                except Exception:
                    expected_md = None

                # Reverse calc: some renewed deposits store the RENEWAL/transaction date in DepositDate
                # rather than the true original start date, which breaks the forward check above. So we
                # also compute what DepositDate *should* have been, working backward from MaturityDate,
                # and surface it as an alternate for the person to compare against.
                expected_dep_date = None
                try:
                    if maturity_date and td and float(td) > 0:
                        expected_dep_date = maturity_date - _ptd(days=float(td))
                    elif maturity_date and tm and float(tm) > 0:
                        expected_dep_date = add_months(maturity_date, -float(tm))
                except Exception:
                    expected_dep_date = None

                if expected_md and maturity_date and abs((expected_md - maturity_date).days) > 2:
                    deposit_issue(fname, product, row, "MaturityDate", maturity_date, expected_md,
                        "MaturityDate = DepositDate + Term. If this deposit was renewed, DepositDate may "
                        "hold the renewal/transaction date rather than the true start date -- see the "
                        "reverse-calculated alternate DepositDate.", reverse_alt=expected_dep_date)

                dep_amt = clean_number(row.get("DepositAmount"))
                int_amt = clean_number(row.get("InterestAmount"))
                inst_amt = clean_number(row.get("InstallmentAmount"))
                dep_type = str(row.get("DepositTypeDesc", ""))
                principal_base = inst_amt * float(tm or 0) if "Install" in dep_type else dep_amt
                expected_ma = principal_base + int_amt
                actual_ma = clean_number(row.get("MaturityAmount"))
                if expected_ma and abs(actual_ma - expected_ma) > max(1.0, 0.02 * abs(expected_ma)):
                    note = ("MaturityAmount = DepositAmount + InterestAmount." if "Install" not in dep_type else
                            "MaturityAmount = (InstallmentAmount x TerminMonths) + InterestAmount for installment-type deposits.")
                    deposit_issue(fname, product, row, "MaturityAmount", actual_ma, round(expected_ma, 2), note)

                # Confirmed on real data: the core system rejects a deposit outright if MaturityAmount
                # is zero/blank, or if DepositAmount isn't strictly less than MaturityAmount for a
                # true lump-sum (non-installment) deposit -- a maturity value that doesn't exceed the
                # principal makes no sense for an interest-bearing deposit.
                if actual_ma <= 0:
                    deposit_issue(fname, product, row, "MaturityAmount (zero or blank)", actual_ma, None,
                        "MaturityAmount must be greater than zero -- the core system rejects this "
                        "outright.")
                elif "Install" not in dep_type and dep_amt and dep_amt >= actual_ma:
                    deposit_issue(fname, product, row, "DepositAmount vs MaturityAmount", dep_amt, actual_ma,
                        "DepositAmount must be less than MaturityAmount for a lump-sum deposit -- the "
                        "core system rejects this outright when it isn't.")

            if category == "RD":
                _rd_deep_validation(fname, product, row, reports["RD Deep Validation"])

            if category in ("FD", "RD", "SB"):
                _deposit_data_quality(fname, product, category, row, reports["Deposit Data Quality Issues"])

            if category in LOAN_CATEGORIES:
                sd, lp, dd = row.get("SanctionedDate"), row.get("LoanPeriod"), row.get("DueDate")
                try:
                    lp_f = float(lp) if lp not in (None, "") else None
                except (TypeError, ValueError):
                    lp_f = None

                # SanctionedDate is always treated as the fixed anchor -- every other loan date is
                # derived FROM it, never the other way around.
                expected_dd = add_months(sd, lp_f) if (sd and lp_f) else None
                if expected_dd and dd and abs((expected_dd - dd).days) > 2:
                    loan_issue(fname, product, row, "DueDate", dd, expected_dd,
                        "DueDate = SanctionedDate + LoanPeriod (months). SanctionedDate is fixed -- "
                        "correct DueDate, not SanctionedDate.")

                freq = row.get("RepaymentFrequency")
                fid = row.get("FirstInstallmentDate")
                freq_m = frequency_to_months(freq) if freq else None

                # Confirmed on real data: the core system rejects a loan outright when LoanPeriod
                # isn't an exact multiple of the RepaymentFrequency's period length -- e.g. LoanPeriod
                # 11 with a Yearly (12-month) frequency ("Loan Period: 11, Loan period should match
                # the Repayment frequency"). This is a hard upload-blocking error, not a soft
                # calculation mismatch, so it's worth its own explicit check.
                if lp_f and freq_m and lp_f % freq_m != 0:
                    loan_issue(fname, product, row, "LoanPeriod vs RepaymentFrequency", lp_f, None,
                        f"LoanPeriod ({lp_f:.0f} months) is not an exact multiple of the "
                        f"RepaymentFrequency period ({row.get('RepaymentFrequency','?')} = "
                        f"{freq_m} months). The core system rejects this upload outright -- "
                        f"LoanPeriod must be a whole multiple of the frequency period.")

                # Confirmed on real data: a loan can't be sanctioned before the member even joined
                # ("Admission Date is greater than Sanction Date or invalid Admission Date"). Only
                # checked when the member's own AdmissionDate is actually available.
                #
                # BUG FIX: this crashed generate_masters() outright on real data -- confirmed the
                # actual cause was a type mismatch, not a logic error: the Membership output stores
                # AdmissionDate as a formatted display string (e.g. "31/03/2002"), while this loan
                # row's SanctionedDate is already a parsed datetime by this point. Comparing the two
                # directly raised TypeError and stopped Masters generation mid-way -- which also meant
                # every audit-trail sheet that's built AFTER this point in the same function (LoanNo
                # cleaning, BranchId defaulting, Transaction AdmissionNo correction, etc.) never got
                # written at all, since the crash happened before the report was ever saved. Both
                # sides are now normalized through clean_date() before comparing, regardless of
                # whether either one happens to already be a datetime or still a string.
                member_adm_date_raw = state.membership_admission_dates.get(str(admno).strip())
                member_adm_date = clean_date(member_adm_date_raw) if member_adm_date_raw else None
                sd_parsed = clean_date(sd) if sd else None
                if member_adm_date and sd_parsed and member_adm_date > sd_parsed:
                    loan_issue(fname, product, row, "SanctionedDate vs member AdmissionDate", sd, member_adm_date,
                        "This loan's SanctionedDate falls BEFORE the member's own AdmissionDate -- "
                        "the core system rejects this outright. Check whether AdmissionDate or "
                        "SanctionedDate is the one that's wrong for this member.")

                # Confirmed on real data: negative OutstandingInterest / OutstandingPenalInterest are
                # rejected outright ("Invalid Outstanding Interest Amount: -1018"). clean_number()
                # must be called with allow_negative=True here -- its default silently strips the
                # sign via abs(), which would make this check never fire regardless of input.
                oi = row.get("OutstandingInterest")
                opi = row.get("OutstandingPenalInterest")
                if oi not in (None, "") and clean_number(oi, allow_negative=True) < 0:
                    loan_issue(fname, product, row, "OutstandingInterest (negative)", clean_number(oi, allow_negative=True), 0,
                        "OutstandingInterest is negative -- the core system rejects this outright. "
                        "Check the source calculation for this loan.")
                if opi not in (None, "") and clean_number(opi, allow_negative=True) < 0:
                    loan_issue(fname, product, row, "OutstandingPenalInterest (negative)", clean_number(opi, allow_negative=True), 0,
                        "OutstandingPenalInterest is negative -- the core system rejects this outright. "
                        "Check the source calculation for this loan.")

                expected_fid = add_months(sd, freq_m) if (sd and freq_m) else None
                if expected_fid and fid and abs((expected_fid - fid).days) > 2:
                    loan_issue(fname, product, row, "FirstInstallmentDate", fid, expected_fid,
                        "FirstInstallmentDate = SanctionedDate + one RepaymentFrequency period "
                        "(Monthly=+1mo, Quarterly=+3mo, Halfyearly=+6mo, Yearly=+12mo). SanctionedDate is fixed.")
                # Sanity boundary: the first installment can't legitimately fall after the loan's own
                # DueDate (which itself comes from SanctionedDate + LoanPeriod).
                if fid and expected_dd and fid > expected_dd:
                    loan_issue(fname, product, row, "FirstInstallmentDate (out of range)", fid, expected_dd,
                        "FirstInstallmentDate falls AFTER the loan's own DueDate (SanctionedDate + "
                        "LoanPeriod) -- check RepaymentFrequency and LoanPeriod for this loan.")

                sa = clean_number(row.get("SanctionedAmount"))
                ia = clean_number(row.get("InstallmentAmount"))
                if sa and lp_f and freq_m and ia:
                    n_installments = max(1, round(lp_f / freq_m))
                    expected_ia = sa / n_installments
                    if abs(ia - expected_ia) > max(1.0, 0.05 * expected_ia):
                        loan_issue(fname, product, row, "InstallmentAmount", ia, round(expected_ia, 2),
                            f"InstallmentAmount = SanctionedAmount / number of installments, where the "
                            f"installment count comes from LoanPeriod split into RepaymentFrequency periods "
                            f"({row.get('RepaymentFrequency','?')}: {n_installments} installment(s) over "
                            f"{lp_f:.0f} month(s)). Changing RepaymentFrequency changes this expected amount.")
    return reports


def _rd_deep_validation(fname, product, row, out):
    """RD-specific checks beyond the generic Deposit Calculation Issues above."""
    admno, acct = row.get("AdmissionNo", ""), row.get("AccountNo", "")

    def flag(check, result, detail):
        out.append({"File": fname, "ProductDescription": product, "AdmissionNo": admno, "AccountNo": acct,
                     "Check": check, "Result": result, "Detail": detail})

    dep_type = str(row.get("DepositTypeDesc", ""))
    if "Install" not in dep_type:
        flag("DepositTypeDesc", "Review", f"RD account has DepositTypeDesc='{dep_type}' -- RD accounts "
             f"are normally 'Installment Type' (a fixed amount paid every period).")

    inst_amt = clean_number(row.get("InstallmentAmount"))
    if inst_amt <= 0:
        flag("InstallmentAmount", "Missing/Zero", "RD account has no positive InstallmentAmount -- an RD "
             "must have a periodic installment amount.")

    tm = row.get("TerminMonths")
    try:
        tm_f = float(tm) if tm not in (None, "") else 0
    except (TypeError, ValueError):
        tm_f = 0
    if tm_f <= 0:
        flag("TerminMonths", "Missing/Zero", "RD account has no TerminMonths -- required to know how many "
             "installments are expected and to compute MaturityDate.")

    int_amt = clean_number(row.get("InterestAmount"))
    # BUG FIX: this used InstallmentAmount * TerminMonths (the total PLANNED tenure) as "principal paid
    # in", but TerminMonths is the full term length, not how many installments have actually been paid
    # -- the message text itself says "total installments paid in", which is InstallmentsPaid, not
    # TerminMonths. For an account partway through its tenure (e.g. 10 of 24 months), this overstated
    # the paid-in principal by using the full 24-month tenure, which could mask a genuinely high
    # InterestAmount-to-principal ratio that this check exists to catch. Now matches the same
    # InstallmentAmount * InstallmentsPaid calculation compute_correct_deposit_amount() already uses
    # correctly elsewhere in this file.
    paid_raw = row.get("InstallmentsPaid")
    try:
        paid = float(paid_raw) if paid_raw not in (None, "") else 0
    except (TypeError, ValueError):
        paid = 0
    principal = inst_amt * paid
    if principal > 0 and int_amt > 0 and int_amt > 0.5 * principal:
        flag("InterestAmount", "Review", f"InterestAmount ({int_amt:,.2f}) is unusually high relative to "
             f"total installments paid in ({principal:,.2f}) -- worth a manual sanity check.")

    # Best-effort interpretation of a real, but ambiguously-worded, core-system error message
    # ("TotalInstallmentAmountPaid should be : <AdmissionNo>") -- the number in that message matches
    # the record's own AdmissionNo, not a calculated figure, so the literal text isn't usable as a
    # target value. The sensible, standard formula this is checking is InstallmentAmount x
    # InstallmentsPaid; flagged as Review rather than a hard failure since the exact real-system rule
    # wasn't fully confirmed.
    total_paid = clean_number(row.get("TotalInstallmentAmountPaid"))
    if inst_amt > 0 and paid > 0 and total_paid > 0:
        expected_total = inst_amt * paid
        # Tolerance tightened to 1% after testing against the actual real-world failing record this
        # rule is based on (InstallmentAmount=100, InstallmentsPaid=26, TotalInstallmentAmountPaid=
        # 2550 vs expected 2600 -- a 1.92% gap that a looser 2% tolerance would have missed entirely).
        if abs(total_paid - expected_total) > max(1.0, 0.01 * expected_total):
            flag("TotalInstallmentAmountPaid", "Review",
                 f"TotalInstallmentAmountPaid ({total_paid:,.2f}) does not match InstallmentAmount x "
                 f"InstallmentsPaid ({inst_amt:,.2f} x {paid:.0f} = {expected_total:,.2f}) -- the core "
                 f"system flags a mismatch here, though the exact expected-value rule wasn't fully "
                 f"confirmed from the source error message alone.")

    op = row.get("OperationTypeDesc", "")
    if op and op not in OPERATION_TYPE_ENUM:
        flag("OperationTypeDesc", "Invalid", f"'{op}' is not one of the allowed OperationTypeDesc values.")


def _deposit_data_quality(fname, product, category, row, out):
    """Broader data-quality sweep across FD/RD/SB: missing or out-of-range fields that don't fit the
    date/amount arithmetic checks above but would still fail core-banking validation on upload."""
    admno, acct = row.get("AdmissionNo", ""), row.get("AccountNo", "")

    def flag(field, problem):
        out.append({"File": fname, "ProductDescription": product, "AdmissionNo": admno, "AccountNo": acct,
                     "Field": field, "Problem": problem})

    if not str(acct or "").strip():
        flag("AccountNo", "Missing AccountNo")
    if category in ("FD", "RD"):
        dep_amt = clean_number(row.get("DepositAmount"))
        dep_type = str(row.get("DepositTypeDesc", ""))
        if "Install" not in dep_type and dep_amt <= 0:
            flag("DepositAmount", "Missing or zero DepositAmount for a non-installment deposit")
        elif "Install" in dep_type and dep_amt <= 0:
            # Confirmed real case: a Compulsory/Installment Type deposit whose DepositAmount comes out
            # 0 after compute_correct_deposit_amount() has already tried TotalInstallmentAmountPaid,
            # the raw DepositAmount, and InstallmentAmount*InstallmentsPaid -- if it's STILL 0 here,
            # none of those fields had usable data in the source for this specific account. That's a
            # genuine "nothing to fall back to" situation, not something the formula can fix; flagging
            # it explicitly means it's visible in the report instead of silently uploading a 0 balance.
            flag("DepositAmount", "Installment Type deposit has DepositAmount=0 even after checking "
                 "TotalInstallmentAmountPaid and InstallmentAmount\u00d7InstallmentsPaid -- none of "
                 "these had usable data in the source for this account; check the source row directly.")
        if not row.get("DepositDate"):
            flag("DepositDate", "Missing DepositDate")
        if not row.get("MaturityDate"):
            flag("MaturityDate", "Missing MaturityDate")
        int_amt = clean_number(row.get("InterestAmount"), allow_negative=True)
        if int_amt < 0:
            flag("InterestAmount", f"Negative InterestAmount ({int_amt})")
        rate = row.get("InterestRate")
        if rate not in (None, ""):
            try:
                rate_f = float(rate)
                if rate_f < 0 or rate_f > 15:
                    flag("InterestRate", f"InterestRate {rate_f}% is outside the typical 0-15% range -- please verify")
            except (TypeError, ValueError):
                flag("InterestRate", f"InterestRate '{rate}' is not numeric")
    if category == "SB":
        for f in ("ChequeOption", "IsOrganisation"):
            if row.get(f) not in ("Yes", "No"):
                flag(f, f"'{row.get(f)}' is not Yes/No after normalization")


def build_tally_report(state: AppState):
    """Transaction Tally Report: for every mapped product, checks two separate things --
    (1) COMPLETENESS: did every transaction row destined for this product actually make it into the
        output (none silently dropped or left unmatched)? A missing row here means every other ledger
        figure for that product (principal, interest, balances) will be wrong even if the ones that DID
        come through look fine.
    (2) AMOUNT TALLY: does the Master's outstanding balance line up with the Transaction side's running
        balance for this product?
    A product failing on completeness is flagged as the more serious problem, since it means data is
    missing entirely rather than just slightly mismatched."""
    rows = []
    all_fnames = set(state.masters_output.keys()) | set(state.trans_product_stats.keys())
    for fname in all_fnames:
        mo = state.masters_output.get(fname)
        stats = state.trans_product_stats.get(fname, {})
        product = (mo.get("product") if mo else stats.get("product")) or fname.replace(".xlsx", "")
        master_accounts = len(mo["rows"]) if mo else 0
        master_total = sum(clean_number(r.get("SanctionedAmount") or r.get("DepositAmount") or 0)
                            for r in mo["rows"]) if mo else 0
        master_outstanding = sum(clean_number(r.get("OutstandingPrincipal") or r.get("MaturityAmount") or 0)
                                  for r in mo["rows"]) if mo else 0

        raw_rows = stats.get("raw_rows", 0)
        kept = stats.get("kept", 0)
        dropped_zero = stats.get("dropped_zero_amount", 0)
        matched = stats.get("matched_to_master", 0)
        unmatched = stats.get("unmatched_loanno", 0)
        trans_rows = state.trans_output.get(fname, [])
        trans_disb = sum(clean_number(r.get("DisbursementAmount", 0)) for r in trans_rows)
        trans_collected = sum(clean_number(r.get("CollectedPrincipal", 0)) for r in trans_rows)
        # FIX: BalancePrincipal is a running-balance snapshot on every transaction row, not an
        # independent amount -- summing it across a product's transactions inflates the total by
        # roughly however many transactions each account had (confirmed against real data: one loan
        # with 53 transactions was being counted 53 times). Use each account's latest value instead.
        trans_balance = latest_balance_per_account(trans_rows, "BalancePrincipal")

        if raw_rows == 0:
            completeness = "N/A -- no transactions found for this product"
        elif unmatched > 0:
            completeness = f"CHECK -- {unmatched} of {raw_rows} row(s) had a LoanNo not found in Masters"
        else:
            completeness = f"OK -- all {raw_rows} row(s) matched to a Master account"

        if not trans_rows:
            tallied = "N/A -- no transactions for this product"
        elif master_outstanding == 0 and trans_balance == 0:
            tallied = "Yes"
        elif master_outstanding == 0:
            tallied = "No -- Master OutstandingPrincipal is 0 but Transactions show a balance"
        else:
            diff_pct = abs(master_outstanding - trans_balance) / max(1.0, abs(master_outstanding))
            tallied = "Yes" if diff_pct <= 0.05 else f"No -- {diff_pct*100:.1f}% difference"

        rows.append({
            "ProductDescription": product, "Master File": fname, "Master Accounts": master_accounts,
            "Raw Transaction Rows": raw_rows, "Kept (nonzero amount)": kept,
            "Dropped (zero amount)": dropped_zero, "Matched to Master": matched,
            "Unmatched LoanNo": unmatched, "Completeness": completeness,
            "Master Total (Sanctioned/Deposit)": round(master_total, 2),
            "Master OutstandingPrincipal/Maturity": round(master_outstanding, 2),
            "Transaction Disbursement Total": round(trans_disb, 2),
            "Transaction Collected Principal Total": round(trans_collected, 2),
            "Transaction BalancePrincipal (latest per account, summed)": round(trans_balance, 2),
            "Amount Tallied?": tallied,
        })
    return sorted(rows, key=lambda r: r["ProductDescription"])



def build_loan_lookup(state: AppState):
    """Maps LoanNo -> list of every Master record carrying that LoanNo, across every loan category.

    BUG FIX: this used to store a single dict per LoanNo, silently OVERWRITTEN whenever a later
    category's Master happened to reuse the same LoanNo -- confirmed on real data that a bank's core
    system does NOT guarantee LoanNo is unique across different loan products (e.g. a Deposit Loan and
    an Overdraft Loan each independently used LoanNo "3126" for two different members). Whichever
    category got written last silently won, so a transaction genuinely belonging to the other
    category (with its own correct AdmissionNo) got misassigned to the wrong product entirely --
    confirmed against real Tools Analyzer rejection data ("Could not find Application Details") where
    the misassigned transaction's real AdmissionNo made no sense for the product it landed in.

    Now stores every candidate under that LoanNo; process_transactions() disambiguates using the
    transaction's own AdmissionNo (an exact identifier) whenever a LoanNo has more than one candidate,
    instead of just taking whichever was seen last."""
    state.loan_lookup = {}
    for fname, mo in state.masters_output.items():
        if mo["category"] not in LOAN_CATEGORIES:
            continue
        for r in mo["rows"]:
            loan = digits_only(r.get("LoanNo"))
            if not loan:
                continue
            state.loan_lookup.setdefault(loan, []).append({
                "product": r.get("ProductDescription"),
                "purpose": r.get("CropDescription") or r.get("PurposeDescription") or "",
                "branch": r.get("BranchId"),
                "admission_no": digits_only(r.get("AdmissionNo")),
            })

AMOUNT_COLS = ["DisbursementAmount","CollectedPrincipal","CollectedInterest","CollectedPenalInterest",
               "CollectedIOD","CollectedOthers","OtherChargesDebitAmount","Charges"]

def process_transactions(state: AppState):
    state.trans_output = {}
    state.trans_unmatched = {}
    state.trans_ambiguous_loanno = {}  # LoanNo -> details, when a collision couldn't be resolved
    # Per-product (per Master filename) completeness tracking -- this is what lets the Transaction
    # Tally Report answer "did every transaction row for this product actually make it into the
    # output," not just "do the totals happen to match." A row that silently vanished (e.g. because
    # its LoanNo didn't resolve to any product) would otherwise only show up as a small amount
    # discrepancy that's easy to miss -- here it's counted explicitly.
    state.trans_product_stats = {}
    counters = {}
    kept = dropped = matched = 0
    for raw in state.trans_rows:
        has_amount = False
        for k in AMOUNT_COLS:
            v = get_field(raw, k)
            if v not in (None, "") and clean_number(v, allow_negative=True) != 0:
                has_amount = True
                break

        loan = digits_only(get_field(raw, "LoanNo"))
        candidates = state.loan_lookup.get(loan) or []
        lookup = None
        if len(candidates) == 1:
            lookup = candidates[0]
        elif len(candidates) > 1:
            # Collision: this LoanNo exists in more than one loan category. Disambiguate using the
            # transaction's OWN AdmissionNo -- an exact identifier, unlike fuzzy-matching product text.
            txn_admno = digits_only(get_field(raw, "AdmissionNo"))
            exact = [c for c in candidates if txn_admno and c["admission_no"] == txn_admno]
            if len(exact) == 1:
                lookup = exact[0]
            else:
                # AdmissionNo alone didn't resolve it uniquely -- record this instead of guessing.
                # Silently picking the wrong one here is worse than flagging it for a human to check,
                # given this affects which member and which product a real transaction lands under.
                state.trans_ambiguous_loanno[loan] = {
                    "candidates": [(c["product"], c["admission_no"]) for c in candidates],
                    "transaction_admission_no": txn_admno,
                }
        if lookup:
            product, purpose, branch = lookup["product"], lookup["purpose"], lookup["branch"]
            # BUG FIX: this used to leave AdmissionNo untouched, blindly copying whatever the raw
            # transaction row itself said -- even after a genuine match was found against the
            # authoritative Master record. Confirmed as the likely real cause of a whole product's
            # worth of "Could not find Application Details" rejections: the source transaction file's
            # own AdmissionNo (e.g. "1828") didn't match the actual loan owner recorded in the Master
            # ("867" for the same LoanNo) -- the core system's own rejection message cited the wrong,
            # unmatched value verbatim. Product/Purpose/Branch were already being corrected from the
            # matched Master; AdmissionNo needs the exact same treatment, since the Master is the
            # authoritative record of which member a given LoanNo actually belongs to.
            correct_admno = lookup["admission_no"]
            txn_own_admno = digits_only(get_field(raw, "AdmissionNo"))
            if correct_admno and txn_own_admno and correct_admno != txn_own_admno:
                state.field_cleanup_log.setdefault("Transaction AdmissionNo Corrected", []).append({
                    "File": product_master_filename(product), "AdmissionNo": correct_admno,
                    "Account/LoanNo": loan, "Before": get_field(raw, "AdmissionNo"), "After": correct_admno,
                    "Reason": f"Transaction's own AdmissionNo ({txn_own_admno}) didn't match the Master "
                              f"record's owner ({correct_admno}) for LoanNo {loan} -- corrected to the "
                              f"Master's value, which is authoritative for who a loan actually belongs to."})
            admission = correct_admno or get_field(raw, "AdmissionNo")
            is_matched = True
        else:
            product = get_field(raw, "ProductDescription") or "Unknown"
            purpose = get_field(raw, "PurposeDescription") or "Unknown"
            admission = get_field(raw, "AdmissionNo")
            # Same priority fix as build_master_row() above -- the Setup override wins when set.
            explicit_branch = valid_branch(state.default_branch)
            branch = (explicit_branch or valid_branch(get_field(raw, "BranchId"))
                      or derive_branch_from_account(get_field(raw, "LoanNo")) or 101)
            is_matched = False

        fname = product_master_filename(product)
        stats = state.trans_product_stats.setdefault(fname, {
            "product": product, "raw_rows": 0, "kept": 0, "dropped_zero_amount": 0,
            "matched_to_master": 0, "unmatched_loanno": 0})
        stats["raw_rows"] += 1

        if not has_amount:
            dropped += 1
            stats["dropped_zero_amount"] += 1
            continue
        kept += 1
        stats["kept"] += 1
        if is_matched:
            matched += 1
            stats["matched_to_master"] += 1
        else:
            stats["unmatched_loanno"] += 1
            ukey = loan or "(blank)"
            state.trans_unmatched[ukey] = state.trans_unmatched.get(ukey, 0) + 1

        out = {}
        for key in TRANSACTION_TEMPLATE:
            if key == "ProductDescription":
                val = product
            elif key == "PurposeDescription":
                val = purpose
            elif key == "BranchId":
                val = branch
            elif key == "AdmissionNo":
                val = admission
            elif key == "PacsId":
                val = get_field(raw, "PacsId") or state.pacs_id
            elif key == "TransactionDate":
                val = clean_date(get_field(raw, key))
            elif key in ("DisbursementAmount","OtherChargesDebitAmount","CollectedPrincipal","CollectedInterest",
                         "CollectedPenalInterest","CollectedIOD","CollectedOthers","BalancePrincipal",
                         "BalanceInterest","BalancePenalInterest","BalanceIOD","Charges"):
                val = clean_number(get_field(raw, key))
            elif key == "LedgerFolioNo":
                raw_lf = get_field(raw, key)
                val = clean_special_chars(raw_lf) if raw_lf not in (None, "") else (raw_lf if raw_lf is not None else "")
            elif key == "LoanNo":
                # Same fix as build_master_row(), applied consistently here too -- per explicit
                # instruction, this must clean identically in both Master and Transaction output,
                # or the two can end up with differently-formatted LoanNo values for the same loan,
                # which is what caused real "Could not find Application Details" rejections.
                raw_ln = get_field(raw, key)
                if raw_ln not in (None, ""):
                    cleaned_ln = digits_only(raw_ln)
                    val = cleaned_ln if cleaned_ln else raw_ln
                    if str(raw_ln).strip() != str(val).strip():
                        state.field_cleanup_log.setdefault("LoanNo Special Character Cleanup", []).append({
                            "File": product_master_filename(product), "AdmissionNo": get_field(raw, "AdmissionNo") or "",
                            "Account/LoanNo": raw_ln, "Before": raw_ln, "After": val})
                else:
                    val = ""
            else:
                val = get_field(raw, key)
                if val is None:
                    val = ""
            out[key] = val
        # Same filename convention as Split_By_Products ("Normal KCC.xlsx" etc.) so every product has a
        # matching Masters file and Transactions file -- this is what makes the tally check possible.
        fname = product_master_filename(product)
        counters[fname] = counters.get(fname, 0) + 1
        state.trans_output.setdefault(fname, []).append(out)

    state.trans_kept, state.trans_dropped, state.trans_matched = kept, dropped, matched
    # Safety net: a genuinely-real transaction file having EVERY row drop as "zero amount" is
    # statistically implausible -- confirmed against several real datasets where kept/matched rates
    # were consistently 99%+. A rate this low almost always means none of AMOUNT_COLS' column-name
    # aliases matched this particular source file's naming at all (a gap our alias list doesn't cover
    # yet), not that the PACS genuinely has thousands of zero-value transactions. Surface this loudly
    # instead of letting it look like a routine, unremarkable drop count.
    total = kept + dropped
    state.trans_all_dropped_warning = None
    if total > 20 and kept == 0:
        sample_cols = list(state.trans_rows[0].keys()) if state.trans_rows else []
        state.trans_all_dropped_warning = (
            f"ALL {dropped} transaction row(s) were dropped as zero-amount -- this is almost certainly "
            f"because none of the expected amount column names (DisbursementAmount, CollectedPrincipal, "
            f"CollectedInterest, CollectedPenalInterest, CollectedIOD, CollectedOthers, "
            f"OtherChargesDebitAmount, Charges) were found in this source file, not because the PACS "
            f"genuinely has zero real transactions. The source file's actual columns are: "
            f"{sample_cols}. Compare these against the expected names above and let us know the actual "
            f"column names so they can be added to the recognized list."
        )


DATE_FIELDS = {"SanctionedDate","DueDate","FirstInstallmentDate","LCDate","DepositDate","MaturityDate",
               "LastPaidInstallDate","LastInterestPostingDate","TransactionDate",
               "DOB","AdmissionDate","GPAIssueDate"}

def write_dataframe_xlsx(path, rows, columns):
    df = pd.DataFrame(rows)
    for c in columns:
        if c not in df.columns:
            df[c] = None
    df = df[columns] if len(df) else pd.DataFrame(columns=columns)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
        ws = writer.sheets[writer.sheets and list(writer.sheets.keys())[0]]
        for col_idx, col_name in enumerate(columns, start=1):
            if col_name in DATE_FIELDS:
                for row_idx in range(2, len(df) + 2):
                    cell = ws.cell(row=row_idx, column=col_idx)
                    if isinstance(cell.value, _pdt):
                        cell.number_format = "DD-MM-YYYY"

def export_zip(state: AppState, out_dir: Path):
    root_name = sanitize_filename(f"{state.pacs_name}_{state.pacs_id}")
    root = out_dir / root_name
    masters_dir = root / "Masters"
    trans_dir = root / "Transactions"
    reports_dir = root / "Reports"
    for d in (masters_dir, trans_dir, reports_dir):
        d.mkdir(parents=True, exist_ok=True)

    for fname, mo in state.masters_output.items():
        write_dataframe_xlsx(masters_dir / fname, mo["rows"], MASTER_TEMPLATES[mo["category"]])

    for fname, rows in state.trans_output.items():
        write_dataframe_xlsx(trans_dir / fname, rows, TRANSACTION_TEMPLATE)

    map_rows = [{"Category": CATEGORY_LABEL.get(c["category"], c["category"]), "RawProduct": c["rawProduct"],
                 "RawSecond": c["rawSecond"], "MappedProduct": c["mappedProduct"], "MappedSecond": c["mappedSecond"],
                 "Accounts": c["count"], "Amount": round(c["amount"]), "Confidence": f'{round(c["confidence"]*100)}%'}
                for c in state.combos.values() if c.get("mappedProduct")]
    masters_rows = [{"File": f, "Category": CATEGORY_LABEL.get(mo["category"]), "Accounts": len(mo["rows"]), "Amount": round(mo["amount"])}
                     for f, mo in state.masters_output.items()]
    trans_rows_summary = [{"File": f, "Rows": len(rows)} for f, rows in state.trans_output.items()]
    unmatched_rows = [{"LoanNo": k, "RowsAffected": v} for k, v in state.trans_unmatched.items()]
    ambiguous_rows = [{"LoanNo": k, "Transaction's own AdmissionNo": v["transaction_admission_no"],
                       "Candidates found (Product, AdmissionNo)": str(v["candidates"])}
                      for k, v in state.trans_ambiguous_loanno.items()]

    report_path = reports_dir / "Mapping_Audit_Report.xlsx"
    with pd.ExcelWriter(report_path, engine="openpyxl") as writer:
        pd.DataFrame(map_rows).to_excel(writer, sheet_name="Mapping", index=False)
        pd.DataFrame(masters_rows).to_excel(writer, sheet_name="Masters", index=False)
        pd.DataFrame(trans_rows_summary).to_excel(writer, sheet_name="Transactions", index=False)
        pd.DataFrame(unmatched_rows).to_excel(writer, sheet_name="Unmatched_LoanNo", index=False)
        # Confirmed real bug: LoanNo is not guaranteed unique across different loan categories at
        # this bank -- the same number can be independently assigned to two different loans (e.g. a
        # Deposit Loan and an Overdraft Loan). AdmissionNo now resolves this automatically in the vast
        # majority of cases; this sheet only ever has rows in the rare case that even AdmissionNo
        # couldn't disambiguate, which needs a human to check which loan a transaction really belongs to.
        pd.DataFrame(ambiguous_rows or [{"Info": "No unresolved LoanNo collisions"}]).to_excel(
            writer, sheet_name="Ambiguous_LoanNo", index=False)

    zip_path = out_dir / f"{root_name}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for folder in (masters_dir, trans_dir, reports_dir):
            for f in folder.rglob("*"):
                zf.write(f, f.relative_to(out_dir))
    return zip_path


# =====================================================================
# AI ASSIST (optional — needs ANTHROPIC_API_KEY env var + `requests`)
# =====================================================================
def ask_ai_for_mapping(items):
    """items: list of {key, category, rawProduct, rawSecond, productOptions, secondOptions}
    returns list of {key, mappedProduct, mappedSecond, confidence}"""
    if not HAVE_REQUESTS:
        raise RuntimeError("The 'requests' package is not installed (pip install requests).")
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("Set the ANTHROPIC_API_KEY environment variable to use Ask AI.")
    sys_prompt = ("You are helping map raw core-banking product/purpose/crop names from an Indian PACS "
                  "(cooperative society) core banking export onto a fixed canonical taxonomy. For each item, "
                  "pick the single best matching value from productOptions (and from secondOptions if provided), "
                  "or if truly nothing fits well, propose a short sensible canonical-style name. Respond ONLY with "
                  "a JSON array, no prose, no markdown fences, in the same order as input, each element: "
                  '{"key":str, "mappedProduct":str, "mappedSecond":str or null, "confidence":0-1}.')
    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
        json={"model": "claude-sonnet-4-6", "max_tokens": 4000, "system": sys_prompt,
              "messages": [{"role": "user", "content": json.dumps(items)}]},
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    clean = re.sub(r"```json|```", "", text).strip()
    return json.loads(clean)



# =====================================================================
# CLEAN OUTPUT: ONE consolidated 4-folder structure, replacing the old scattered
# output (raw *_Raw.xlsx files + Split_By_Product + Split_By_MemberType + a
# separate zip-only Masters/Transactions/Reports export). No source/raw files are
# written to the final output at all -- only what the branch actually needs:
#
#   Split_By_Member/        Membership, split by member type
#   Split_By_Products/       One workbook per mapped PRODUCT (e.g. "Normal KCC.xlsx")
#   Split_By_Transactions/   Loan transactions, split by the SAME product filenames
#                            as Split_By_Products (matched to Masters by LoanNo) --
#                            this 1:1 filename match is what makes the Tally Check work.
#   Reports/                 Mapping_Audit_Report.xlsx + Validation_Report.xlsx
# =====================================================================

TRANSACTION_SUMMARY_FIELDS = ["DisbursementAmount", "OtherChargesDebitAmount", "CollectedPrincipal",
    "CollectedInterest", "CollectedPenalInterest", "CollectedIOD", "CollectedOthers", "Charges"]
# These four are running-BALANCE snapshots recorded on every transaction row (each row shows what the
# account's balance was on that date) -- summing them across a product's transactions is meaningless
# and produces wildly inflated numbers (a single loan with 50 transactions would count its own balance
# 50 times over). They need the "latest value per account, then summed across accounts" treatment
# instead -- see latest_balance_per_account() below.
TRANSACTION_BALANCE_FIELDS = ["BalancePrincipal", "BalanceInterest", "BalancePenalInterest", "BalanceIOD"]


def latest_balance_per_account(trans_rows, field):
    """For a running-balance field, each transaction row is a snapshot of ONE account's balance at a
    point in time -- not an independent amount to add up. This takes each account's (LoanNo, or
    AdmissionNo if LoanNo is blank) most recent value by TransactionDate and sums those per-account
    latest values, which is what's actually comparable to a Master's OutstandingPrincipal/Maturity."""
    latest = {}  # account key -> (date, value)
    for r in trans_rows:
        key = str(r.get("LoanNo") or r.get("AdmissionNo") or "")
        if not key:
            continue
        val = r.get(field)
        if val in (None, ""):
            continue
        try:
            val = float(val)
        except (TypeError, ValueError):
            continue
        date = r.get("TransactionDate")
        prev = latest.get(key)
        if prev is None:
            latest[key] = (date, val)
        elif date and prev[0] and date >= prev[0]:
            latest[key] = (date, val)
        elif date and not prev[0]:
            latest[key] = (date, val)
    return round(sum(v for _, v in latest.values()), 2)


def _group_trans_rows_by_product(state: AppState):
    """Groups every output transaction row by its ProductDescription, regardless of which file it
    landed in -- a small helper shared by the summary and tally reports so both group rows identically."""
    grouped = {}
    for rows in state.trans_output.values():
        for row in rows:
            prod = row.get("ProductDescription") or "Unknown"
            grouped.setdefault(prod, []).append(row)
    return grouped


def build_transaction_product_summary(state: AppState):
    """Product-wise totals of every transaction amount field -- lets you sanity-check that transaction
    rows landed on the right product (a total that's wildly off for a product usually means transactions
    got matched to the wrong LoanNo/product during the LoanNo lookup). Flow fields (Disbursement,
    Collected*, Charges) are summed normally; Balance fields use latest-per-account (see above) and are
    labeled accordingly so the number can't be mistaken for a naive sum."""
    agg = {}
    for prod, rows in _group_trans_rows_by_product(state).items():
        a = {"TransactionCount": len(rows)}
        for f in TRANSACTION_SUMMARY_FIELDS:
            total = 0.0
            for row in rows:
                try:
                    total += float(row.get(f) or 0)
                except (TypeError, ValueError):
                    pass
            a[f] = round(total, 2)
        for f in TRANSACTION_BALANCE_FIELDS:
            a[f"{f} (latest per account, summed)"] = latest_balance_per_account(rows, f)
        agg[prod] = a
    out_rows = []
    for prod, vals in sorted(agg.items(), key=lambda kv: -kv[1]["TransactionCount"]):
        row = {"ProductDescription": prod}
        row.update({k: (round(v, 2) if isinstance(v, float) else v) for k, v in vals.items()})
        out_rows.append(row)
    return out_rows


def build_combined_product_purpose_mapping(state: AppState):
    """ONE sheet with both the detail (every raw ProductDescription/PurposeDescription row and what
    it mapped to) AND the rollup verification (when several raw combinations merge into the same final
    product, the merged total Accounts/Amount) -- previously these were two separate sheets
    ('Product-Purpose Mapping' detail-only, 'Mapping Summary by Product' rollup-only), which made it
    hard to verify a merge was correct without flipping between them. Rows are grouped by the mapped
    Product/Purpose so every raw row that rolls up into the same target sits together, with that
    group's merged totals repeated on each row for easy cross-checking."""
    groups = {}
    for c in state.combos.values():
        if not c.get("mappedProduct"):
            continue
        key = (c["category"], c["mappedProduct"], c["mappedSecond"])
        groups.setdefault(key, []).append(c)

    rows = []
    for (category, mapped_product, mapped_second), combos_in_group in sorted(
            groups.items(), key=lambda kv: -sum(c["amount"] for c in kv[1])):
        merged_accounts = sum(c["count"] for c in combos_in_group)
        merged_amount = round(sum(c["amount"] for c in combos_in_group), 2)
        merged_from_count = len(combos_in_group)
        for c in sorted(combos_in_group, key=lambda c: -c["amount"]):
            rows.append({
                "Category": CATEGORY_LABEL.get(category, category),
                "Source ProductDescription": c["rawProduct"],
                "Source PurposeDescription": c["rawSecond"] or "-",
                "-> Mapped ProductDescription": mapped_product,
                "-> Mapped PurposeDescription": mapped_second or "-",
                "Accounts (this source row)": c["count"],
                "Amount (this source row)": round(c["amount"], 2),
                "Confirmed": "Yes" if c.get("locked") else "No",
                "Confidence": f'{round((c.get("confidence") or 0) * 100)}%',
                "Merged From (N source rows)": merged_from_count,
                "Merged Total Accounts": merged_accounts,
                "Merged Total Amount": merged_amount,
                "Verify": ("OK -- single source, no merge" if merged_from_count == 1
                           else f"Merged {merged_from_count} source rows -> check total looks right"),
            })
    return rows




def build_ai_suggestion_backup(state: AppState, ctx):
    """Consolidated backup of every automated ('AI-suggested') correction made anywhere in the pipeline
    -- Original value vs what the system substituted, and why -- so a human can double-check or revert
    any single one of them. Covers: product/purpose fuzzy mapping, OperationTypeDesc/ChequeOption/
    IsOrganisation normalization, LedgerFolioNo cleanup, JointAdmissionNo cleanup, Member Number
    reassignment, and DOB defaulting."""
    rows = []
    for c in state.combos.values():
        if not c.get("mappedProduct"):
            continue
        confidence = c.get("confidence") or 0
        if confidence < 1.0 and not c.get("locked"):
            rows.append({"Area": "Product/Purpose Mapping", "Field": "Product/Purpose",
                         "OriginalValue": f'{c["rawProduct"]} / {c["rawSecond"] or "-"}',
                         "AISuggestedValue": f'{c["mappedProduct"]} / {c["mappedSecond"] or "-"}',
                         "Reason": f"Fuzzy match, {round(confidence*100)}% confidence -- accounts affected: {c['count']}"})
    for name, log_rows in (state.field_cleanup_log or {}).items():
        for r in log_rows:
            rows.append({"Area": name, "Field": r.get("Field", ""),
                         "OriginalValue": r.get("Before", r.get("Original", "")),
                         "AISuggestedValue": r.get("After", r.get("New", "")),
                         "Reason": r.get("Reason", "Automated field cleanup")})
    if ctx is not None:
        for r in (getattr(ctx, "ai_suggestion_backup", []) or []):
            rows.append(r)
        for r in (getattr(ctx, "dob_defaulted_rows", []) or []):
            rows.append({"Area": "DOB Defaulted", "Field": "DOB",
                         "OriginalValue": r.get("OriginalValue", ""), "AISuggestedValue": r.get("FilledDOB", ""),
                         "Reason": f"{r.get('Reason','')} -- AdmNo {r.get('AdmissionNo','')}"})
    return rows


def write_mapping_audit_report(state: AppState, path):
    """Product/Purpose mapping (detail + merged-total verification in one sheet), a product-wise
    Transaction summary, and a Transaction Tally Report checking both completeness (did every
    transaction row make it into the output) and amount tally (do Master and Transaction totals line
    up) per product -- this is the checkpoint report reviewed on the Mapping Audit tab before Masters
    are generated, and again after, to confirm Source and Transaction data are mapped correctly."""
    combined_map_rows = build_combined_product_purpose_mapping(state)
    trans_summary_rows = build_transaction_product_summary(state)
    tally_rows = build_tally_report(state) if (state.masters_output or state.trans_product_stats) else []
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        pd.DataFrame(combined_map_rows or [{"Info": "No mapping data"}]).to_excel(
            writer, sheet_name="Product-Purpose Mapping", index=False)
        pd.DataFrame(trans_summary_rows or [{"Info": "No transaction data"}]).to_excel(
            writer, sheet_name="Transaction Summary by Product", index=False)
        pd.DataFrame(tally_rows or [{"Info": "Generate Masters and process Transactions first"}]).to_excel(
            writer, sheet_name="Transaction Tally Report", index=False)


def build_all_issues_sheet(state: AppState, ctx):
    """Flattens every finding from every report -- membership validation, field cleanup, loan/deposit
    calculation issues, RD deep validation, data quality, unresolved OperationTypeDesc -- into one combined
    list. Deliberately placed as the LAST sheet in the Validation Report so it reads as a final summary
    after you've seen the detail sheets."""
    all_rows = []
    if ctx is not None:
        for r in (getattr(ctx, "issues", []) or []):
            all_rows.append({"Report": f"Membership: {r.get('sheet','')}", "Type": r.get("type", ""),
                              "Detail": r.get("detail", ""), "Row": r.get("row", "")})
    for name, rows in (state.validation_reports or {}).items():
        for r in rows:
            detail = "; ".join(f"{k}: {v}" for k, v in r.items() if v not in (None, ""))
            all_rows.append({"Report": name, "Type": r.get("Field") or r.get("Issue") or r.get("Check") or "",
                              "Detail": detail, "Row": ""})
    return all_rows


def write_validation_report(state: AppState, ctx, path):
    """One workbook: membership-side validation (from the DCT ConversionContext) + the Masters-side
    validation this engine now runs (date/amount arithmetic checks, RD deep validation, deposit data
    quality, field cleanup logs, unresolved OperationTypeDesc), with a combined 'All Issues' sheet LAST."""
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        if ctx is not None:
            pd.DataFrame(ctx.duplicate_member_rows or [{"Info": "No duplicate member numbers found"}]).to_excel(
                writer, sheet_name="Duplicate Member Report", index=False)
            pd.DataFrame(ctx.special_member_number_rows or [{"Info": "No invalid member numbers found"}]).to_excel(
                writer, sheet_name="Special Member Number Errors", index=False)
            pd.DataFrame(getattr(ctx, "member_number_reassignments", []) or [{"Info": "No reassignments needed"}]).to_excel(
                writer, sheet_name="Member Number Reassignments", index=False)
            pd.DataFrame(getattr(ctx, "dob_defaulted_rows", []) or [{"Info": "No DOB defaults needed"}]).to_excel(
                writer, sheet_name="DOB Defaulted", index=False)
            pd.DataFrame(getattr(ctx, "loan_incomplete_rows", []) or [{"Info": "No incomplete loan records found"}]).to_excel(
                writer, sheet_name="Incomplete Loan Records", index=False)
            pd.DataFrame(getattr(ctx, "deposit_incomplete_rows", []) or [{"Info": "No incomplete deposit records found"}]).to_excel(
                writer, sheet_name="Incomplete Deposit Records", index=False)
            pd.DataFrame(ctx.admission_date_adjustments or [{"Info": "No adjustments"}]).to_excel(
                writer, sheet_name="AdmissionDate Cap Adjustments", index=False)
            pd.DataFrame(ctx.admission_account_date_adjustments or [{"Info": "No adjustments"}]).to_excel(
                writer, sheet_name="AdmissionDate vs Account", index=False)
            pd.DataFrame(ctx.sb_pigmy_date_adjustments or [{"Info": "No adjustments"}]).to_excel(
                writer, sheet_name="SB-Pigmy Date Adjustments", index=False)
            pd.DataFrame(getattr(ctx, "missing_membership_rows", []) or [{"Info": "None found"}]).to_excel(
                writer, sheet_name="Missing Membership", index=False)
            pd.DataFrame(getattr(ctx, "village_mapping_results", []) or [{"Info": "No village reference file was provided, or every VillageDescription was already filled"}]).to_excel(
                writer, sheet_name="Village Mapping", index=False)
            pd.DataFrame(getattr(ctx, "balance_sheet_tally", []) or [{"Info": "No Balance Sheet file was provided"}]).to_excel(
                writer, sheet_name="Balance Sheet Tally", index=False)
            pd.DataFrame(ctx.deleted_aadhaar or [{"Info": "None found"}]).to_excel(
                writer, sheet_name="Duplicate Aadhaar Deleted", index=False)
            pd.DataFrame(ctx.deleted_pan or [{"Info": "None found"}]).to_excel(
                writer, sheet_name="Duplicate PAN Deleted", index=False)
        # Preferred sheet order for readability; anything not listed here still gets written afterward.
        preferred_order = ["Loan Calculation Issues", "Deposit Calculation Issues", "RD Deep Validation",
                            "Deposit Data Quality Issues", "Account Number Format Errors",
                            "OperationTypeDesc Unresolved",
                            "LedgerFolioNo Cleanup", "JointAdmissionNo Cleanup",
                            "ChequeOption-IsOrganisation Cleanup", "OperationTypeDesc Mapping",
                            "BranchId Defaulted to 101",
                            "LoanNo Special Character Cleanup", "AccountNo Special Character Cleanup",
                            "LoanNo Reassigned (collision avoided)", "AccountNo Reassigned (collision avoided)",
                            "Transaction AdmissionNo Corrected"]
        remaining = dict(state.validation_reports or {})
        for name in preferred_order:
            if name in remaining:
                rows = remaining.pop(name)
                safe_name = re.sub(r'[\[\]\:\*\?/\\]', '', name)[:31] or "Sheet"
                pd.DataFrame(rows or [{"Info": "None found"}]).to_excel(writer, sheet_name=safe_name, index=False)
        for name, rows in remaining.items():
            safe_name = re.sub(r'[\[\]\:\*\?/\\]', '', name)[:31] or "Sheet"
            pd.DataFrame(rows or [{"Info": "None found"}]).to_excel(writer, sheet_name=safe_name, index=False)
        # NOTE: "AI Suggestion Backup" is deliberately NOT written as a report sheet -- every
        # automated correction is still persisted to mapping_history.json (see
        # update_mapping_history()) so nothing is lost, it's just not cluttering this report.
        # "All Issues" -- combined view of everything above, written LAST as requested.
        all_rows = build_all_issues_sheet(state, ctx)
        pd.DataFrame(all_rows or [{"Info": "No issues found anywhere"}]).to_excel(
            writer, sheet_name="All Issues", index=False)


def build_clean_output(state: AppState, ctx, full_dfs, outdir):
    """Writes the single clean 4-folder output structure described above and returns a summary dict.
    No raw/source *_Raw.xlsx files are written anywhere in here -- those only ever exist in memory."""
    summary = {"member_files": 0, "product_files": 0, "transaction_files": 0}

    member_dir = os.path.join(outdir, "Split_By_Member")
    os.makedirs(member_dir, exist_ok=True)
    membership_df = (full_dfs or {}).get("MembershipTemplate.xlsx")
    if membership_df is not None and not membership_df.empty and "MemberTypeDescription" in membership_df.columns:
        for member_type, group in membership_df.groupby("MemberTypeDescription", dropna=False):
            mt = member_type if not is_blank(member_type) else "Unknown"
            safe_type = re.sub(r'[^a-zA-Z0-9_\- ]', '_', str(mt).strip())[:30]
            group_native = convert_membership_dates_to_native(group)
            out_path = os.path.join(member_dir, f"Membership_{safe_type}.xlsx")
            write_dataframe_xlsx(out_path, group_native.to_dict(orient="records"), list(group_native.columns))
            summary["member_files"] += 1

    product_dir = os.path.join(outdir, "Split_By_Products")
    os.makedirs(product_dir, exist_ok=True)
    for fname, mo in state.masters_output.items():
        write_dataframe_xlsx(os.path.join(product_dir, fname), mo["rows"], MASTER_TEMPLATES[mo["category"]])
        summary["product_files"] += 1

    trans_dir = os.path.join(outdir, "Split_By_Transactions")
    os.makedirs(trans_dir, exist_ok=True)
    for fname, rows in state.trans_output.items():
        write_dataframe_xlsx(os.path.join(trans_dir, fname), rows, TRANSACTION_TEMPLATE)
        summary["transaction_files"] += 1

    report_dir = os.path.join(outdir, "Reports")
    os.makedirs(report_dir, exist_ok=True)
    write_mapping_audit_report(state, os.path.join(report_dir, "Mapping_Audit_Report.xlsx"))
    write_validation_report(state, ctx, os.path.join(report_dir, "Validation_Report.xlsx"))

    return summary

# ==============================================================================
# UNIFIED GUI
# PACS DCT + Mapping Suite -- one app, one workflow:
#   Setup -> Source Files -> Convert & Validate -> Split (Member/Product) ->
#   Product Mapping -> Masters & Transactions -> Reports -> Config
# ==============================================================================

import os
import sys
import threading
import traceback
import datetime as _dtmod

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from tkinter.scrolledtext import ScrolledText

import pandas as pd

eng = sys.modules[__name__]   # engine functions/classes live in this same module, defined above


APP_TITLE = "PACS DCT + Mapping Suite"
APP_VERSION = "4.0"
APP_VERSION_DATE = "31/08/2026"


# ------------------------------------------------------------------------
# SmartCombo -- type-to-search entry with a floating filtered list.
# This replaces plain ttk.Combobox wherever a list is long (PACS picker,
# product/purpose pickers) so the user can type a few letters and jump
# straight to the match instead of scrolling.
# ------------------------------------------------------------------------
class SmartCombo:
    def __init__(self, parent, initial, options, width, on_change, placeholder=None, strict=False):
        self.options = options
        self.on_change = on_change
        # STRICT MODE: when True, only a value that exactly matches something already in self.options
        # can ever be committed -- typing text that doesn't match a real taxonomy entry is rejected
        # and the box snaps back to the last valid value. This is what Product Mapping rows use, per
        # explicit instruction: adding a genuinely NEW product/purpose must only ever happen through
        # the Config tab, never by typing directly into a mapping row. Confirmed as a real, concrete
        # problem on a real screenshot: a row where "test"/"test" had been typed in and gotten
        # "confirmed" -- exploratory or accidental typing could silently become a permanent, saved
        # mapping. The Config tab remains free-text (that's specifically what it's for).
        self.strict = strict
        self.var = tk.StringVar(value=initial)
        # Tracks what's actually been committed (as opposed to merely typed-but-not-finished), so
        # on_change only fires once per real change -- see the bug note on _on_key below.
        self._last_committed = initial
        self.entry = ttk.Entry(parent, textvariable=self.var, width=width)
        if placeholder and not initial:
            self._set_placeholder(placeholder)
        self.popup = None
        self.listbox = None
        self._hide_job = None
        self.entry.bind("<KeyRelease>", self._on_key)
        self.entry.bind("<FocusIn>", lambda e: self._show())
        self.entry.bind("<FocusOut>", self._on_focus_out)
        self.entry.bind("<Down>", lambda e: self._move(1))
        self.entry.bind("<Up>", lambda e: self._move(-1))
        self.entry.bind("<Return>", lambda e: self._commit_selected())
        self.entry.bind("<Escape>", lambda e: self._hide())

    def _set_placeholder(self, text):
        pass  # kept simple; entry starts blank, popup shows full list on focus

    def grid(self, **kw):
        self.entry.grid(**kw)

    def pack(self, **kw):
        self.entry.pack(**kw)

    def set_options(self, options):
        self.options = options

    def get(self):
        return self.var.get()

    def set(self, value):
        self.var.set(value)
        self._last_committed = value

    def _filtered(self):
        typed = self.var.get().strip().lower()
        if not typed:
            return self.options[:300]
        starts = [o for o in self.options if o.lower().startswith(typed)]
        contains = [o for o in self.options if typed in o.lower() and o not in starts]
        return (starts + contains)[:300]

    def _on_key(self, event):
        if event.keysym in ("Up", "Down", "Return", "Escape"):
            return
        self._show()
        # BUG FIX: this used to call self.on_change(self.var.get()) on every single keystroke. Combined
        # with the mapping row's "auto-save a genuinely new value to the taxonomy" logic living inside
        # on_change, that meant every partial, mid-typing fragment -- "L", "Lo", "Lon", "Long" while
        # someone was simply typing "Long Term Agri Loans" -- got permanently saved as its own
        # taxonomy entry. Confirmed on a real screenshot: a product dropdown full of single-letter and
        # fragment junk ("L", "LO", "LOn", "LOng", "Li", "Lin", "Ling"). on_change now only fires once
        # the user actually COMMITS a value -- pressing Enter, clicking a list item, or clicking/tabbing
        # away -- never on an in-progress keystroke. Only the live filter-dropdown redraws here.

    def _on_focus_out(self, event=None):
        self._schedule_hide()
        self._maybe_commit_typed_value()

    def _maybe_commit_typed_value(self):
        """Commits whatever the user actually finished typing, if it's a real change -- covers
        clicking/tabbing away after typing a new value without pressing Enter or clicking a list item,
        which previously left that typed value uncommitted (on_change never fired for it at all).

        In strict mode, only commits if the typed text exactly matches (case-insensitively) something
        already in self.options -- anything else is rejected and the box snaps back to the last
        committed value, since strict mode means new values may ONLY be added via the Config tab."""
        current = self.var.get().strip()
        if self.strict:
            match = next((o for o in self.options if o.lower() == current.lower()), None)
            if match is None:
                self.var.set(self._last_committed)  # reject -- snap back, don't touch on_change at all
                return
            current = match  # normalize to the taxonomy's exact stored casing/spelling
        if current and current != self._last_committed:
            self._last_committed = current
            self.on_change(current)

    def _show(self):
        items = self._filtered()
        if self.popup is None:
            self.popup = tk.Toplevel(self.entry)
            self.popup.wm_overrideredirect(True)
            self.popup.wm_attributes("-topmost", True)
            frame = ttk.Frame(self.popup)
            frame.pack(fill="both", expand=True)
            sb = ttk.Scrollbar(frame, orient="vertical")
            self.listbox = tk.Listbox(frame, height=10, yscrollcommand=sb.set, activestyle="none",
                                       exportselection=False, font=("Segoe UI", 9))
            sb.config(command=self.listbox.yview)
            self.listbox.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")
            self.listbox.bind("<Button-1>", self._on_click, add="+")
            self.listbox.bind("<ButtonRelease-1>", self._commit_from_click)
            self.popup.bind("<FocusOut>", lambda e: self._schedule_hide())
        self.listbox.delete(0, "end")
        for it in items:
            self.listbox.insert("end", it)
        if not items:
            self.listbox.insert("end", "(no match -- free text kept as typed)")
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        w = max(self.entry.winfo_width(), 260)
        self.popup.wm_geometry(f"{w}x200+{x}+{y}")
        self.popup.deiconify()

    def _on_click(self, event):
        if self._hide_job:
            self.entry.after_cancel(self._hide_job)
            self._hide_job = None

    def _commit_from_click(self, event):
        sel = self.listbox.curselection()
        if sel:
            val = self.listbox.get(sel[0])
            if not val.startswith("(no match"):
                self.var.set(val)
                self._last_committed = val
                self.on_change(val)
        self._hide()
        self.entry.focus_set()

    def _move(self, delta):
        if self.popup is None or not self.popup.winfo_ismapped():
            self._show()
            return
        cur = self.listbox.curselection()
        idx = (cur[0] + delta) if cur else 0
        idx = max(0, min(idx, self.listbox.size() - 1))
        self.listbox.selection_clear(0, "end")
        self.listbox.selection_set(idx)
        self.listbox.see(idx)

    def _commit_selected(self):
        if self.popup is not None and self.popup.winfo_ismapped():
            sel = self.listbox.curselection()
            if sel:
                val = self.listbox.get(sel[0])
                if not val.startswith("(no match"):
                    self.var.set(val)
                    self._last_committed = val
                    self.on_change(val)
                    self._hide()
                    return
        # BUG FIX: previously, if the user typed a genuinely new value and pressed Enter WITHOUT
        # navigating to/highlighting a dropdown item first (a very natural thing to do), nothing
        # happened at all -- on_change never fired, so that new value was never committed or saved.
        # Now falls through to committing whatever was actually typed.
        self._maybe_commit_typed_value()
        self._hide()

    def _schedule_hide(self):
        self._hide_job = self.entry.after(150, self._hide)

    def _hide(self):
        if self.popup is not None:
            self.popup.withdraw()


# ------------------------------------------------------------------------
# One row in the Product Mapping tab
# ------------------------------------------------------------------------
class MappingRow:
    def __init__(self, parent, key, combo, state, refresh_progress_cb, on_reclassify_cb):
        self.key = key
        self.combo = combo
        self.state = state
        self.refresh_progress_cb = refresh_progress_cb
        self.on_reclassify_cb = on_reclassify_cb
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="x", pady=1, padx=2)

        self.cat_var = tk.StringVar(value=combo["category"])
        cat_cb = ttk.Combobox(self.frame, textvariable=self.cat_var, values=list(eng.CATEGORY_LABEL.keys()),
                               state="readonly", width=8)
        cat_cb.grid(row=0, column=0, sticky="w")
        cat_cb.bind("<<ComboboxSelected>>", self._on_category_change)
        ttk.Label(self.frame, text=combo["rawProduct"], width=24).grid(row=0, column=1, sticky="w")
        ttk.Label(self.frame, text=combo["rawSecond"] or "\u2014", width=18).grid(row=0, column=2, sticky="w")
        ttk.Label(self.frame, text=str(combo["count"]), width=6, anchor="e").grid(row=0, column=3, sticky="e")
        ttk.Label(self.frame, text=f'{combo["amount"]:,.0f}', width=12, anchor="e").grid(row=0, column=4, sticky="e")

        tax = eng.CATEGORY_TAXKEY[combo["category"]]
        prod_options = state.tax_list(tax["products"])
        # strict=True: Product Mapping rows are selection-only. A new product/purpose may ONLY be
        # added via the Config tab -- never by typing directly into a mapping row. See SmartCombo's
        # strict-mode docstring for why.
        self.prod_combo = SmartCombo(self.frame, combo["mappedProduct"], prod_options, 26,
                                      self._on_change_product, strict=True)
        self.prod_combo.grid(row=0, column=5, sticky="w", padx=2)

        if tax["second"]:
            sec_options = eng.allowed_second_options(state, combo["category"], combo["mappedProduct"])
            self.sec_combo = SmartCombo(self.frame, combo["mappedSecond"], sec_options, 22,
                                         self._on_change_second, strict=True)
            self.sec_combo.grid(row=0, column=6, sticky="w", padx=2)
        else:
            self.sec_combo = None
            ttk.Label(self.frame, text="\u2014", width=22).grid(row=0, column=6, sticky="w")

        self.badge = tk.Button(self.frame, text=self._badge_text(), width=14, relief=tk.FLAT, bd=0,
                                cursor="hand2", command=self._toggle_confirm,
                                font=("Segoe UI", 9))
        self.badge.grid(row=0, column=7, sticky="w")
        self._style_badge()

    def _toggle_confirm(self):
        """Explicit confirm tick -- for when the auto-suggested mapping is already correct and just
        needs a human sign-off, without having to touch either dropdown to trigger the usual
        change-driven locked=True. Clicking again un-confirms it."""
        self.combo["locked"] = not self.combo.get("locked")
        if self.combo["locked"]:
            self.combo["confidence"] = 1.0
        self.badge.configure(text=self._badge_text())
        self._style_badge()
        self.refresh_progress_cb()

    def _style_badge(self):
        c = self.combo
        if c.get("locked"):
            self.badge.configure(bg="#e1f7ea", fg="#0b9f6e", activebackground="#c8f0d8")
        else:
            pct = round((c.get("confidence") or 0) * 100)
            if pct >= 75:
                self.badge.configure(bg="#fff1d6", fg="#b35900", activebackground="#ffe4b3")
            else:
                self.badge.configure(bg="#fef2f2", fg="#c62828", activebackground="#fcd8d8")

    def _on_category_change(self, event=None):
        new_cat = self.cat_var.get()
        combo = self.combo
        old_cat = combo["category"]
        if new_cat == old_cat:
            return
        combo["category"] = new_cat
        new_tax = eng.CATEGORY_TAXKEY[new_cat]
        new_prod_list = self.state.tax_list(new_tax["products"])
        pm, pscore = eng.best_match(combo["rawProduct"], new_prod_list)
        combo["mappedProduct"] = pm or combo["rawProduct"]
        confidence = pscore
        if new_tax["second"] and combo["rawSecond"]:
            sec_list_new = eng.allowed_second_options(self.state, new_cat, combo["mappedProduct"])
            sm, sscore = eng.best_match(combo["rawSecond"], sec_list_new)
            combo["mappedSecond"] = sm or combo["rawSecond"]
            confidence = min(confidence, sscore)
        else:
            combo["mappedSecond"] = combo["rawSecond"] if new_tax["second"] else ""
        combo["confidence"] = confidence
        combo["locked"] = False
        self.on_reclassify_cb()

    def _badge_text(self):
        c = self.combo
        if c.get("locked"):
            return "\u2713 confirmed"
        pct = round((c.get("confidence") or 0) * 100)
        if pct >= 75:
            return f"match {pct}%"
        if pct >= 40:
            return f"review {pct}%"
        return f"new/weak {pct}%"

    def _on_change_product(self, value):
        # NOTE: this only ever receives a value that's already in the taxonomy -- the SmartCombo
        # instances for Product Mapping rows are created with strict=True, so anything typed that
        # doesn't exactly match an existing option is rejected before it ever reaches here. New
        # products/purposes may only be added via the Config tab, per explicit instruction: an earlier
        # version of this method auto-saved whatever was typed directly into a mapping row, which was
        # confirmed as a real problem on a real screenshot -- a row where someone had typed
        # "test"/"test" while trying things out had gotten permanently saved as a "confirmed" mapping.
        value = value.strip()
        self.combo["mappedProduct"] = value
        self.combo["locked"] = True
        self.combo["confidence"] = 1.0
        self.badge.config(text=self._badge_text())
        # Product changed -> narrow the purpose/crop list per PRODUCT_PURPOSE_REQUIREMENTS
        if self.sec_combo is not None:
            new_opts = eng.allowed_second_options(self.state, self.combo["category"], self.combo["mappedProduct"])
            self.sec_combo.set_options(new_opts)
            cur = self.sec_combo.get()
            if cur and cur not in new_opts:
                # current value no longer valid for this product -- best-guess within new list
                sm, sscore = eng.best_match(cur, new_opts) if new_opts else (cur, 0.0)
                if sm:
                    self.sec_combo.set(sm)
                    self.combo["mappedSecond"] = sm
        self.refresh_progress_cb()

    def _on_change_second(self, value):
        # Same note as _on_change_product() above -- strict=True guarantees this is always an
        # existing taxonomy value already, never free-typed text.
        value = value.strip()
        self.combo["mappedSecond"] = value
        self.combo["locked"] = True
        self.combo["confidence"] = 1.0
        self.badge.config(text=self._badge_text())
        self.refresh_progress_cb()

    def matches_filter(self, cat_filter, search):
        return MappingRow.static_matches_filter(self.combo, cat_filter, search)

    @staticmethod
    def static_matches_filter(combo, cat_filter, search):
        if cat_filter and combo["category"] != cat_filter:
            return False
        if search:
            s = search.lower()
            # BUG FIX: this only searched the RAW product/purpose text -- but a person reviewing their
            # mapping naturally wants to search by the MAPPED (target) name too, e.g. typing "Staff
            # Loans" to find every row currently mapped to that product, regardless of what the raw
            # source text happened to say. Searching only the raw side made that kind of lookup return
            # nothing even when matching rows clearly existed, which is exactly what "search isn't
            # working" looks like from the outside.
            haystack = " ".join([
                combo.get("rawProduct") or "", combo.get("rawSecond") or "",
                combo.get("mappedProduct") or "", combo.get("mappedSecond") or "",
            ]).lower()
            if s not in haystack:
                return False
        return True


# ------------------------------------------------------------------------
# _ViewRouter -- a stacked-frame page switcher driven by an icon-only sidebar,
# matching theem10.html's .sidebar-nav. Exposes the same .select()/.tab()/.bind()
# surface a ttk.Notebook would, so the rest of the app (built against a Notebook
# originally) didn't need to change -- only how pages are created and switched.
# ------------------------------------------------------------------------
class _ViewRouter:
    def __init__(self, app, sidebar_parent, nav_specs, on_change=None):
        self.app = app
        self.on_change = on_change
        self.buttons = {}     # widget -> tk.Button
        self.states = {}      # widget -> "normal"/"disabled"
        self.current = None
        P = app.PALETTE
        for widget, icon, tooltip in nav_specs:
            btn = tk.Button(sidebar_parent, text=icon, font=("Segoe UI", 15), width=3, height=1,
                             bg=P["surface"], fg=P["text_sub"], activebackground=P["primary_light"],
                             activeforeground=P["primary"], relief=tk.FLAT, bd=0, cursor="hand2",
                             command=lambda w=widget: self.select(w))
            btn.pack(pady=3, padx=18)
            _ToolTip(btn, tooltip)
            self.buttons[widget] = btn
            self.states[widget] = "normal"

    def select(self, widget):
        if self.states.get(widget) == "disabled":
            return
        for w, btn in self.buttons.items():
            P = self.app.PALETTE
            active = (w is widget)
            btn.configure(bg=P["primary"] if active else P["surface"],
                          fg="white" if active else P["text_sub"])
        widget.tkraise()
        self.current = widget
        if self.on_change:
            self.on_change(widget)

    def tab(self, widget, state=None):
        if state is not None:
            self.states[widget] = state
            btn = self.buttons.get(widget)
            if btn is not None:
                btn.configure(state=("disabled" if state == "disabled" else "normal"))


class _ToolTip:
    """Small hover tooltip for the icon-only sidebar buttons (icons alone aren't
    self-explanatory), matching theem10.html's data-tooltip attribute behaviour."""
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)

    def _show(self, event=None):
        if self.tip or not self.text:
            return
        x = self.widget.winfo_rootx() + self.widget.winfo_width() + 6
        y = self.widget.winfo_rooty() + self.widget.winfo_height() // 2 - 10
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry(f"+{x}+{y}")
        tk.Label(self.tip, text=self.text, bg="#1e2233", fg="white", font=("Segoe UI", 9),
                 padx=8, pady=3).pack()

    def _hide(self, event=None):
        if self.tip:
            self.tip.destroy()
            self.tip = None


# ==============================================================================
# MAIN APPLICATION
# ==============================================================================
class SuiteApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_TITLE} v{APP_VERSION}")
        self._size_window_for_screen()

        self.base_dir = self._determine_base_dir()
        self.cfg = eng.load_config(self.base_dir)
        eng.set_admission_date_cap(
            eng.parse_date_from_string(self.cfg["settings"].get("admission_date_cap", "")) or eng.MAX_ADMISSION_DATE
        )

        # DCT-side state
        self.pacs_df = None
        self.pacs_info = {}
        self.source_files = []
        self.last_output_dir = self.cfg["settings"].get("last_output_dir", "")
        self.last_issues = []
        self.last_ctx = None
        self.full_dfs = {}
        self.village_data = {}
        self.balance_sheet_path = None
        self.balance_sheet_tally = []

        # Mapping-side state
        self.map_state = eng.AppState()
        self.map_state.load_custom_tax()
        self.mapping_rows = []
        self.split_mode = tk.StringVar(value="product")  # "member" or "product"
        self.var_audit_reviewed = tk.BooleanVar(value=False)

        self.status_var = tk.StringVar(value="Ready")

        self._build_style()
        self._build_header()
        self._build_menu()

        # ---- Icon sidebar + stacked-page router (replaces the old ttk.Notebook tab strip,
        # matching theem10.html's 76px icon-only sidebar). _ViewRouter below provides the same
        # .select()/.tab()/.bind() surface the rest of this class already calls, so none of the
        # ~30 _build_xxx_tab() methods needed to change -- only how pages are created/switched.
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        sidebar = tk.Frame(body, bg=self.PALETTE["surface"], width=84)
        sidebar.grid(row=0, column=0, sticky="ns")
        sidebar.grid_propagate(False)
        tk.Label(sidebar, text="\U0001F3DB\uFE0F", font=("Segoe UI", 20), bg=self.PALETTE["primary_light"],
                 fg=self.PALETTE["primary"], width=2, height=1).pack(pady=(18, 16))

        content = ttk.Frame(body)
        content.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        content.columnconfigure(0, weight=1)
        content.rowconfigure(0, weight=1)

        self.tab_dashboard = ttk.Frame(content)
        self.tab_setup = ttk.Frame(content)
        self.tab_files = ttk.Frame(content)
        self.tab_run = ttk.Frame(content)
        self.tab_split = ttk.Frame(content)
        self.tab_map = ttk.Frame(content)
        self.tab_audit = ttk.Frame(content)
        self.tab_masters = ttk.Frame(content)
        self.tab_reports = ttk.Frame(content)
        self.tab_config = ttk.Frame(content)

        nav_specs = [
            (self.tab_dashboard, "\U0001F3E0", "Dashboard"),
            (self.tab_setup, "\u2699", "Setup"),
            (self.tab_files, "\U0001F4C1", "Source Files"),
            (self.tab_run, "\U0001F527", "Convert && Validate"),
            (self.tab_split, "\U0001F500", "Split"),
            (self.tab_map, "\U0001F5FA", "Product Mapping"),
            (self.tab_audit, "\U0001F4CB", "Mapping Audit"),
            (self.tab_masters, "\U0001F5C4", "Masters && Transactions"),
            (self.tab_reports, "\U0001F4CA", "Reports"),
            (self.tab_config, "\U0001F39B", "Config"),
        ]
        self.nb = _ViewRouter(self, sidebar, nav_specs, self._on_tab_changed)

        for w in (self.tab_dashboard, self.tab_setup, self.tab_files, self.tab_run, self.tab_split,
                  self.tab_map, self.tab_audit, self.tab_masters, self.tab_reports, self.tab_config):
            w.grid(row=0, column=0, sticky="nsew", in_=content)

        self._build_dashboard_tab()
        self._build_setup_tab()
        self._build_files_tab()
        self._build_run_tab()
        self._build_split_tab()
        self._build_map_tab()
        self._build_audit_tab()
        self._build_masters_tab()
        self._build_reports_tab()
        self._build_config_tab()

        for t in (self.tab_split, self.tab_map, self.tab_audit, self.tab_masters, self.tab_reports):
            self.nb.tab(t, state="disabled")
        self.nb.select(self.tab_dashboard)

        status_bar = tk.Label(self, textvariable=self.status_var, anchor=tk.W, font=("Segoe UI", 9),
                               bg=self.PALETTE["primary_dark"], fg="white", padx=12, pady=4)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        footer = tk.Label(self, text=f"{APP_TITLE}  \u2022  v{APP_VERSION}  \u2022  {APP_VERSION_DATE}",
                           anchor=tk.E, font=("Segoe UI", 8), bg=self.PALETTE["bg"], fg=self.PALETTE["text_sub"],
                           padx=12, pady=2)
        footer.pack(side=tk.BOTTOM, fill=tk.X)

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(100, self._auto_load_pacs_file)

    def _on_tab_changed(self, current_widget):
        try:
            if current_widget is self.tab_audit:
                self._refresh_audit_table()
            elif current_widget is self.tab_dashboard:
                self._refresh_dashboard()
        except Exception:
            pass

    # ---- shell / chrome -------------------------------------------------

    def _size_window_for_screen(self):
        """Sizes the window as a comfortable fraction of whatever screen it's actually running on,
        instead of one fixed guess -- a 14" laptop at 1366x768 and one at 1920x1080 both get a window
        that fits with room to spare (for the taskbar, etc.), rather than either being too cramped or
        spilling off a smaller display. Capped on both ends so it's neither tiny nor absurdly large on
        a big external monitor."""
        try:
            screen_w = self.winfo_screenwidth()
            screen_h = self.winfo_screenheight()
        except Exception:
            screen_w, screen_h = 1366, 768
        win_w = max(880, min(1200, int(screen_w * 0.85)))
        win_h = max(600, min(760, int(screen_h * 0.82)))
        x = max(0, (screen_w - win_w) // 2)
        y = max(0, (screen_h - win_h) // 2 - 15)
        self.geometry(f"{win_w}x{win_h}+{x}+{y}")
        self.minsize(880, 600)

    def _determine_base_dir(self):
        if getattr(sys, "frozen", False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))

    # ---- design system -------------------------------------------------
    PALETTE = {
        "primary": "#4F46E5",         # indigo accent, matches theem10.html --accent exactly
        "primary_dark": "#3f37c9",    # matches theem10.html --accent-hover
        "primary_light": "#f0f4fe",   # matches theem10.html --accent-light
        "accent": "#06B6D4",          # matches theem10.html --cyan
        "accent_dark": "#0891b2",     # matches theem10.html --cyan-hover
        "blue": "#2563EB",
        "bg": "#f4f6fb",              # matches theem10.html --bg-primary
        "surface": "#ffffff",         # matches theem10.html --bg-surface
        "border": "#eef2f6",          # matches theem10.html --border-color
        "text": "#1e2233",            # matches theem10.html --text-primary
        "text_sub": "#5b677b",        # matches theem10.html --text-secondary
        "good": "#0b9f6e",            # matches theem10.html --green
        "good_bg": "#e1f7ea",         # matches theem10.html --green-bg
        "warn": "#d97706",            # matches theem10.html --orange
        "warn_bg": "#fff1d6",         # matches theem10.html --orange-bg
        "bad": "#dc2626",             # matches theem10.html --red
        "bad_bg": "#FEF2F2",
    }

    def _build_style(self):
        style = ttk.Style(self)
        for theme in ("vista", "clam"):
            try:
                style.theme_use(theme)
                break
            except tk.TclError:
                continue
        P = self.PALETTE
        self.configure(bg=P["bg"])

        style.configure(".", background=P["bg"], foreground=P["text"], font=("Segoe UI", 10))
        style.configure("TFrame", background=P["bg"])
        style.configure("TLabel", background=P["bg"], foreground=P["text"])
        style.configure("TCheckbutton", background=P["bg"])
        style.configure("TRadiobutton", background=P["bg"])

        style.configure("Header.TLabel", font=("Segoe UI", 15, "bold"), foreground=P["text"])
        style.configure("Sub.TLabel", font=("Segoe UI", 9), foreground=P["text_sub"])
        style.configure("Good.TLabel", foreground=P["good"], font=("Segoe UI", 9, "bold"))
        style.configure("Warn.TLabel", foreground=P["warn"], font=("Segoe UI", 9, "bold"))
        style.configure("Bad.TLabel", foreground=P["bad"], font=("Segoe UI", 9, "bold"))

        style.configure("Card.TFrame", background=P["surface"], relief="flat", borderwidth=1)
        style.configure("Card.TLabelframe", background=P["surface"], borderwidth=1, relief="solid")
        style.configure("Card.TLabelframe.Label", background=P["surface"], foreground=P["primary"],
                         font=("Segoe UI", 10, "bold"))
        style.configure("TLabelframe", background=P["bg"], borderwidth=1)
        style.configure("TLabelframe.Label", background=P["bg"], foreground=P["primary_dark"],
                         font=("Segoe UI", 10, "bold"))

        # Notebook (tab strip)
        style.configure("TNotebook", background=P["bg"], borderwidth=0, tabmargins=(4, 6, 4, 0))
        style.configure("TNotebook.Tab", background=P["surface"], foreground=P["text_sub"],
                         padding=(14, 8), font=("Segoe UI", 9, "bold"), borderwidth=0)
        style.map("TNotebook.Tab",
                  background=[("selected", P["primary"]), ("active", P["primary_light"])],
                  foreground=[("selected", "#FFFFFF"), ("active", P["primary_dark"])])

        # Treeview (tables)
        style.configure("Treeview", background=P["surface"], fieldbackground=P["surface"],
                         foreground=P["text"], rowheight=26, borderwidth=0, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", background=P["primary_light"], foreground=P["primary_dark"],
                         font=("Segoe UI", 9, "bold"), relief="flat", padding=6)
        style.map("Treeview", background=[("selected", P["primary"])], foreground=[("selected", "#FFFFFF")])
        style.map("Treeview.Heading", background=[("active", P["primary_light"])])

        # Progressbar
        style.configure("TProgressbar", troughcolor=P["border"], background=P["accent"],
                         bordercolor=P["bg"], lightcolor=P["accent"], darkcolor=P["accent"])

        # Entry / Combobox
        style.configure("TEntry", fieldbackground=P["surface"], bordercolor=P["border"])
        style.configure("TCombobox", fieldbackground=P["surface"])

    def _create_button(self, parent, text, command, width=None, kind="primary"):
        P = self.PALETTE
        colors = {
            "primary": (P["primary"], P["primary_dark"]),
            "accent": (P["accent"], P["accent_dark"]),
            "ghost": (P["surface"], P["primary_light"]),
        }
        bg, active_bg = colors.get(kind, colors["primary"])
        fg = P["text"] if kind == "ghost" else "#FFFFFF"
        btn = tk.Button(parent, text=text, command=command,
                         bg=bg, fg=fg, activebackground=active_bg, activeforeground=fg,
                         font=("Segoe UI", 10, "bold"), relief=tk.FLAT, bd=0,
                         padx=14, pady=7, cursor="hand2",
                         highlightthickness=1, highlightbackground=P["border"])
        if width:
            btn.config(width=width)
        btn.bind("<Enter>", lambda e: btn.config(bg=active_bg))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        return btn

    def _build_header(self):
        P = self.PALETTE
        height = 72
        canvas = tk.Canvas(self, height=height, highlightthickness=0, bd=0)
        canvas.pack(fill=tk.X, side=tk.TOP)

        def draw_gradient(event=None):
            canvas.delete("grad")
            w = canvas.winfo_width() or self.winfo_width() or 1250
            steps = 60
            c1 = (79, 70, 229)     # indigo (matches PALETTE["primary"] / theem10.html --accent)
            c2 = (6, 182, 212)     # cyan (matches PALETTE["accent"] / theem10.html --cyan)
            for i in range(steps):
                t = i / steps
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                color = f"#{r:02x}{g:02x}{b:02x}"
                x0 = int(w * i / steps)
                x1 = int(w * (i + 1) / steps)
                canvas.create_rectangle(x0, 0, x1, height, fill=color, outline=color, tags="grad")
            canvas.create_text(24, height * 0.36, anchor="w", text=f"\U0001F3E6  {APP_TITLE}",
                                fill="white", font=("Segoe UI", 17, "bold"), tags="grad")
            canvas.create_text(24, height * 0.72, anchor="w",
                                text=f"v{APP_VERSION}  \u00b7  DCT Conversion + Product/Purpose Mapping -- one workflow",
                                fill="#E0E7FF", font=("Segoe UI", 10), tags="grad")
            canvas.tag_lower("grad")

        canvas.bind("<Configure>", draw_gradient)
        self._header_canvas = canvas

    def _build_menu(self):
        menubar = tk.Menu(self)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Save settings", command=self._save_settings)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=filemenu)
        self.config(menu=menubar)

    def _on_close(self):
        self._save_settings(silent=True)
        self.map_state.save_custom_tax()
        self.destroy()

    def log(self, msg):
        # Marshaled onto the main thread via self.after() -- this is called from a background thread
        # during conversion (threading.Thread(target=self._run_conversion)), and Tkinter's underlying
        # Tcl interpreter is not thread-safe. Touching a widget directly from a background thread (as
        # this used to do, plus calling update_idletasks() from that thread too) is a classic Tkinter
        # deadlock: confirmed by reproducing a real, indefinite hang during conversion with real data,
        # using the exact threading pattern the app itself uses -- not a testing artifact.
        text = str(msg) + "\n"
        def _do():
            self.txt_log.configure(state="normal")
            self.txt_log.insert("end", text)
            self.txt_log.see("end")
            self.txt_log.configure(state="disabled")
        self.after(0, _do)

    # ================================================================
    # TAB 0: DASHBOARD
    # New workflow-at-a-glance home view -- stat cards, a workflow progress panel,
    # a mapping-audit preview, and quick-jump actions, all wired to real session
    # data (not mock numbers), matching theem10.html's Dashboard view.
    # ================================================================
    def _build_dashboard_tab(self):
        f = self.tab_dashboard
        P = self.PALETTE
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Dashboard", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)

        stats_row = ttk.Frame(f)
        stats_row.grid(row=1, column=0, sticky="we", padx=10, pady=(4, 10))
        for i in range(4):
            stats_row.columnconfigure(i, weight=1)
        self._dash_stat_cards = []
        for i, (icon, label) in enumerate([("\U0001F465", "Members"), ("\U0001F4C4", "Loan Accounts"),
                                            ("\U0001F437", "Deposits"), ("\U0001F6A9", "Pending Attention")]):
            card = tk.Frame(stats_row, bg=P["surface"], highlightbackground=P["border"], highlightthickness=1)
            card.grid(row=0, column=i, sticky="we", padx=4)
            tk.Label(card, text=f"{icon} {label}", bg=P["surface"], fg=P["text_sub"],
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=14, pady=(10, 0))
            val_lbl = tk.Label(card, text="0", bg=P["surface"], fg=P["text"], font=("Segoe UI", 18, "bold"))
            val_lbl.pack(anchor="w", padx=14, pady=(0, 10))
            self._dash_stat_cards.append(val_lbl)

        middle = ttk.Frame(f)
        middle.grid(row=2, column=0, sticky="nsew", padx=10, pady=4)
        middle.columnconfigure(1, weight=1)
        middle.rowconfigure(0, weight=1)
        f.rowconfigure(2, weight=1)
        f.columnconfigure(0, weight=1)

        wf_panel = tk.Frame(middle, bg=P["surface"], highlightbackground=P["border"], highlightthickness=1)
        wf_panel.grid(row=0, column=0, sticky="ns", padx=(0, 8))
        tk.Label(wf_panel, text="\u27A1 Workflow", bg=P["surface"], fg=P["text_sub"],
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=14, pady=(12, 8))
        self._dash_wf_progress = ttk.Progressbar(wf_panel, orient="horizontal", length=210, mode="determinate")
        self._dash_wf_progress.pack(padx=14, pady=(0, 8))
        self._dash_wf_steps_frame = tk.Frame(wf_panel, bg=P["surface"])
        self._dash_wf_steps_frame.pack(fill="both", expand=True, padx=10, pady=(0, 12))

        table_panel = ttk.Frame(middle)
        table_panel.grid(row=0, column=1, sticky="nsew")
        table_panel.columnconfigure(0, weight=1)
        table_panel.rowconfigure(1, weight=1)
        self._dash_audit_title = ttk.Label(table_panel, text="\U0001F4CB Mapping Audit", style="Sub.TLabel",
                                            font=("Segoe UI", 10, "bold"))
        self._dash_audit_title.grid(row=0, column=0, sticky="w", pady=(0, 6))
        cols = ("category", "raw", "mapped", "accounts", "amount", "status")
        self.tree_dashboard = ttk.Treeview(table_panel, columns=cols, show="headings", height=10)
        headers = {"category": "Category", "raw": "Raw Product", "mapped": "-> Mapped",
                   "accounts": "Accounts", "amount": "Amount", "status": "Status"}
        for c in cols:
            self.tree_dashboard.heading(c, text=headers[c])
            self.tree_dashboard.column(c, width=110, anchor="e" if c in ("accounts", "amount") else "w")
        self.tree_dashboard.grid(row=1, column=0, sticky="nsew")

        action_bar = ttk.Frame(f)
        action_bar.grid(row=3, column=0, sticky="we", padx=10, pady=8)
        self._create_button(action_bar, "\U0001F501 Re-run guess", self._fill_best_guess, kind="ghost").pack(side="left", padx=3)
        self._create_button(action_bar, "\U0001F5FA Go to Mapping",
                             lambda: self.nb.select(self.tab_map), kind="ghost").pack(side="left", padx=3)
        self._create_button(action_bar, "\u2699 Generate Masters",
                             lambda: self.nb.select(self.tab_masters), kind="accent").pack(side="left", padx=3)
        self._create_button(action_bar, "\U0001F4E4 Clean Output",
                             lambda: self.nb.select(self.tab_masters)).pack(side="left", padx=3)

        self._dash_status_label = tk.Label(f, text="", bg=P["bg"], fg=P["text_sub"], font=("Segoe UI", 9),
                                            anchor="w")
        self._dash_status_label.grid(row=4, column=0, sticky="we", padx=10, pady=(4, 8))

    def _refresh_dashboard(self):
        membership_df = (self.full_dfs or {}).get("MembershipTemplate.xlsx")
        n_members = len(membership_df) if membership_df is not None else 0
        state = self.map_state
        loan_accounts = sum(c["count"] for c in state.combos.values() if c["category"] in eng.LOAN_CATEGORIES)
        deposit_amount = sum(c["amount"] for c in state.combos.values() if c["category"] in ("FD", "RD", "SB", "PIGMY"))
        unresolved_optype = len([u for u in eng.scan_operation_type_values(state)
                                 if u["RawValue"] not in state.operation_type_overrides]) if state.combos else 0
        special_members = len(getattr(self.last_ctx, "special_member_number_rows", [])) if self.last_ctx else 0
        pending = unresolved_optype + special_members

        vals = [f"{n_members:,}", f"{loan_accounts:,}", f"\u20B9{deposit_amount:,.0f}", f"{pending:,}"]
        for lbl, v in zip(self._dash_stat_cards, vals):
            lbl.configure(text=v)

        steps = [
            ("Setup", bool(self.pacs_info), "done" if self.pacs_info else "not started"),
            ("Source Files", bool(self.source_files), f"{len(self.source_files)} files" if self.source_files else "none yet"),
            ("Convert", bool(self.last_ctx), f"{len(self.last_issues)} issues" if self.last_ctx else "not run"),
            ("Load Mapping", bool(state.combos), "done" if state.combos else "pending"),
        ]
        confirmed = sum(1 for c in state.combos.values() if c.get("locked") or (c.get("confidence") or 0) >= 0.75)
        mapping_status = "not started"
        if state.combos:
            mapping_status = "done" if confirmed == len(state.combos) else f"{confirmed}/{len(state.combos)} combos"
        steps.append(("Product Mapping", bool(state.combos) and confirmed == len(state.combos), mapping_status))
        steps.append(("Audit && Masters", bool(state.masters_output),
                      "done" if state.masters_output else "pending"))
        done_count = sum(1 for _, d, _ in steps if d)
        self._dash_wf_progress["maximum"] = len(steps)
        self._dash_wf_progress["value"] = done_count

        for w in self._dash_wf_steps_frame.winfo_children():
            w.destroy()
        P = self.PALETTE
        for label, done, status in steps:
            row = tk.Frame(self._dash_wf_steps_frame, bg=(P["good_bg"] if done else P["surface"]))
            row.pack(fill="x", pady=1)
            icon = "\u2705" if done else "\u23F3"
            tk.Label(row, text=f"{icon} {label}", bg=row["bg"], fg=P["text"], font=("Segoe UI", 9),
                     anchor="w").pack(side="left", padx=6, pady=3)
            tk.Label(row, text=status, bg=row["bg"], fg=P["text_sub"], font=("Segoe UI", 8),
                     anchor="e").pack(side="right", padx=6)

        self.tree_dashboard.delete(*self.tree_dashboard.get_children())
        for c in sorted(state.combos.values(), key=lambda c: -c["amount"])[:12]:
            status = "Confirmed" if c.get("locked") else ("Review" if (c.get("confidence") or 0) < 0.75 else "Pending")
            self.tree_dashboard.insert("", "end", values=(
                eng.CATEGORY_LABEL.get(c["category"], c["category"]), c["rawProduct"], c["mappedProduct"],
                c["count"], f'{c["amount"]:,.0f}', status))
        total_amt = sum(c["amount"] for c in state.combos.values())
        self._dash_audit_title.configure(
            text=f"\U0001F4CB Mapping Audit  \u2022  {len(state.combos)} combos \u00b7 \u20B9{total_amt:,.0f}")

        n_rows = sum(len(df) for df in self.full_dfs.values()) if self.full_dfs else 0
        self._dash_status_label.configure(
            text=f"\U0001F7E2 All systems online   |   \U0001F5C3 {len(self.source_files)} files \u00b7 {n_rows} rows   |   "
                 f"\U0001F6A9 {unresolved_optype} unresolved OpType   \u26A0 {special_members} special member numbers"
                 f"   |   \U0001F512 local only")

    # ================================================================
    # TAB 1: SETUP
    # ================================================================
    def _build_setup_tab(self):
        f = self.tab_setup
        pad = {"padx": 10, "pady": 6}

        canvas = tk.Canvas(f)
        scrollbar = ttk.Scrollbar(f, orient="vertical", command=canvas.yview)
        scrollable = ttk.Frame(canvas)
        scrollable.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        f = scrollable

        ttk.Label(f, text="Setup", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Everything below runs only on this computer. Nothing is uploaded anywhere.",
                  style="Sub.TLabel").grid(row=1, column=0, columnspan=4, sticky="w", padx=10)

        # --- PACS identity, with keyboard-searchable picker ---
        box = ttk.LabelFrame(f, text="PACS Identity (from your 'PACS ID details.xlsx')", style="Card.TFrame")
        box.grid(row=2, column=0, columnspan=4, sticky="we", padx=10, pady=10)
        box.columnconfigure(1, weight=1)

        ttk.Label(box, text="PACS ID details file:").grid(row=0, column=0, sticky="w", **pad)
        self.var_pacs_file = tk.StringVar(value=self.cfg["settings"].get("pacs_id_details_path", ""))
        ttk.Entry(box, textvariable=self.var_pacs_file).grid(row=0, column=1, sticky="we", **pad)
        ttk.Button(box, text="Browse...", command=self._browse_pacs_file).grid(row=0, column=2, **pad)
        ttk.Button(box, text="Reload", command=lambda: self._load_pacs_file(self.var_pacs_file.get())).grid(row=0, column=3, padx=4)

        ttk.Label(box, text="Select your PACS (type to search):").grid(row=1, column=0, sticky="w", **pad)
        self.combo_pacs = SmartCombo(box, "", [], 40, self._on_pacs_typed)
        self.combo_pacs.grid(row=1, column=1, sticky="we", **pad)
        ttk.Label(box, text="\u2328 Start typing the PACS name -- matching results appear below the box; "
                             "click one or press Enter.", style="Sub.TLabel").grid(
            row=2, column=0, columnspan=3, sticky="w", padx=10)

        ttk.Label(box, text="Login / bulk-upload user:").grid(row=3, column=0, sticky="w", **pad)
        self.var_user_row = tk.StringVar()
        self.combo_user_row = ttk.Combobox(box, textvariable=self.var_user_row, state="readonly", width=50)
        self.combo_user_row.grid(row=3, column=1, sticky="we", **pad)
        self.combo_user_row.bind("<<ComboboxSelected>>", self._on_user_row_selected)

        self.lbl_pacs_details = ttk.Label(box, text="PacsIDPKey: -    DCCBBrName: -    bulkuploaduserid: -",
                                           style="Sub.TLabel")
        self.lbl_pacs_details.grid(row=4, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 8))

        # --- Branch + output folder ---
        box2 = ttk.LabelFrame(f, text="Branch & Output", style="Card.TFrame")
        box2.grid(row=3, column=0, columnspan=4, sticky="we", padx=10, pady=10)
        box2.columnconfigure(1, weight=1)

        ttk.Label(box2, text="Branch for this upload batch:").grid(row=0, column=0, sticky="w", **pad)
        self.var_branch = tk.StringVar()
        ttk.Entry(box2, textvariable=self.var_branch, width=20).grid(row=0, column=1, sticky="w", **pad)
        ttk.Label(box2, text="(leave blank to keep whatever BranchId is already in the source file)",
                  style="Sub.TLabel").grid(row=0, column=2, sticky="w", padx=10)

        ttk.Label(box2, text="Output folder:").grid(row=1, column=0, sticky="w", **pad)
        self.var_outdir = tk.StringVar(value=self.last_output_dir)
        ttk.Entry(box2, textvariable=self.var_outdir).grid(row=1, column=1, sticky="we", **pad)
        ttk.Button(box2, text="Browse...", command=self._browse_outdir).grid(row=1, column=2, **pad)

        # --- DOB / Age rules ---
        box3 = ttk.LabelFrame(f, text="Missing Date of Birth / Age rule", style="Card.TFrame")
        box3.grid(row=4, column=0, columnspan=4, sticky="we", padx=10, pady=10)

        s = self.cfg["settings"]
        self.var_dob_strategy = tk.StringVar(value=s.get("dob_missing_strategy", "fixed"))
        ttk.Radiobutton(box3, text="Use a fixed default DOB:", variable=self.var_dob_strategy,
                         value="fixed").grid(row=0, column=0, sticky="w", padx=10, pady=4)
        self.var_dob_fixed = tk.StringVar(value=s.get("dob_fixed_default", "01-01-1947"))
        ttk.Entry(box3, textvariable=self.var_dob_fixed, width=12).grid(row=0, column=1, sticky="w")
        ttk.Label(box3, text="(dd-mm-yyyy)", style="Sub.TLabel").grid(row=0, column=2, sticky="w")

        ttk.Radiobutton(box3, text="Use Admission Date minus", variable=self.var_dob_strategy,
                         value="admission_minus_years").grid(row=1, column=0, sticky="w", padx=10, pady=4)
        self.var_dob_years = tk.StringVar(value=str(s.get("dob_admission_minus_years", 20)))
        ttk.Entry(box3, textvariable=self.var_dob_years, width=6).grid(row=1, column=1, sticky="w")
        ttk.Label(box3, text="years", style="Sub.TLabel").grid(row=1, column=2, sticky="w")

        ttk.Label(box3, text="Calculate Age as on:").grid(row=2, column=0, sticky="w", padx=10, pady=(10, 4))
        self.var_age_as_on = tk.StringVar(value=s.get("age_as_on", "admission_date"))
        ttk.Radiobutton(box3, text="Admission Date", variable=self.var_age_as_on,
                         value="admission_date").grid(row=3, column=0, sticky="w", padx=10)
        ttk.Radiobutton(box3, text="Today", variable=self.var_age_as_on, value="today").grid(row=3, column=1, sticky="w")
        ttk.Radiobutton(box3, text="Custom date:", variable=self.var_age_as_on, value="custom").grid(row=3, column=2, sticky="w")
        self.var_age_custom = tk.StringVar(value=s.get("age_as_on_custom_date", ""))
        ttk.Entry(box3, textvariable=self.var_age_custom, width=12).grid(row=3, column=3, sticky="w")

        # --- Caste mapping toggle ---
        box4 = ttk.LabelFrame(f, text="Caste Description Handling", style="Card.TFrame")
        box4.grid(row=5, column=0, columnspan=4, sticky="we", padx=10, pady=10)
        self.var_caste_mapping_disabled = tk.BooleanVar(value=s.get("caste_mapping_disabled", False))
        toggle_frame = ttk.Frame(box4)
        toggle_frame.grid(row=0, column=0, sticky="w", padx=10, pady=6)
        self.btn_toggle_caste = ttk.Button(toggle_frame, text="Disable Caste Mapping (Use Source Values)",
                                            command=self._toggle_caste_mapping)
        self.btn_toggle_caste.pack(side="left", padx=4)
        self.lbl_caste_status = ttk.Label(toggle_frame, text="\u2713 Mapping Active", style="Good.TLabel")
        self.lbl_caste_status.pack(side="left", padx=10)
        self._update_caste_toggle_ui()

        # --- AdmissionDate cap: now editable, was hardcoded before ---
        box5 = ttk.LabelFrame(f, text="AdmissionDate Rules (date condition)", style="Card.TFrame")
        box5.grid(row=6, column=0, columnspan=4, sticky="we", padx=10, pady=10)
        box5.columnconfigure(1, weight=1)
        ttk.Label(box5, text="Maximum allowed AdmissionDate (dd-mm-yyyy):").grid(row=0, column=0, sticky="w", **pad)
        self.var_admission_cap = tk.StringVar(
            value=s.get("admission_date_cap", eng.admission_date_cap_str()))
        ttk.Entry(box5, textvariable=self.var_admission_cap, width=14).grid(row=0, column=1, sticky="w", **pad)
        ttk.Button(box5, text="Reset to next 31-March", command=self._reset_admission_cap).grid(row=0, column=2, padx=6)
        ttk.Label(box5, text="Any AdmissionDate greater than this is automatically pulled back to this date. "
                              "This used to be hardcoded to 31-03-2026 (now in the past) -- it auto-advances to "
                              "the next 31-March each year, and you can override it here for special cases.",
                  style="Sub.TLabel", wraplength=850).grid(row=1, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 6))

        # --- Output structure preview ---
        box6 = ttk.LabelFrame(f, text="Output you'll get (Tab 7)", style="Card.TFrame")
        box6.grid(row=7, column=0, columnspan=4, sticky="we", padx=10, pady=10)
        ttk.Label(box6, text="One clean folder, no source/raw files included:\n"
                              "   Split_By_Member/        -- Membership, split by member type\n"
                              "   Split_By_Products/      -- one workbook per loan/deposit template\n"
                              "   Split_By_Transactions/  -- loan transactions, split by product\n"
                              "   Reports/                -- Mapping_Audit_Report.xlsx + Validation_Report.xlsx",
                  style="Sub.TLabel", justify="left", font=("Consolas", 9)).grid(
            row=0, column=0, sticky="w", padx=10, pady=8)

        btn_row = ttk.Frame(f)
        btn_row.grid(row=8, column=0, columnspan=4, sticky="w", padx=10, pady=14)
        self._create_button(btn_row, "Save Setup", self._save_settings).pack(side="left", padx=4)
        self._create_button(btn_row, "Reset Setup Fields", self._reset_setup, kind="ghost").pack(side="left", padx=4)
        self._create_button(btn_row, "\u21BA Reset Entire Process", self._reset_all_process, kind="accent").pack(side="left", padx=14)
        ttk.Label(btn_row, text="Clears every file, conversion, mapping, and report -- starts a fresh session.",
                  style="Sub.TLabel").pack(side="left", padx=6)

    def _reset_admission_cap(self):
        eng.MAX_ADMISSION_DATE = eng._default_fy_end_cap()
        self.var_admission_cap.set(eng.admission_date_cap_str())

    def _toggle_caste_mapping(self):
        new_value = not self.var_caste_mapping_disabled.get()
        self.var_caste_mapping_disabled.set(new_value)
        self.cfg["settings"]["caste_mapping_disabled"] = new_value
        self._update_caste_toggle_ui()

    def _update_caste_toggle_ui(self):
        disabled = self.var_caste_mapping_disabled.get()
        if disabled:
            self.btn_toggle_caste.configure(text="Enable Caste Mapping")
            self.lbl_caste_status.configure(text="\u2717 Mapping Disabled -- using source values directly", style="Warn.TLabel")
        else:
            self.btn_toggle_caste.configure(text="Disable Caste Mapping (Use Source Values)")
            self.lbl_caste_status.configure(text="\u2713 Mapping Active -- values will be normalized", style="Good.TLabel")

    def _reset_setup(self):
        if messagebox.askyesno("Confirm Reset", "Reset all Setup fields to default values?"):
            self.combo_pacs.set("")
            self.combo_user_row.set("")
            self.pacs_info = {}
            self.lbl_pacs_details.configure(text="PacsIDPKey: -    DCCBBrName: -    bulkuploaduserid: -")
            self.var_branch.set("")
            self.var_dob_strategy.set("fixed")
            self.var_dob_fixed.set("01-01-1947")
            self.var_dob_years.set("20")
            self.var_age_as_on.set("admission_date")
            self.var_age_custom.set("")
            self.var_caste_mapping_disabled.set(False)
            self._update_caste_toggle_ui()
            self.status_var.set("Setup reset to defaults")

    def _reset_all_process(self):
        """Clears everything -- source files, conversion output, mapping, masters/transactions, reports --
        and returns the app to a fresh first-run state. Setup fields (PACS selection, output folder,
        DOB/date rules) are left as-is since those are usually reused across sessions; use 'Reset Setup
        Fields' separately if those need clearing too."""
        if not messagebox.askyesno(
            "Reset Entire Process",
            "This clears every source file, conversion result, product mapping, master/transaction "
            "output, and report from this session -- essentially starting over.\n\n"
            "Your Setup tab selections (PACS, output folder, date rules) are kept.\n\n"
            "Continue?"
        ):
            return

        # Source files / files tab
        self.source_files = []
        self.tree_files.delete(*self.tree_files.get_children())

        # Conversion output
        self.full_dfs = {}
        self.last_ctx = None
        self.last_issues = []
        self.village_data = {}
        self.balance_sheet_path = None
        self.balance_sheet_tally = []
        self.txt_log.configure(state="normal")
        self.txt_log.delete("1.0", "end")
        self.txt_log.configure(state="disabled")
        self.progress["value"] = 0
        self.lbl_progress.configure(text="")

        # Mapping / audit / masters / transactions
        self.map_state = eng.AppState()
        self.map_state.pacs_id = self.pacs_info.get("PacsIDPKey", "")
        self.map_state.pacs_name = str(self.pacs_info.get("PacsName", ""))
        self.map_state.load_custom_tax()
        self.mapping_rows = []
        self.var_audit_reviewed.set(False)
        for w in self.map_rows_frame.winfo_children():
            w.destroy()
        self.tree_audit.delete(*self.tree_audit.get_children())
        self.lbl_audit_summary.configure(text="")
        self.txt_masters_log.configure(state="normal")
        self.txt_masters_log.delete("1.0", "end")
        self.txt_masters_log.configure(state="disabled")
        self.lbl_clean_output.configure(text="")
        self.lbl_split_result.configure(text="")

        # Reports
        self.tree_reports.delete(*self.tree_reports.get_children())

        # Disable the tabs that need fresh data again
        for t in (self.tab_split, self.tab_map, self.tab_audit, self.tab_masters, self.tab_reports):
            self.nb.tab(t, state="disabled")
        self.nb.select(self.tab_setup)

        self.status_var.set("Entire process reset -- ready for a new file set.")
        messagebox.showinfo("Reset complete", "Everything has been cleared. Add source files on Tab 2 to start again.")

    def _browse_pacs_file(self):
        path = filedialog.askopenfilename(title="Select PACS ID details.xlsx",
                                           filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")])
        if path:
            self.var_pacs_file.set(path)
            self._load_pacs_file(path)

    def _auto_load_pacs_file(self):
        for cand in ("PACS ID details.xlsx", "PACS_ID_details.xlsx"):
            p = os.path.join(self.base_dir, cand)
            if os.path.exists(p):
                self.var_pacs_file.set(p)
                self._load_pacs_file(p)
                return
        p = self.var_pacs_file.get()
        if p and os.path.exists(p):
            self._load_pacs_file(p)

    def _load_pacs_file(self, path):
        if not path or not os.path.exists(path):
            return
        try:
            df = eng.read_any_table(path)
            df.columns = [str(c).strip() for c in df.columns]
            self.pacs_df = df
            names = sorted(df["PacsName"].dropna().unique().tolist())
            self.combo_pacs.set_options(names)
            self.log(f"Loaded {len(df)} PACS user records from '{os.path.basename(path)}'.")
            self.status_var.set(f"PACS file loaded: {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Could not read PACS ID details file", str(e))
            self.status_var.set("Error loading PACS file")

    def _on_pacs_typed(self, value):
        if self.pacs_df is None:
            return
        rows = self.pacs_df[self.pacs_df["PacsName"] == value]
        if rows.empty:
            return
        labels = []
        for _, r in rows.iterrows():
            labels.append(f"{r.get('# UserName','')}  |  {r.get('bulkuploaduserid','') or '-'}")
        self.combo_user_row["values"] = labels
        self._pacs_candidate_rows = rows.reset_index(drop=True)
        if labels:
            self.combo_user_row.current(0)
            self._on_user_row_selected()

    def _on_user_row_selected(self, event=None):
        idx = self.combo_user_row.current()
        if idx < 0 or getattr(self, "_pacs_candidate_rows", None) is None:
            return
        row = self._pacs_candidate_rows.iloc[idx]
        self.pacs_info = {
            "PacsIDPKey": str(row.get("PacsIDPKey", "")).strip(),
            "PacsName": row.get("PacsName", ""),
            "DCCBBrName": row.get("DCCBBrName", ""),
            "UserName": row.get("# UserName", ""),
            "bulkuploaduserid": row.get("bulkuploaduserid", ""),
        }
        self.lbl_pacs_details.configure(
            text=f"PacsIDPKey: {self.pacs_info['PacsIDPKey']}    "
                 f"DCCBBrName: {self.pacs_info['DCCBBrName']}    "
                 f"bulkuploaduserid: {self.pacs_info['bulkuploaduserid']}")
        self.status_var.set(f"Selected PACS: {self.pacs_info['PacsName']}")
        self.map_state.pacs_id = self.pacs_info["PacsIDPKey"]
        self.map_state.pacs_name = str(self.pacs_info["PacsName"])
        self._update_output_folder()

    def _update_output_folder(self):
        base = self.var_outdir.get().strip() or os.getcwd()
        self.last_output_dir = base

    def _browse_outdir(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.var_outdir.set(path)

    def _save_settings(self, silent=False):
        s = self.cfg["settings"]
        s["pacs_id_details_path"] = self.var_pacs_file.get()
        s["last_output_dir"] = self.var_outdir.get()
        s["dob_missing_strategy"] = self.var_dob_strategy.get()
        s["dob_fixed_default"] = self.var_dob_fixed.get()
        try:
            s["dob_admission_minus_years"] = int(self.var_dob_years.get())
        except ValueError:
            pass
        s["age_as_on"] = self.var_age_as_on.get()
        s["age_as_on_custom_date"] = self.var_age_custom.get()
        s["caste_mapping_disabled"] = self.var_caste_mapping_disabled.get()
        s["admission_date_cap"] = self.var_admission_cap.get()
        cap_dt = eng.parse_date_from_string(self.var_admission_cap.get())
        if cap_dt:
            eng.set_admission_date_cap(cap_dt)
        try:
            eng.save_config(self.base_dir, self.cfg)
            if not silent:
                messagebox.showinfo("Saved", "Setup saved.")
        except Exception as e:
            if not silent:
                messagebox.showerror("Could not save", str(e))

    # ================================================================
    # TAB 2: SOURCE FILES  (unchanged behaviour from the DCT tool)
    # ================================================================
    def _build_files_tab(self):
        f = self.tab_files
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Source Files", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Add every raw export file for one PACS. The tool detects the type from the "
                          "filename -- double-click a row to change it if it guessed wrong.",
                  style="Sub.TLabel", wraplength=900).grid(row=1, column=0, columnspan=4, sticky="w", padx=10)

        btnf = ttk.Frame(f)
        btnf.grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=6)
        self._create_button(btnf, "Add Files...", self._add_files).pack(side="left", padx=4)
        self._create_button(btnf, "Remove Selected", self._remove_selected_files).pack(side="left", padx=4)
        self._create_button(btnf, "Clear All", self._clear_files).pack(side="left", padx=4)

        cols = ("file", "type", "rows", "status")
        self.tree_files = ttk.Treeview(f, columns=cols, show="headings", height=18)
        self.tree_files.heading("file", text="File")
        self.tree_files.heading("type", text="Detected Type")
        self.tree_files.heading("rows", text="Rows")
        self.tree_files.heading("status", text="Status")
        self.tree_files.column("file", width=420)
        self.tree_files.column("type", width=320)
        self.tree_files.column("rows", width=70, anchor="center")
        self.tree_files.column("status", width=180)
        self.tree_files.grid(row=3, column=0, columnspan=4, sticky="nsew", padx=10, pady=6)
        self.tree_files.bind("<Double-1>", self._edit_file_type)
        f.rowconfigure(3, weight=1)
        f.columnconfigure(0, weight=1)

    def _add_files(self):
        paths = filedialog.askopenfilenames(
            title="Select PACS DCT source files (or a .zip/.rar containing them)",
            filetypes=[("Excel + Archive files", "*.xls *.xlsx *.zip *.rar"),
                       ("Excel files", "*.xls *.xlsx"), ("Archives", "*.zip *.rar"), ("All files", "*.*")])
        extracted_dir = None
        for p in paths:
            ext = os.path.splitext(p)[1].lower()
            if ext in (".zip", ".rar"):
                if extracted_dir is None:
                    extracted_dir = os.path.join(self.base_dir if hasattr(self, "base_dir") else ".",
                                                  ".pacs_dct_suite_extracted")
                    os.makedirs(extracted_dir, exist_ok=True)
                extracted_files, warning = eng.extract_archive_to_temp(p, extracted_dir)
                if warning:
                    messagebox.showwarning(f"Extracting {os.path.basename(p)}", warning)
                for ep in extracted_files:
                    if any(sf["path"] == ep for sf in self.source_files):
                        continue
                    stype = eng.detect_sheet_type(ep)
                    self.source_files.append({"path": ep, "type": stype, "rows": "-", "status": "Pending"})
                    self.tree_files.insert("", "end", iid=ep, values=(
                        f"{os.path.basename(ep)}  (from {os.path.basename(p)})",
                        eng.SHEET_TYPE_LABELS.get(stype, stype), "-", "Pending"))
                if extracted_files:
                    self.log(f"Extracted {len(extracted_files)} file(s) from {os.path.basename(p)}")
                continue
            if any(sf["path"] == p for sf in self.source_files):
                continue
            stype = eng.detect_sheet_type(p)
            entry = {"path": p, "type": stype, "rows": "-", "status": "Pending"}
            self.source_files.append(entry)
            self.tree_files.insert("", "end", iid=p, values=(
                os.path.basename(p), eng.SHEET_TYPE_LABELS.get(stype, stype), "-", "Pending"))

    def _remove_selected_files(self):
        for iid in self.tree_files.selection():
            self.tree_files.delete(iid)
            self.source_files = [sf for sf in self.source_files if sf["path"] != iid]

    def _clear_files(self):
        self.tree_files.delete(*self.tree_files.get_children())
        self.source_files = []

    def _edit_file_type(self, event):
        iid = self.tree_files.identify_row(event.y)
        if not iid:
            return
        current = next((sf for sf in self.source_files if sf["path"] == iid), None)
        if not current:
            return
        choices = list(eng.SHEET_TYPE_LABELS.keys())
        labels = [eng.SHEET_TYPE_LABELS[c] for c in choices]
        win = tk.Toplevel(self)
        win.title("Change file type")
        win.grab_set()
        ttk.Label(win, text=f"File: {os.path.basename(iid)}").pack(padx=14, pady=(14, 6))
        var = tk.StringVar(value=eng.SHEET_TYPE_LABELS.get(current["type"], current["type"]))
        combo = ttk.Combobox(win, textvariable=var, values=labels, state="readonly", width=60)
        combo.pack(padx=14, pady=6)

        def apply():
            chosen_label = var.get()
            for c, l in zip(choices, labels):
                if l == chosen_label:
                    current["type"] = c
                    vals = self.tree_files.item(iid, "values")
                    self.tree_files.item(iid, values=(os.path.basename(iid), l, vals[2], vals[3]))
                    break
            win.destroy()

        ttk.Button(win, text="OK", command=apply).pack(pady=(6, 14))

    # ================================================================
    # TAB 3: CONVERT & VALIDATE
    # ================================================================
    def _build_run_tab(self):
        f = self.tab_run
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Convert & Validate", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Runs cleaning + validation on every source file, checks account dates against "
                          "AdmissionDate, flags duplicate & special/invalid Member Numbers, and checks for "
                          "Missing Membership references.", style="Sub.TLabel", wraplength=920).grid(
            row=1, column=0, columnspan=4, sticky="w", padx=10)

        btnf = ttk.Frame(f)
        btnf.grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=6)
        self._create_button(btnf, "Start Conversion", self._start_conversion).pack(side="left", padx=4)
        ttk.Label(btnf, text="Validation Report is saved automatically to the Reports folder every time "
                             "you generate the clean output (Tab 7) -- no separate export needed.",
                  style="Sub.TLabel").pack(side="left", padx=14)

        self.progress = ttk.Progressbar(f, orient="horizontal", mode="determinate", length=500)
        self.progress.grid(row=3, column=0, columnspan=4, sticky="we", padx=10, pady=6)
        self.lbl_progress = ttk.Label(f, text="", style="Sub.TLabel")
        self.lbl_progress.grid(row=4, column=0, columnspan=4, sticky="w", padx=10)

        self.txt_log = ScrolledText(f, height=28, state="disabled", font=("Consolas", 9))
        self.txt_log.grid(row=5, column=0, columnspan=4, sticky="nsew", padx=10, pady=8)
        f.rowconfigure(5, weight=1)
        f.columnconfigure(0, weight=1)

    def _update_progress(self, val, msg):
        # Same thread-safety fix as log() above -- marshaled via self.after() instead of touching
        # the Progressbar/Label directly from the background conversion thread.
        def _do():
            self.progress["value"] = val
            self.lbl_progress.configure(text=msg)
        self.after(0, _do)

    def _start_conversion(self):
        if not self.source_files:
            messagebox.showwarning("No files", "Add source files on the 'Source Files' tab first.")
            return
        if not self.var_outdir.get().strip():
            messagebox.showwarning("Output folder missing", "Set an output folder on the Setup tab first.")
            return
        threading.Thread(target=self._run_conversion, daemon=True).start()

    def _run_conversion(self):
        try:
            self._run_conversion_body()
        except Exception:
            self.log("FATAL ERROR:\n" + traceback.format_exc())
            # Marshaled onto the main thread -- see the matching note on log()/_update_progress() above.
            # A modal dialog shown directly from a background thread is unsafe in Tkinter and was
            # confirmed (via a real stack-trace capture, not a guess) to cause an indefinite hang.
            self.after(0, lambda: messagebox.showerror("Conversion failed", "See the log for details."))

    def _run_conversion_body(self):
        outdir_base = self.var_outdir.get().strip()
        pacs_name = self.pacs_info.get("PacsName", "NoPACS")
        safe_pacs = eng.sanitize_folder_name(str(pacs_name), max_len=15)
        # NOTE: we deliberately do NOT create/write into this folder here. Conversion output stays
        # in memory (self.full_dfs) -- no raw/source *_Raw.xlsx files are ever written to disk. The
        # only thing that gets written to disk is the final clean 4-folder output (Tab: Masters &
        # Transactions -> "Generate Clean Output"), which is what the person actually needs.
        outdir_preview = os.path.join(outdir_base, safe_pacs or "Output")
        self.log(f"Output folder (used later, for the final clean output): {outdir_preview}")

        branch_id = self.var_branch.get().strip()
        s = self.cfg["settings"]
        cap_dt = eng.parse_date_from_string(self.var_admission_cap.get())
        if cap_dt:
            eng.set_admission_date_cap(cap_dt)

        ctx = eng.ConversionContext(self.cfg, pacs_info=self.pacs_info, branch_id=branch_id,
                                     ask_user_callback=None, log_callback=self.log,
                                     progress_callback=self._update_progress)

        combined_outputs = {}
        self.log(f"=== Starting conversion: {_dtmod.datetime.now():%Y-%m-%d %H:%M:%S} ===")
        self.log(f"   AdmissionDate capped at: {eng.admission_date_cap_str()}")
        self.log("   Caste mapping " + ("DISABLED (using source values)" if s.get("caste_mapping_disabled") else "ACTIVE"))

        total = len(self.source_files)
        village_ref_paths = []
        balance_sheet_path = None
        for idx, sf in enumerate(self.source_files):
            path = sf["path"]
            stype = sf["type"]
            self._update_progress(((idx + 1) / total) * 80, f"Processing {os.path.basename(path)}...")
            self.log(f"\n--- {os.path.basename(path)}  (type: {eng.SHEET_TYPE_LABELS.get(stype, stype)}) ---")
            if stype == "VillagesRef":
                # Not part of bulk-upload conversion itself, but DOES get used below to fill in
                # VillageDescription from Address1/Address2 wherever the source left it blank --
                # previously this file was detected correctly but then silently ignored entirely.
                village_ref_paths.append(path)
                self.log("   Village reference file -- will be used to fill blank VillageDescription values.")
                continue
            if stype == "BalanceSheet":
                # Not part of bulk-upload conversion, but used later to tally Product Mapping totals
                # against the PACS's own official balance sheet figures -- confirmed on real data that
                # this catches genuine mapping problems (two products both matching one balance sheet
                # line, amounts split incorrectly, etc.) that nothing else would surface.
                balance_sheet_path = path
                self.log("   Balance Sheet file -- will be used to tally Product Mapping totals after mapping.")
                continue
            if stype in ("Unknown", "PacsIdRef"):
                self.log("   Skipped (reference file / not part of bulk-upload conversion).")
                continue
            try:
                df = eng.read_any_table(path)
            except Exception as e:
                self.log(f"   COULD NOT READ this file: {e}")
                continue
            try:
                outputs = eng.convert_sheet(stype, df, ctx)
            except Exception as e:
                self.log(f"   CONVERSION ERROR: {e}")
                continue
            for fname, odf in outputs.items():
                combined_outputs.setdefault(fname, []).append(odf)
                self.log(f"   -> {fname}: {len(odf)} rows")
        self.balance_sheet_path = balance_sheet_path

        full_dfs = {}
        for fname, parts in combined_outputs.items():
            full_dfs[fname] = pd.concat(parts, ignore_index=True) if len(parts) > 1 else parts[0]
        self.full_dfs = full_dfs

        if village_ref_paths:
            self.log(f"\nLoading village reference data from {len(village_ref_paths)} file(s)...")
            self.village_data = {}
            for vp in village_ref_paths:
                try:
                    loaded = eng.load_village_reference(vp)
                    self.village_data.update(loaded)
                    self.log(f"   {os.path.basename(vp)}: {len(loaded)} village(s) loaded")
                except Exception as e:
                    self.log(f"   COULD NOT READ {os.path.basename(vp)}: {e}")
            membership_df = full_dfs.get("MembershipTemplate.xlsx")
            if membership_df is not None and self.village_data:
                village_results = eng.apply_village_mapping(membership_df, self.village_data, ctx)
                matched = sum(1 for r in village_results if r["Status"] == "Matched")
                self.log(f"   VillageDescription filled from address text: {matched} matched, "
                          f"{len(village_results) - matched} not found (of {len(village_results)} "
                          f"rows that had a blank village and an address to try)")
                ctx.village_mapping_results = village_results

        self.log("\nChecking account dates against AdmissionDate...")
        adm_adj, sb_adj = eng.check_admission_vs_account_dates(full_dfs, ctx)
        self.log(f"   AdmissionDate changes: {len(adm_adj)}   SB/Pigmy date changes: {len(sb_adj)}")

        self.log("\nChecking for Missing Membership...")
        missing_rows = eng.check_missing_membership(full_dfs, ctx)
        self.log(f"   Missing Membership rows: {len(missing_rows)}")

        self.log("\nChecking Duplicate Member Numbers and Special/Invalid Member Numbers...")
        # NOTE: convert_membership() already calls ctx.report_duplicates() internally as part
        # of processing the Membership sheet -- calling it again here would double-count every
        # duplicate row, so we only read the results it already populated.
        membership_file = "MembershipTemplate.xlsx"
        membership_df = full_dfs.get(membership_file)
        special_rows = eng.check_special_member_numbers(membership_df, ctx)
        self.log(f"   Duplicate member rows flagged: {len(ctx.duplicate_member_rows)}")
        self.log(f"   Special/invalid member numbers flagged: {len(special_rows)}")
        if special_rows:
            self.log("   (Member Number must be numeric only -- values like A125 / B226 are not allowed)")
            reassign_map = eng.reassign_invalid_member_numbers(full_dfs, ctx)
            if reassign_map:
                self.log(f"   Reassigned {len(reassign_map)} alphanumeric Member Number(s) to valid numbers, "
                          f"and updated every table that referenced them (Membership, Masters, Transactions).")
                for r in ctx.member_number_reassignments[:8]:
                    self.log(f"      '{r['OriginalAdmissionNo']}' -> '{r['AssignedNewAdmissionNo']}' ({r['Name']})")
                if len(ctx.member_number_reassignments) > 8:
                    self.log(f"      ... and {len(ctx.member_number_reassignments) - 8} more (see Reports tab)")

        self.log("\nChecking Loan and Deposit records for missing mandatory fields...")
        eng.check_incomplete_loans(full_dfs, ctx)
        eng.check_incomplete_deposits(full_dfs, ctx)
        self.log(f"   Loans with missing mandatory fields: {len(ctx.loan_incomplete_rows)}")
        self.log(f"   Deposits with missing mandatory fields: {len(ctx.deposit_incomplete_rows)}")

        self._update_progress(90, "Finalizing in-memory conversion output...")
        self.log(f"\n{len(full_dfs)} output table(s) built in memory "
                  f"({sum(len(df) for df in full_dfs.values())} total rows). "
                  f"Nothing written to disk yet -- go to Tab 4 to split, then generate the final "
                  f"clean output folder from the Masters & Transactions tab.")

        self.last_issues = list(ctx.issues)
        self.last_ctx = ctx
        eng.save_config(self.base_dir, self.cfg)

        self._update_progress(100, "Conversion complete")
        self.log(f"\n=== Done. {len(self.last_issues)} validation "
                  f"issue(s) found. Continue to Tab 4 to split by Member or Product. ===")
        for t in (self.tab_split, self.tab_reports):
            self.nb.tab(t, state="normal")
        self._refresh_reports_summary()
        self._auto_save_reports()
        # NOTE: previously showed a messagebox.showinfo() popup here summarizing the same numbers
        # already in the log line above and the status bar below. Removed for two real reasons, not
        # just redundancy: (1) it was called from the background conversion thread, which is unsafe in
        # Tkinter and was confirmed (via a captured stack trace, not a guess) to cause an indefinite
        # hang when nothing was there to click it -- exactly the kind of freeze a real user could hit
        # unpredictably; (2) it added an extra interrupt-and-click step after every single conversion
        # for no new information over what's already visible in the log and status bar.
        self.status_var.set(f"Conversion complete: {len(full_dfs)} tables in memory, {len(self.last_issues)} issue(s).")

    def _auto_save_reports(self, silent=True):
        """Writes Validation_Report.xlsx and (once mapping data exists) Mapping_Audit_Report.xlsx to the
        Reports folder automatically -- called after conversion and after Masters/Transactions, so both
        reports are always current on disk without a separate 'export' button to click."""
        if not self.var_outdir.get().strip() or not self.pacs_info:
            return  # nowhere to save yet -- Setup tab needs a PACS + output folder first
        if not self.last_issues and not self.map_state.validation_reports and not self.map_state.combos:
            return
        outdir = self.var_outdir.get()
        pacs_name = self.pacs_info.get("PacsName", "NoPACS")
        report_dir = os.path.join(outdir, eng.sanitize_folder_name(str(pacs_name), max_len=15), "Reports")
        os.makedirs(report_dir, exist_ok=True)
        try:
            eng.write_validation_report(self.map_state, self.last_ctx, os.path.join(report_dir, "Validation_Report.xlsx"))
            if self.map_state.combos:
                eng.write_mapping_audit_report(self.map_state, os.path.join(report_dir, "Mapping_Audit_Report.xlsx"))
            self.status_var.set(f"Reports auto-saved to: {report_dir}")
        except Exception as e:
            if not silent:
                messagebox.showerror("Could not save reports", str(e))

    # ================================================================
    # TAB 4: LOAD FOR MAPPING
    # ================================================================
    def _build_split_tab(self):

        f = self.tab_split
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Load Loan / Deposit Data for Mapping", style="Header.TLabel").grid(
            row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Loads every loan/deposit row from the conversion straight into Product Mapping "
                          "-- no intermediate files. Membership, Masters, Transactions, and Reports are all "
                          "written together at the end (Tab 7) as one clean output folder.",
                  style="Sub.TLabel", wraplength=900).grid(row=1, column=0, columnspan=3, sticky="w", padx=10)

        btnf = ttk.Frame(f)
        btnf.grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=10)
        self._create_button(btnf, "Load into Product Mapping", self._run_split).pack(side="left", padx=4)

        self.lbl_split_result = ttk.Label(f, text="", style="Sub.TLabel", wraplength=900)
        self.lbl_split_result.grid(row=3, column=0, columnspan=3, sticky="w", padx=10, pady=6)

    def _run_split(self):
        if not self.full_dfs:
            messagebox.showwarning("Nothing to load", "Run a conversion first (Tab 3).")
            return
        ctx = self.last_ctx
        # Wire the Setup tab's actual Branch Code into map_state -- this is what build_master_row()
        # uses for Masters/Transactions, and it must reflect the real UI value at the moment Split
        # runs (the person may have changed it after Convert), not a stale value from AppState's own
        # init. Blank means "nothing explicit" -> None, so build_master_row() correctly falls through
        # to the source file's own BranchId instead of a wrong hardcoded default.
        self.map_state.default_branch = eng.valid_branch(self.var_branch.get().strip()) or None
        summary = eng.load_dct_output_into_state(self.full_dfs, self.map_state)
        n_rows = sum(v[1] for v in summary.values() if v[0] != "Transactions")
        result_text = (f"Loaded. {len(summary)} category file(s) into Product Mapping ({n_rows} account rows "
                       f"across {len(self.map_state.combos)} product/purpose combinations). "
                       f"Opening the Product Mapping tab...")
        skipped = self.map_state.skipped_no_product
        if skipped:
            details = "; ".join(f"{v['category']} ({v['skipped_rows']} of {v['total_rows']} rows in {k})"
                                 for k, v in skipped.items())
            result_text += (f"\n\n\u26A0 Some rows had a blank ProductDescription and could not be "
                            f"mapped at all -- they will NOT appear in Product Mapping: {details}. "
                            f"See the Reports tab for the full breakdown; this is usually a sign that "
                            f"the source file uses a different column name for the product than this "
                            f"tool recognized.")
        if self.balance_sheet_path:
            try:
                bs_amounts = eng.extract_balance_sheet_amounts(self.balance_sheet_path)
                self.balance_sheet_tally = eng.build_balance_sheet_tally(self.map_state, bs_amounts)
                ctx.balance_sheet_tally = self.balance_sheet_tally
                n_tallied = sum(1 for r in self.balance_sheet_tally if r["Status"] == "Tallied")
                result_text += (f"\n\n\U0001F4CA Balance Sheet tally: {n_tallied} of "
                                f"{len(self.balance_sheet_tally)} product(s) tallied against "
                                f"{os.path.basename(self.balance_sheet_path)}. See the Reports tab for "
                                f"the full breakdown.")
            except Exception as e:
                self.log(f"Balance Sheet tally failed: {e}")
        self.lbl_split_result.configure(text=result_text)
        self.status_var.set("Loaded into Product Mapping.")
        self.nb.tab(self.tab_map, state="normal")
        self.nb.tab(self.tab_audit, state="normal")
        self.nb.tab(self.tab_masters, state="normal")
        self.var_audit_reviewed.set(False)
        self._render_mapping_table()
        self._refresh_map_progress_label()
        self._refresh_audit_table()
        self._check_operation_type_popup()
        self.nb.select(self.tab_map)

    def _check_operation_type_popup(self):
        """OperationTypeDesc values that don't confidently match the allowed enum (e.g. the real-world
        'PRESIDENT AND SECRETORY' found in sample data) get a small popup asking where to map them,
        instead of a silent guess."""
        unresolved = eng.scan_operation_type_values(self.map_state)
        unresolved = [u for u in unresolved if u["RawValue"] not in self.map_state.operation_type_overrides]
        if not unresolved:
            return
        win = tk.Toplevel(self)
        win.title("Map OperationTypeDesc values")
        win.geometry("620x420")
        win.grab_set()
        ttk.Label(win, text="These OperationTypeDesc values don't confidently match the allowed list.\n"
                            "Choose where each one should map (a best guess is pre-filled):",
                  wraplength=580, justify="left").pack(padx=14, pady=10, anchor="w")

        canvas = tk.Canvas(win)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True, padx=(14, 0))
        scrollbar.pack(side="right", fill="y")

        choice_vars = {}
        for i, u in enumerate(unresolved):
            row = ttk.Frame(inner)
            row.pack(fill="x", pady=4, padx=4)
            ttk.Label(row, text=f'"{u["RawValue"]}"  ({u["Count"]} row(s))', width=32).pack(side="left")
            var = tk.StringVar(value=u["BestGuess"] or eng.OPERATION_TYPE_ENUM[0])
            ttk.Combobox(row, textvariable=var, values=eng.OPERATION_TYPE_ENUM, state="readonly",
                         width=22).pack(side="left", padx=6)
            choice_vars[u["RawValue"]] = var

        def apply_and_close():
            for raw_val, var in choice_vars.items():
                self.map_state.operation_type_overrides[raw_val] = var.get()
            win.destroy()
            messagebox.showinfo("Saved", f"{len(choice_vars)} OperationTypeDesc value(s) mapped. "
                                          "They'll be applied when Masters are generated.")

        btn_row = ttk.Frame(win)
        btn_row.pack(fill="x", pady=10, padx=14)
        self._create_button(btn_row, "Apply Mapping", apply_and_close).pack(side="right")


    # ================================================================
    # TAB 5: PRODUCT MAPPING
    # ================================================================
    def _build_map_tab(self):
        f = self.tab_map
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Product Mapping", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Every raw Product + Purpose/Crop combination found in the split-by-product data, "
                          "with a fuzzy best-guess already filled in. Purpose/Crop options automatically "
                          "narrow based on the chosen Product (per the Crop/Purpose Requirement rules).",
                  style="Sub.TLabel", wraplength=920).grid(row=1, column=0, columnspan=6, sticky="w", padx=10)

        toolbar = ttk.Frame(f)
        toolbar.grid(row=2, column=0, columnspan=6, sticky="we", padx=10, pady=6)
        ttk.Label(toolbar, text="Filter category:").pack(side="left")
        self.var_map_filter_cat = tk.StringVar(value="")
        cb = ttk.Combobox(toolbar, textvariable=self.var_map_filter_cat, state="readonly", width=18,
                           values=[""] + list(eng.CATEGORY_LABEL.keys()))
        cb.pack(side="left", padx=6)
        cb.bind("<<ComboboxSelected>>", lambda e: self._render_mapping_table())
        ttk.Label(toolbar, text="Search:").pack(side="left", padx=(14, 0))
        self.var_map_search = tk.StringVar()
        e = ttk.Entry(toolbar, textvariable=self.var_map_search, width=24)
        e.pack(side="left", padx=6)
        e.bind("<KeyRelease>", lambda ev: self._render_mapping_table())
        self._create_button(toolbar, "Re-run Best Guess", self._fill_best_guess).pack(side="left", padx=10)
        self.lbl_map_progress = ttk.Label(toolbar, text="", style="Sub.TLabel")
        self.lbl_map_progress.pack(side="left", padx=14)

        bulk_bar = ttk.Frame(f)
        bulk_bar.grid(row=3, column=0, columnspan=6, sticky="we", padx=10, pady=(0, 6))
        self._create_button(bulk_bar, "\U0001F517 Merge Product-wise", self._apply_merge_by_product,
                            kind="accent").pack(side="left", padx=4)
        ttk.Label(bulk_bar, text="Confirm one Purpose/Crop variant of a product, then click this to apply "
                                 "the same Product to every other variant of it.",
                  style="Sub.TLabel").pack(side="left", padx=(0, 20))
        self._create_button(bulk_bar, "\U0001F4CB Keep As Source Data", self._apply_keep_as_source,
                            kind="ghost").pack(side="left", padx=4)
        ttk.Label(bulk_bar, text="For every unconfirmed row, trusts the source file's own "
                                 "Product/Purpose text as final (no fuzzy-match review needed).",
                  style="Sub.TLabel").pack(side="left")

        header = ttk.Frame(f)
        header.grid(row=4, column=0, columnspan=6, sticky="we", padx=12)
        for txt, col, w in [("Cat", 0, 8), ("Raw Product", 1, 24), ("Raw Purpose/Crop", 2, 18),
                            ("#", 3, 6), ("Amount", 4, 12), ("-> Product", 5, 26),
                            ("-> Purpose/Crop", 6, 22), ("Status", 7, 16)]:
            ttk.Label(header, text=txt, font=("Segoe UI", 9, "bold"), width=w).grid(row=0, column=col, sticky="w")

        canvas = tk.Canvas(f, height=420)
        vsb = ttk.Scrollbar(f, orient="vertical", command=canvas.yview)
        self.map_rows_frame = ttk.Frame(canvas)
        self.map_rows_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.map_rows_frame, anchor="nw")
        canvas.configure(yscrollcommand=vsb.set)
        canvas.grid(row=5, column=0, columnspan=5, sticky="nsew", padx=(12, 0), pady=6)
        vsb.grid(row=5, column=5, sticky="ns", pady=6)
        f.rowconfigure(5, weight=1)
        f.columnconfigure(0, weight=1)

    def _fill_best_guess(self):
        eng.apply_autofill(self.map_state, overwrite=False)
        self._render_mapping_table()

    def _apply_merge_by_product(self):
        n = eng.apply_merge_by_raw_product(self.map_state)
        self._render_mapping_table()
        if n:
            messagebox.showinfo("Merged", f"{n} row(s) updated to match their product's already-confirmed mapping.")
        else:
            messagebox.showinfo("Nothing to merge", "Confirm at least one Purpose/Crop variant of a product "
                                                     "first (change its dropdown, or use 'Keep As Source Data'), "
                                                     "then click this again to apply it to the other variants.")

    def _apply_keep_as_source(self):
        if not messagebox.askyesno("Keep As Source Data",
                                     "For every row not yet confirmed, this sets the mapped Product/Purpose "
                                     "to exactly what the source file says, and marks it confirmed.\n\n"
                                     "Use this when you know the source file's own wording is already correct "
                                     "and doesn't need review.\n\nContinue?"):
            return
        n = eng.apply_keep_source_as_mapped(self.map_state, only_unlocked=True)
        self._render_mapping_table()
        messagebox.showinfo("Done", f"{n} row(s) set to keep the source Product/Purpose text as-is.")

    def _render_mapping_table(self):
        for w in self.map_rows_frame.winfo_children():
            w.destroy()
        self.mapping_rows = []
        cat_filter = self.var_map_filter_cat.get() or None
        search = self.var_map_search.get().strip()

        # Group by (category, rawProduct) so every Purpose/Crop variant of the same product sits
        # together as a visible cluster, instead of being scattered across a flat amount-sorted list --
        # this is what makes it practical to map or merge all of a product's variants in one pass,
        # since you can literally see them adjacent to each other rather than hunting through the list.
        groups = {}
        for key, combo in self.map_state.combos.items():
            groups.setdefault((combo["category"], combo["rawProduct"]), []).append((key, combo))
        group_totals = {gk: sum(c["amount"] for _, c in items) for gk, items in groups.items()}
        ordered_groups = sorted(groups.items(), key=lambda kv: -group_totals[kv[0]])

        P = self.PALETTE
        for (category, raw_product), items in ordered_groups:
            items.sort(key=lambda kv: -kv[1]["amount"])
            visible_items = [(k, c) for k, c in items
                              if MappingRow.static_matches_filter(c, cat_filter, search)]
            if not visible_items:
                continue
            if len(visible_items) > 1:
                header = tk.Frame(self.map_rows_frame, bg=P["primary_light"])
                header.pack(fill="x", pady=(8, 1), padx=2)
                # Shows the count/total of what's actually VISIBLE after filtering, not the group's
                # full unfiltered size -- otherwise a search that narrows a 5-variant group down to 1
                # match would still claim "5 variants" right above the single row actually shown.
                visible_total = sum(c["amount"] for _, c in visible_items)
                tk.Label(header, text=f"  {eng.CATEGORY_LABEL.get(category, category)} \u2192 {raw_product}"
                                       f"  ({len(visible_items)} Purpose/Crop variant{'s' if len(visible_items) != 1 else ''}, "
                                       f"total \u20B9{visible_total:,.0f})",
                         bg=P["primary_light"], fg=P["primary"], font=("Segoe UI", 9, "bold"),
                         anchor="w").pack(fill="x", padx=4, pady=3)
            for key, combo in visible_items:
                row = MappingRow(self.map_rows_frame, key, combo, self.map_state,
                                  self._refresh_map_progress_label, self._render_mapping_table)
                self.mapping_rows.append(row)
        self._refresh_map_progress_label()

    def _refresh_map_progress_label(self):
        total = len(self.map_state.combos)
        confirmed = sum(1 for c in self.map_state.combos.values() if c.get("locked") or (c.get("confidence") or 0) >= 0.75)
        self.lbl_map_progress.configure(text=f"{confirmed}/{total} mapped with high confidence")

    # ================================================================
    # TAB 6: MAPPING AUDIT
    # A dedicated checkpoint between Product Mapping and Masters & Transactions --
    # review every mapping decision (and export the audit report) BEFORE generating
    # Masters/Transactions, rather than only being able to see it afterward.
    # ================================================================
    def _build_audit_tab(self):
        f = self.tab_audit
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Mapping Audit", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Review every Product/Purpose mapping decision below and export the audit report "
                          "before generating Masters & Transactions. This is the same data that ends up in "
                          "the final Mapping Audit report, shown here as a checkpoint before generation.",
                  style="Sub.TLabel", wraplength=920).grid(row=1, column=0, columnspan=4, sticky="w", padx=10)

        btnf = ttk.Frame(f)
        btnf.grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=6)
        self._create_button(btnf, "Refresh", self._refresh_audit_table).pack(side="left", padx=4)
        self.lbl_audit_summary = ttk.Label(btnf, text="", style="Sub.TLabel")
        self.lbl_audit_summary.pack(side="left", padx=14)

        cols = ("category", "raw_product", "raw_second", "mapped_product", "mapped_second",
                "accounts", "amount", "confidence")
        self.tree_audit = ttk.Treeview(f, columns=cols, show="headings", height=20)
        headers = {"category": "Category", "raw_product": "Raw Product", "raw_second": "Raw Purpose/Crop",
                   "mapped_product": "-> Product", "mapped_second": "-> Purpose/Crop",
                   "accounts": "Accounts", "amount": "Amount", "confidence": "Confidence"}
        widths = {"category": 90, "raw_product": 200, "raw_second": 160, "mapped_product": 210,
                  "mapped_second": 180, "accounts": 80, "amount": 110, "confidence": 90}
        for c in cols:
            self.tree_audit.heading(c, text=headers[c])
            anchor = "e" if c in ("accounts", "amount") else "w"
            self.tree_audit.column(c, width=widths[c], anchor=anchor)
        self.tree_audit.grid(row=3, column=0, columnspan=4, sticky="nsew", padx=10, pady=6)
        f.rowconfigure(3, weight=1)
        f.columnconfigure(0, weight=1)

        gate = ttk.LabelFrame(f, text="Sign-off before generating Masters/Transactions", style="Card.TFrame")
        gate.grid(row=4, column=0, columnspan=4, sticky="we", padx=10, pady=10)
        ttk.Checkbutton(gate, text="I have reviewed this Mapping Audit and confirm the Product/Purpose "
                                   "mappings above are correct.",
                        variable=self.var_audit_reviewed).pack(anchor="w", padx=10, pady=8)

    def _refresh_audit_table(self):
        self.tree_audit.delete(*self.tree_audit.get_children())
        combos = [c for c in self.map_state.combos.values() if c.get("mappedProduct")]
        total_amount = 0.0
        low_conf = 0
        for c in sorted(combos, key=lambda c: (-c["amount"], c["rawProduct"])):
            conf_pct = round((c.get("confidence") or 0) * 100)
            conf_label = "confirmed" if c.get("locked") else f"{conf_pct}%"
            if not c.get("locked") and conf_pct < 75:
                low_conf += 1
            total_amount += c["amount"]
            self.tree_audit.insert("", "end", values=(
                eng.CATEGORY_LABEL.get(c["category"], c["category"]), c["rawProduct"], c["rawSecond"] or "\u2014",
                c["mappedProduct"], c["mappedSecond"] or "\u2014", c["count"], f'{c["amount"]:,.0f}', conf_label))
        self.lbl_audit_summary.configure(
            text=f"{len(combos)} combination(s), total amount {total_amount:,.0f}. "
                 f"{low_conf} combination(s) below 75% confidence and not yet confirmed -- "
                 f"double-check these on the Product Mapping tab.")

    # ================================================================
    # TAB 7: MASTERS & TRANSACTIONS
    # ================================================================
    def _build_masters_tab(self):
        f = self.tab_masters
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Masters & Transactions", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Generate the final Master workbooks (one per canonical product) from the mapping "
                          "above, then process the Loan Transaction Details against them.",
                  style="Sub.TLabel", wraplength=900).grid(row=1, column=0, columnspan=3, sticky="w", padx=10)

        btnf = ttk.Frame(f)
        btnf.grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=10)
        self._create_button(btnf, "Generate Masters", self._generate_masters).pack(side="left", padx=4)
        self._create_button(btnf, "Process Transactions", self._process_transactions).pack(side="left", padx=4)
        self._create_button(btnf, "\U0001F4E6 Generate Clean Output Folder", self._generate_clean_output,
                            kind="accent").pack(side="left", padx=4)

        self.lbl_clean_output = ttk.Label(f, text="", style="Sub.TLabel", wraplength=900)
        self.lbl_clean_output.grid(row=3, column=0, columnspan=3, sticky="w", padx=10)

        self.txt_masters_log = ScrolledText(f, height=22, state="disabled", font=("Consolas", 9))
        self.txt_masters_log.grid(row=4, column=0, columnspan=3, sticky="nsew", padx=10, pady=8)
        f.rowconfigure(4, weight=1)
        f.columnconfigure(0, weight=1)

    def _mlog(self, msg):
        self.txt_masters_log.configure(state="normal")
        self.txt_masters_log.insert("end", str(msg) + "\n")
        self.txt_masters_log.see("end")
        self.txt_masters_log.configure(state="disabled")

    def _generate_masters(self):
        if not self.map_state.combos:
            messagebox.showwarning("No data", "Run 'Load into Product Mapping' first (Tab 4).")
            return
        if not self.var_audit_reviewed.get():
            proceed = messagebox.askyesno(
                "Mapping Audit not confirmed",
                "You haven't checked 'I have reviewed this Mapping Audit' on the Mapping Audit tab (Tab 6).\n\n"
                "It's strongly recommended to review the Product/Purpose mappings there first -- especially "
                "any combination below 75% confidence.\n\nGenerate Masters anyway?"
            )
            if not proceed:
                self.nb.select(self.tab_audit)
                return
        # Re-sync from the actual textbox right before generating, in case it was changed after
        # Split ran -- Masters/Transactions should reflect whatever is in the box at the moment of
        # generation, not a value cached from an earlier step.
        self.map_state.default_branch = eng.valid_branch(self.var_branch.get().strip()) or None
        # Confirmed as a real problem: an unhandled exception here (e.g. the AdmissionDate type-
        # mismatch crash just fixed) used to propagate silently -- the button click would appear to
        # do nothing, with no visible error, which is exactly what a "the app is stuck/loading"
        # report from this looks like from the outside. Now shows a clear error with the actual
        # cause instead of an apparent freeze, and the log keeps whatever ran before the failure.
        try:
            eng.generate_masters(self.map_state, self.last_ctx)
        except Exception:
            self._mlog("FATAL ERROR during Generate Masters:\n" + traceback.format_exc())
            messagebox.showerror("Generate Masters failed",
                "An unexpected error stopped Masters generation partway through -- see the log for "
                "the full details. No output was saved for this run; please report the error shown "
                "in the log so it can be fixed.")
            return
        self._mlog(f"Generated {len(self.map_state.masters_output)} master file(s) (one per mapped product):")
        for fname, mo in self.map_state.masters_output.items():
            self._mlog(f"   {fname}: {len(mo['rows'])} rows, amount {mo['amount']:,.0f}")
        cleanup = self.map_state.field_cleanup_log if hasattr(self.map_state, "field_cleanup_log") else {}
        n_cleanup = sum(len(v) for v in cleanup.values())
        if n_cleanup:
            self._mlog(f"   {n_cleanup} field(s) auto-cleaned (LedgerFolioNo special characters, "
                       f"JointAdmissionNo zeros, ChequeOption/IsOrganisation -> Yes/No, BranchId "
                       f"defaulted to 101 where nothing else was available) -- see Reports tab.")
        unresolved = eng.scan_operation_type_values(self.map_state)
        unresolved = [u for u in unresolved if u["RawValue"] not in self.map_state.operation_type_overrides]
        if unresolved:
            self._mlog(f"   \u26A0 {len(unresolved)} OperationTypeDesc value(s) still unresolved -- "
                       f"go back to Tab 4 to map them, or check Reports.")
        self.status_var.set(f"{len(self.map_state.masters_output)} master file(s) generated.")
        self._auto_save_reports()

    def _process_transactions(self):
        if not self.map_state.trans_rows:
            self._mlog("No Transactions_Raw data was found in the converted output -- skipping.")
            return
        if not self.map_state.loan_lookup:
            messagebox.showwarning("Generate Masters first", "Generate Masters before processing Transactions "
                                                               "(Transactions are matched to Masters by LoanNo).")
            return
        try:
            eng.process_transactions(self.map_state)
        except Exception:
            self._mlog("FATAL ERROR during Process Transactions:\n" + traceback.format_exc())
            messagebox.showerror("Process Transactions failed",
                "An unexpected error stopped transaction processing partway through -- see the log "
                "for the full details. Please report the error shown in the log so it can be fixed.")
            return
        self._mlog(f"\nTransactions processed: kept {self.map_state.trans_kept}, "
                    f"dropped(zero-amount) {self.map_state.trans_dropped}, "
                    f"matched-to-master {self.map_state.trans_matched}")
        self._mlog(f"Split into {len(self.map_state.trans_output)} file(s).")
        if self.map_state.trans_unmatched:
            self._mlog(f"{len(self.map_state.trans_unmatched)} unmatched LoanNo value(s) -- see Reports tab.")
        if self.map_state.trans_ambiguous_loanno:
            self._mlog(f"\u26A0 {len(self.map_state.trans_ambiguous_loanno)} LoanNo value(s) exist in more than "
                       f"one loan category and couldn't be resolved by AdmissionNo either -- see Reports tab "
                       f"(Ambiguous_LoanNo sheet) to check which product these transactions really belong to.")
        if self.map_state.trans_all_dropped_warning:
            self._mlog(f"\n\u26A0\u26A0\u26A0 {self.map_state.trans_all_dropped_warning}")
            messagebox.showwarning(
                "All transactions dropped -- likely a column-naming issue",
                "Every transaction row was dropped as zero-amount. This almost always means the source "
                "file's amount columns use different names than expected, not that the PACS genuinely "
                "has zero transactions.\n\nSee the Masters & Transactions log for the exact column names "
                "found in your file, and share them so the recognized-name list can be extended."
            )
        self.status_var.set("Transactions processed.")
        self._auto_save_reports()

    def _generate_clean_output(self):
        if not self.map_state.masters_output:
            messagebox.showwarning("Generate Masters first", "Generate Masters (and Process Transactions if "
                                                               "you have transaction data) before producing "
                                                               "the output folder.")
            return
        outdir_base = self.var_outdir.get().strip()
        if not outdir_base:
            messagebox.showwarning("Output folder missing", "Set an output folder on the Setup tab first.")
            return
        pacs_name = self.pacs_info.get("PacsName", "NoPACS")
        outdir = os.path.join(outdir_base, eng.sanitize_folder_name(str(pacs_name), max_len=15))
        os.makedirs(outdir, exist_ok=True)
        result = eng.build_clean_output(self.map_state, self.last_ctx, self.full_dfs, outdir)
        self._mlog(f"\nClean output written to: {outdir}")
        self._mlog(f"   Split_By_Member/        {result['member_files']} file(s)")
        self._mlog(f"   Split_By_Products/      {result['product_files']} file(s)")
        self._mlog(f"   Split_By_Transactions/  {result['transaction_files']} file(s)")
        self._mlog(f"   Reports/                Mapping_Audit_Report.xlsx, Validation_Report.xlsx")
        self.lbl_clean_output.configure(text=f"\u2713 Output ready at: {outdir}", style="Good.TLabel")
        self.status_var.set("Clean output folder generated.")
        self._refresh_reports_summary()
        messagebox.showinfo(
            "Output ready",
            f"Clean output written to:\n{outdir}\n\n"
            f"Split_By_Member/        {result['member_files']} file(s)\n"
            f"Split_By_Products/      {result['product_files']} file(s)\n"
            f"Split_By_Transactions/  {result['transaction_files']} file(s)\n"
            f"Reports/                Mapping_Audit_Report.xlsx + Validation_Report.xlsx\n\n"
            f"No source/raw files are included."
        )

    # ================================================================
    # TAB 7: REPORTS
    # ================================================================
    def _build_reports_tab(self):
        f = self.tab_reports
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Reports", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Both reports are written automatically to the Reports folder every time you "
                          "generate the clean output (Tab 7) -- they're always current, no export button needed.",
                  style="Sub.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", padx=10)

        self.stat_cards_frame = ttk.Frame(f)
        self.stat_cards_frame.grid(row=2, column=0, columnspan=3, sticky="we", padx=10, pady=(4, 10))

        btnf = ttk.Frame(f)
        btnf.grid(row=3, column=0, columnspan=3, sticky="w", padx=10, pady=6)
        self._create_button(btnf, "Refresh", self._refresh_reports_summary, kind="ghost").pack(side="left", padx=4)

        cols = ("report", "count", "note")
        self.tree_reports = ttk.Treeview(f, columns=cols, show="headings", height=16)
        self.tree_reports.heading("report", text="Report")
        self.tree_reports.heading("count", text="Rows")
        self.tree_reports.heading("note", text="Notes")
        self.tree_reports.column("report", width=320)
        self.tree_reports.column("count", width=80, anchor="center")
        self.tree_reports.column("note", width=600)
        self.tree_reports.grid(row=4, column=0, columnspan=3, sticky="nsew", padx=10, pady=8)
        f.rowconfigure(4, weight=1)
        f.columnconfigure(0, weight=1)

    def _stat_card(self, parent, label, value, color_key="primary"):
        P = self.PALETTE
        card = tk.Frame(parent, bg=P["surface"], highlightbackground=P["border"], highlightthickness=1, bd=0)
        tk.Label(card, text=label.upper(), bg=P["surface"], fg=P["text_sub"],
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14, pady=(10, 0))
        tk.Label(card, text=str(value), bg=P["surface"], fg=P.get(color_key, P["primary"]),
                 font=("Segoe UI", 20, "bold")).pack(anchor="w", padx=14, pady=(0, 12))
        return card

    def _refresh_stat_cards(self):
        for w in self.stat_cards_frame.winfo_children():
            w.destroy()
        ctx = self.last_ctx
        vr = getattr(self.map_state, "validation_reports", {}) or {}
        n_issues = len(self.last_issues) + sum(len(v) for v in vr.values())
        n_products = len(self.map_state.masters_output)
        n_accounts = sum(len(mo["rows"]) for mo in self.map_state.masters_output.values())
        total_amount = sum(mo["amount"] for mo in self.map_state.masters_output.values())
        cards = [
            ("Products Generated", n_products, "primary"),
            ("Total Accounts", f"{n_accounts:,}", "blue"),
            ("Total Amount", f"{total_amount:,.0f}", "accent"),
            ("Issues Flagged", n_issues, "bad" if n_issues else "good"),
        ]
        for i, (label, value, color) in enumerate(cards):
            card = self._stat_card(self.stat_cards_frame, label, value, color)
            card.grid(row=0, column=i, sticky="we", padx=(0 if i == 0 else 8, 0))
            self.stat_cards_frame.columnconfigure(i, weight=1)

    def _refresh_reports_summary(self):
        self._refresh_stat_cards()
        self.tree_reports.delete(*self.tree_reports.get_children())
        ctx = self.last_ctx
        rows = [
            ("All Validation Issues", len(self.last_issues), "Everything logged during conversion"),
        ]
        skipped = self.map_state.skipped_no_product
        if skipped:
            total_skipped = sum(v["skipped_rows"] for v in skipped.values())
            files_list = ", ".join(f"{k} ({v['skipped_rows']} rows)" for k, v in skipped.items())
            rows.append(("\u26A0 Rows Excluded (blank ProductDescription)", total_skipped,
                         f"NOT in Product Mapping at all -- check source column naming: {files_list}"))
        if self.balance_sheet_tally:
            n_tallied = sum(1 for r in self.balance_sheet_tally if r["Status"] == "Tallied")
            n_not = len(self.balance_sheet_tally) - n_tallied
            rows.append(("\U0001F4CA Balance Sheet Tally", len(self.balance_sheet_tally),
                         f"{n_tallied} tallied, {n_not} need review -- see Balance Sheet Tally sheet in Validation Report"))
        if ctx:
            rows += [
                ("Duplicate Member Report", len(ctx.duplicate_member_rows),
                 "Same AdmissionNo used by more than one member row"),
                ("Special Member Number Errors", len(ctx.special_member_number_rows),
                 "AdmissionNo not purely numeric (e.g. A125, B226) -- not allowed for upload"),
                ("AdmissionDate Cap Adjustments", len(ctx.admission_date_adjustments),
                 f"Pulled back to {eng.admission_date_cap_str()}"),
                ("AdmissionDate vs Account Date", len(ctx.admission_account_date_adjustments),
                 "AdmissionDate corrected to precede earliest loan/deposit"),
                ("SB/Pigmy Date Adjustments", len(ctx.sb_pigmy_date_adjustments),
                 "Deposit date corrected to not precede AdmissionDate"),
                ("Missing Membership", len(getattr(ctx, "missing_membership_rows", [])),
                 "Account rows referencing an AdmissionNo not found in Membership"),
                ("Duplicate Aadhaar (deleted)", len(ctx.deleted_aadhaar), ""),
                ("Duplicate PAN (deleted)", len(ctx.deleted_pan), ""),
            ]
        rows.append(("Product-Purpose Mapping", len(self.map_state.combos),
                     "Every source Product/Purpose row + merged totals when several rows map to the same product, in one sheet"))
        if self.map_state.masters_output or self.map_state.trans_product_stats:
            tally = eng.build_tally_report(self.map_state)
            n_incomplete = sum(1 for t in tally if not str(t["Completeness"]).startswith(("OK", "N/A")))
            n_mismatched = sum(1 for t in tally if str(t["Amount Tallied?"]).startswith("No"))
            note = "All products complete and tallied"
            if n_incomplete or n_mismatched:
                parts = []
                if n_incomplete:
                    parts.append(f"{n_incomplete} product(s) with incomplete transaction data")
                if n_mismatched:
                    parts.append(f"{n_mismatched} product(s) not amount-tallied")
                note = "; ".join(parts)
            rows.append(("Transaction Tally Report", len(tally), note))
        vr = getattr(self.map_state, "validation_reports", {}) or {}
        if vr:
            rows += [
                ("LedgerFolioNo Cleanup", len(vr.get("LedgerFolioNo Cleanup", [])),
                 "Special characters removed, e.g. '30.05.2023(bmr date)' -> '30.05.2023 bmr date'"),
                ("JointAdmissionNo Cleanup", len(vr.get("JointAdmissionNo Cleanup", [])),
                 "Zero values cleared to blank"),
                ("ChequeOption/IsOrganisation Cleanup", len(vr.get("ChequeOption-IsOrganisation Cleanup", [])),
                 "Normalized to strict Yes/No"),
                ("OperationTypeDesc Mapping", len(vr.get("OperationTypeDesc Mapping", [])),
                 "Values corrected to the allowed OperationTypeDesc list"),
                ("OperationTypeDesc Unresolved", len(vr.get("OperationTypeDesc Unresolved", [])),
                 "Still need manual mapping -- see Tab 4 popup"),
                ("MaturityDate Correction", len(vr.get("MaturityDate Correction", [])),
                 "MaturityDate recomputed from DepositDate + Term (was blank or inconsistent)"),
                ("DepositAmount Correction (RD)", len(vr.get("DepositAmount Correction (RD)", [])),
                 "RD running balance computed as InstallmentAmount x InstallmentsPaid (was blank/zero)"),
                ("Deposit Calculation Issues", len(vr.get("Deposit Calculation Issues", [])),
                 "MaturityDate/MaturityAmount vs DepositDate+Term (includes reverse-calc alternate for renewed deposits)"),
                ("RD Deep Validation", len(vr.get("RD Deep Validation", [])),
                 "RD-specific checks: DepositTypeDesc, InstallmentAmount, TerminMonths, InterestAmount sanity"),
                ("Deposit Data Quality Issues", len(vr.get("Deposit Data Quality Issues", [])),
                 "Missing/out-of-range fields across FD/RD/SB beyond the date-arithmetic checks"),
                ("Loan Calculation Issues", len(vr.get("Loan Calculation Issues", [])),
                 "DueDate/FirstInstallmentDate/InstallmentAmount that don't match the expected formula"),
            ]
        if self.map_state.trans_unmatched:
            rows.append(("Unmatched Transaction LoanNo", len(self.map_state.trans_unmatched),
                         "Transactions with no matching Master LoanNo"))
        if self.map_state.trans_ambiguous_loanno:
            rows.append(("\u26A0 Ambiguous Transaction LoanNo", len(self.map_state.trans_ambiguous_loanno),
                         "LoanNo exists in 2+ loan categories and AdmissionNo didn't resolve which one -- "
                         "check the Ambiguous_LoanNo sheet in the Mapping Audit Report"))
        for r in rows:
            self.tree_reports.insert("", "end", values=r)

    # ================================================================
    # TAB 8: CONFIG
    # ================================================================
    def _build_config_tab(self):
        f = self.tab_config
        pad = {"padx": 10, "pady": 6}
        ttk.Label(f, text="Config", style="Header.TLabel").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(f, text="Value-mapping tables used during conversion (caste, farmer type, community, "
                          "etc.), plus custom additions to the Product/Purpose taxonomy used in mapping.",
                  style="Sub.TLabel", wraplength=900).grid(row=1, column=0, columnspan=4, sticky="w", padx=10)

        nb2 = ttk.Notebook(f)
        nb2.grid(row=2, column=0, columnspan=4, sticky="nsew", padx=10, pady=8)
        f.rowconfigure(2, weight=1)
        f.columnconfigure(0, weight=1)

        tab_vmap = ttk.Frame(nb2)
        tab_tax = ttk.Frame(nb2)
        nb2.add(tab_vmap, text="Value Mapping Tables")
        nb2.add(tab_tax, text="Custom Product/Purpose Taxonomy")

        self._build_value_mapping_subtab(tab_vmap)
        self._build_taxonomy_subtab(tab_tax)

    SIMPLE_MAP_KEYS = [
        ("caste_map", "Caste Description"),
        ("farmer_type_map", "Farmer Type Description"),
        ("member_type_map", "Member Type (overrides / odd values)"),
        ("customer_type_map", "Customer Type"),
        ("community_map", "Community Description"),
        ("marital_status_map", "Marital Status"),
        ("gender_map", "Gender Description"),
    ]

    def _build_value_mapping_subtab(self, f):
        pad = {"padx": 10, "pady": 6}
        topf = ttk.Frame(f)
        topf.pack(fill="x", padx=10, pady=6)
        ttk.Label(topf, text="Mapping table:").pack(side="left")
        self.var_map_choice = tk.StringVar()
        self.combo_map_choice = ttk.Combobox(topf, textvariable=self.var_map_choice, state="readonly", width=46,
                                              values=[label for _, label in self.SIMPLE_MAP_KEYS])
        self.combo_map_choice.current(0)
        self.combo_map_choice.pack(side="left", padx=8)
        self.combo_map_choice.bind("<<ComboboxSelected>>", lambda e: self._refresh_mapping_tree())

        btnf = ttk.Frame(f)
        btnf.pack(fill="x", padx=10)
        self._create_button(btnf, "Add / Edit Entry", self._add_edit_mapping_entry).pack(side="left", padx=4)
        self._create_button(btnf, "Delete Selected", self._delete_mapping_entry).pack(side="left", padx=4)
        self._create_button(btnf, "Save Mappings Now", self._save_mappings).pack(side="left", padx=4)

        self.tree_map = ttk.Treeview(f, columns=("source", "target"), show="headings", height=16)
        self.tree_map.heading("source", text="Source value (as found in PACS data)")
        self.tree_map.heading("target", text="Maps to (Template value)")
        self.tree_map.column("source", width=420)
        self.tree_map.column("target", width=420)
        self.tree_map.pack(fill="both", expand=True, padx=10, pady=8)
        self._refresh_mapping_tree()

    def _current_mapping_dict(self):
        choice = self.var_map_choice.get()
        for key, label in self.SIMPLE_MAP_KEYS:
            if label == choice:
                return self.cfg[key]
        return {}

    def _refresh_mapping_tree(self):
        self.tree_map.delete(*self.tree_map.get_children())
        for k, v in sorted(self._current_mapping_dict().items()):
            self.tree_map.insert("", "end", values=(k, v))

    def _add_edit_mapping_entry(self):
        mapping = self._current_mapping_dict()
        sel = self.tree_map.selection()
        default_src = self.tree_map.item(sel[0], "values")[0] if sel else ""
        default_tgt = self.tree_map.item(sel[0], "values")[1] if sel else ""
        src = simpledialog.askstring("Source value", "Exact source value (as it appears in the PACS file):",
                                      initialvalue=default_src, parent=self)
        if not src:
            return
        tgt = simpledialog.askstring("Maps to", "What should this map to in the output template?",
                                      initialvalue=default_tgt, parent=self)
        if tgt is None:
            return
        mapping[eng.norm_key(src)] = tgt
        self._refresh_mapping_tree()

    def _delete_mapping_entry(self):
        mapping = self._current_mapping_dict()
        for iid in self.tree_map.selection():
            src = self.tree_map.item(iid, "values")[0]
            mapping.pop(src, None)
            self.tree_map.delete(iid)

    def _save_mappings(self):
        try:
            eng.save_config(self.base_dir, self.cfg)
            messagebox.showinfo("Saved", "Mapping tables saved.")
        except Exception as e:
            messagebox.showerror("Could not save", str(e))

    def _build_taxonomy_subtab(self, f):
        ttk.Label(f, text="Add extra Products / Purposes / Crops on top of the built-in taxonomy "
                          "(from Logic_maping.xlsx + the Crop/Purpose Requirement attachment). "
                          "These are saved globally and used by the Product Mapping tab's suggestions.",
                  style="Sub.TLabel", wraplength=900).pack(anchor="w", padx=10, pady=6)
        topf = ttk.Frame(f)
        topf.pack(fill="x", padx=10, pady=6)
        ttk.Label(topf, text="Taxonomy list:").pack(side="left")
        self.var_tax_choice = tk.StringVar()
        combo = ttk.Combobox(topf, textvariable=self.var_tax_choice, state="readonly", width=30,
                              values=list(eng.TAXONOMY_BASE.keys()))
        combo.current(0)
        combo.pack(side="left", padx=8)
        combo.bind("<<ComboboxSelected>>", lambda e: self._refresh_tax_list())
        self.var_tax_new = tk.StringVar()
        ttk.Entry(topf, textvariable=self.var_tax_new, width=30).pack(side="left", padx=8)
        self._create_button(topf, "Add", self._add_tax_entry).pack(side="left", padx=4)
        self._create_button(topf, "Remove Selected", self._remove_tax_entry).pack(side="left", padx=4)

        self.list_tax = tk.Listbox(f, height=18)
        self.list_tax.pack(fill="both", expand=True, padx=10, pady=8)
        self._refresh_tax_list()

    def _refresh_tax_list(self):
        self.list_tax.delete(0, "end")
        key = self.var_tax_choice.get()
        for item in self.map_state.custom_tax.get(key, []):
            self.list_tax.insert("end", item)

    def _add_tax_entry(self):
        key = self.var_tax_choice.get()
        val = self.var_tax_new.get().strip()
        if not val:
            return
        self.map_state.custom_tax.setdefault(key, [])
        if val not in self.map_state.custom_tax[key]:
            self.map_state.custom_tax[key].append(val)
        self.map_state.save_custom_tax()
        self.var_tax_new.set("")
        self._refresh_tax_list()

    def _remove_tax_entry(self):
        key = self.var_tax_choice.get()
        sel = self.list_tax.curselection()
        if not sel:
            return
        val = self.list_tax.get(sel[0])
        if val in self.map_state.custom_tax.get(key, []):
            self.map_state.custom_tax[key].remove(val)
        self.map_state.save_custom_tax()
        self._refresh_tax_list()


def _declare_windows_dpi_awareness():
    """Without this, Tkinter apps on Windows get scaled as a blurry bitmap by the OS on any
    high-DPI display -- which is the norm on modern 14" laptops (commonly 1920x1080 or higher at
    125-150% Windows scaling). The symptom is exactly "doesn't fit / looks wrong on my 14-inch
    screen": text and controls render at the wrong physical size relative to the real window
    dimensions. Declaring per-monitor DPI awareness (Windows 8.1+) makes Tkinter render natively at
    the display's actual scale instead. No-op on non-Windows platforms."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PER_MONITOR_DPI_AWARE
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()  # older Windows fallback
    except Exception:
        pass


def main():
    _declare_windows_dpi_awareness()
    app = SuiteApp()
    app.mainloop()


if __name__ == "__main__":
    main()
